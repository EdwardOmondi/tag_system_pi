var Pg = Object.defineProperty,
	kg = Object.defineProperties;
var Lg = Object.getOwnPropertyDescriptors;
var Xc = Object.getOwnPropertySymbols;
var Vg = Object.prototype.hasOwnProperty,
	jg = Object.prototype.propertyIsEnumerable;
var el = (e, t, r) => t in e ? Pg(e, t, {
		enumerable: !0,
		configurable: !0,
		writable: !0,
		value: r
	}) : e[t] = r,
	g = (e, t) => {
		for (var r in t ||= {}) Vg.call(t, r) && el(e, r, t[r]);
		if (Xc)
			for (var r of Xc(t)) jg.call(t, r) && el(e, r, t[r]);
		return e
	},
	z = (e, t) => kg(e, Lg(t));
var tl = null;
var ys = 1,
	nl = Symbol("SIGNAL");

function k(e) {
	let t = tl;
	return tl = e, t
}
var rl = {
	version: 0,
	lastCleanEpoch: 0,
	dirty: !1,
	producerNode: void 0,
	producerLastReadVersion: void 0,
	producerIndexOfThis: void 0,
	nextProducerIndex: 0,
	liveConsumerNode: void 0,
	liveConsumerIndexOfThis: void 0,
	consumerAllowSignalWrites: !1,
	consumerIsAlwaysLive: !1,
	producerMustRecompute: () => !1,
	producerRecomputeValue: () => {},
	consumerMarkedDirty: () => {},
	consumerOnSignalRead: () => {}
};

function Ug(e) {
	if (!(Cs(e) && !e.dirty) && !(!e.dirty && e.lastCleanEpoch === ys)) {
		if (!e.producerMustRecompute(e) && !Ds(e)) {
			e.dirty = !1, e.lastCleanEpoch = ys;
			return
		}
		e.producerRecomputeValue(e), e.dirty = !1, e.lastCleanEpoch = ys
	}
}

function il(e) {
	return e && (e.nextProducerIndex = 0), k(e)
}

function ol(e, t) {
	if (k(t), !(!e || e.producerNode === void 0 || e.producerIndexOfThis === void 0 || e.producerLastReadVersion === void 0)) {
		if (Cs(e))
			for (let r = e.nextProducerIndex; r < e.producerNode.length; r++) ws(e.producerNode[r], e.producerIndexOfThis[r]);
		for (; e.producerNode.length > e.nextProducerIndex;) e.producerNode.pop(), e.producerLastReadVersion.pop(), e.producerIndexOfThis.pop()
	}
}

function Ds(e) {
	ui(e);
	for (let t = 0; t < e.producerNode.length; t++) {
		let r = e.producerNode[t],
			n = e.producerLastReadVersion[t];
		if (n !== r.version || (Ug(r), n !== r.version)) return !0
	}
	return !1
}

function sl(e) {
	if (ui(e), Cs(e))
		for (let t = 0; t < e.producerNode.length; t++) ws(e.producerNode[t], e.producerIndexOfThis[t]);
	e.producerNode.length = e.producerLastReadVersion.length = e.producerIndexOfThis.length = 0, e.liveConsumerNode && (e.liveConsumerNode.length = e.liveConsumerIndexOfThis.length = 0)
}

function ws(e, t) {
	if ($g(e), ui(e), e.liveConsumerNode.length === 1)
		for (let n = 0; n < e.producerNode.length; n++) ws(e.producerNode[n], e.producerIndexOfThis[n]);
	let r = e.liveConsumerNode.length - 1;
	if (e.liveConsumerNode[t] = e.liveConsumerNode[r], e.liveConsumerIndexOfThis[t] = e.liveConsumerIndexOfThis[r], e.liveConsumerNode.length--, e.liveConsumerIndexOfThis.length--, t < e.liveConsumerNode.length) {
		let n = e.liveConsumerIndexOfThis[t],
			i = e.liveConsumerNode[t];
		ui(i), i.producerIndexOfThis[n] = t
	}
}

function Cs(e) {
	return e.consumerIsAlwaysLive || (e?.liveConsumerNode?.length ?? 0) > 0
}

function ui(e) {
	e.producerNode ??= [], e.producerIndexOfThis ??= [], e.producerLastReadVersion ??= []
}

function $g(e) {
	e.liveConsumerNode ??= [], e.liveConsumerIndexOfThis ??= []
}

function Bg() {
	throw new Error
}
var Hg = Bg;

function al(e) {
	Hg = e
}

function T(e) {
	return typeof e == "function"
}

function dn(e) {
	let r = e(n => {
		Error.call(n), n.stack = new Error().stack
	});
	return r.prototype = Object.create(Error.prototype), r.prototype.constructor = r, r
}
var ci = dn(e => function(r) {
	e(this), this.message = r ? `${r.length} errors occurred during unsubscription:
${r.map((n,i)=>`${i+1}) ${n.toString()}`).join(`
  `)}` : "", this.name = "UnsubscriptionError", this.errors = r
});

function nr(e, t) {
	if (e) {
		let r = e.indexOf(t);
		0 <= r && e.splice(r, 1)
	}
}
var J = class e {
	constructor(t) {
		this.initialTeardown = t, this.closed = !1, this._parentage = null, this._finalizers = null
	}
	unsubscribe() {
		let t;
		if (!this.closed) {
			this.closed = !0;
			let {
				_parentage: r
			} = this;
			if (r)
				if (this._parentage = null, Array.isArray(r))
					for (let o of r) o.remove(this);
				else r.remove(this);
			let {
				initialTeardown: n
			} = this;
			if (T(n)) try {
				n()
			} catch (o) {
				t = o instanceof ci ? o.errors : [o]
			}
			let {
				_finalizers: i
			} = this;
			if (i) {
				this._finalizers = null;
				for (let o of i) try {
					ul(o)
				} catch (s) {
					t = t ?? [], s instanceof ci ? t = [...t, ...s.errors] : t.push(s)
				}
			}
			if (t) throw new ci(t)
		}
	}
	add(t) {
		var r;
		if (t && t !== this)
			if (this.closed) ul(t);
			else {
				if (t instanceof e) {
					if (t.closed || t._hasParent(this)) return;
					t._addParent(this)
				}(this._finalizers = (r = this._finalizers) !== null && r !== void 0 ? r : []).push(t)
			}
	}
	_hasParent(t) {
		let {
			_parentage: r
		} = this;
		return r === t || Array.isArray(r) && r.includes(t)
	}
	_addParent(t) {
		let {
			_parentage: r
		} = this;
		this._parentage = Array.isArray(r) ? (r.push(t), r) : r ? [r, t] : t
	}
	_removeParent(t) {
		let {
			_parentage: r
		} = this;
		r === t ? this._parentage = null : Array.isArray(r) && nr(r, t)
	}
	remove(t) {
		let {
			_finalizers: r
		} = this;
		r && nr(r, t), t instanceof e && t._removeParent(this)
	}
};
J.EMPTY = (() => {
	let e = new J;
	return e.closed = !0, e
})();
var Es = J.EMPTY;

function li(e) {
	return e instanceof J || e && "closed" in e && T(e.remove) && T(e.add) && T(e.unsubscribe)
}

function ul(e) {
	T(e) ? e() : e.unsubscribe()
}
var Le = {
	onUnhandledError: null,
	onStoppedNotification: null,
	Promise: void 0,
	useDeprecatedSynchronousErrorHandling: !1,
	useDeprecatedNextContext: !1
};
var fn = {
	setTimeout(e, t, ...r) {
		let {
			delegate: n
		} = fn;
		return n?.setTimeout ? n.setTimeout(e, t, ...r) : setTimeout(e, t, ...r)
	},
	clearTimeout(e) {
		let {
			delegate: t
		} = fn;
		return (t?.clearTimeout || clearTimeout)(e)
	},
	delegate: void 0
};

function di(e) {
	fn.setTimeout(() => {
		let {
			onUnhandledError: t
		} = Le;
		if (t) t(e);
		else throw e
	})
}

function rr() {}
var cl = bs("C", void 0, void 0);

function ll(e) {
	return bs("E", void 0, e)
}

function dl(e) {
	return bs("N", e, void 0)
}

function bs(e, t, r) {
	return {
		kind: e,
		value: t,
		error: r
	}
}
var Ut = null;

function hn(e) {
	if (Le.useDeprecatedSynchronousErrorHandling) {
		let t = !Ut;
		if (t && (Ut = {
				errorThrown: !1,
				error: null
			}), e(), t) {
			let {
				errorThrown: r,
				error: n
			} = Ut;
			if (Ut = null, r) throw n
		}
	} else e()
}

function fl(e) {
	Le.useDeprecatedSynchronousErrorHandling && Ut && (Ut.errorThrown = !0, Ut.error = e)
}
var $t = class extends J {
		constructor(t) {
			super(), this.isStopped = !1, t ? (this.destination = t, li(t) && t.add(this)) : this.destination = qg
		}
		static create(t, r, n) {
			return new pn(t, r, n)
		}
		next(t) {
			this.isStopped ? Ms(dl(t), this) : this._next(t)
		}
		error(t) {
			this.isStopped ? Ms(ll(t), this) : (this.isStopped = !0, this._error(t))
		}
		complete() {
			this.isStopped ? Ms(cl, this) : (this.isStopped = !0, this._complete())
		}
		unsubscribe() {
			this.closed || (this.isStopped = !0, super.unsubscribe(), this.destination = null)
		}
		_next(t) {
			this.destination.next(t)
		}
		_error(t) {
			try {
				this.destination.error(t)
			} finally {
				this.unsubscribe()
			}
		}
		_complete() {
			try {
				this.destination.complete()
			} finally {
				this.unsubscribe()
			}
		}
	},
	zg = Function.prototype.bind;

function Is(e, t) {
	return zg.call(e, t)
}
var _s = class {
		constructor(t) {
			this.partialObserver = t
		}
		next(t) {
			let {
				partialObserver: r
			} = this;
			if (r.next) try {
				r.next(t)
			} catch (n) {
				fi(n)
			}
		}
		error(t) {
			let {
				partialObserver: r
			} = this;
			if (r.error) try {
				r.error(t)
			} catch (n) {
				fi(n)
			} else fi(t)
		}
		complete() {
			let {
				partialObserver: t
			} = this;
			if (t.complete) try {
				t.complete()
			} catch (r) {
				fi(r)
			}
		}
	},
	pn = class extends $t {
		constructor(t, r, n) {
			super();
			let i;
			if (T(t) || !t) i = {
				next: t ?? void 0,
				error: r ?? void 0,
				complete: n ?? void 0
			};
			else {
				let o;
				this && Le.useDeprecatedNextContext ? (o = Object.create(t), o.unsubscribe = () => this.unsubscribe(), i = {
					next: t.next && Is(t.next, o),
					error: t.error && Is(t.error, o),
					complete: t.complete && Is(t.complete, o)
				}) : i = t
			}
			this.destination = new _s(i)
		}
	};

function fi(e) {
	Le.useDeprecatedSynchronousErrorHandling ? fl(e) : di(e)
}

function Gg(e) {
	throw e
}

function Ms(e, t) {
	let {
		onStoppedNotification: r
	} = Le;
	r && fn.setTimeout(() => r(e, t))
}
var qg = {
	closed: !0,
	next: rr,
	error: Gg,
	complete: rr
};
var gn = typeof Symbol == "function" && Symbol.observable || "@@observable";

function be(e) {
	return e
}

function Ss(...e) {
	return Ts(e)
}

function Ts(e) {
	return e.length === 0 ? be : e.length === 1 ? e[0] : function(r) {
		return e.reduce((n, i) => i(n), r)
	}
}
var V = (() => {
	class e {
		constructor(r) {
			r && (this._subscribe = r)
		}
		lift(r) {
			let n = new e;
			return n.source = this, n.operator = r, n
		}
		subscribe(r, n, i) {
			let o = Zg(r) ? r : new pn(r, n, i);
			return hn(() => {
				let {
					operator: s,
					source: a
				} = this;
				o.add(s ? s.call(o, a) : a ? this._subscribe(o) : this._trySubscribe(o))
			}), o
		}
		_trySubscribe(r) {
			try {
				return this._subscribe(r)
			} catch (n) {
				r.error(n)
			}
		}
		forEach(r, n) {
			return n = hl(n), new n((i, o) => {
				let s = new pn({
					next: a => {
						try {
							r(a)
						} catch (u) {
							o(u), s.unsubscribe()
						}
					},
					error: o,
					complete: i
				});
				this.subscribe(s)
			})
		}
		_subscribe(r) {
			var n;
			return (n = this.source) === null || n === void 0 ? void 0 : n.subscribe(r)
		} [gn]() {
			return this
		}
		pipe(...r) {
			return Ts(r)(this)
		}
		toPromise(r) {
			return r = hl(r), new r((n, i) => {
				let o;
				this.subscribe(s => o = s, s => i(s), () => n(o))
			})
		}
	}
	return e.create = t => new e(t), e
})();

function hl(e) {
	var t;
	return (t = e ?? Le.Promise) !== null && t !== void 0 ? t : Promise
}

function Wg(e) {
	return e && T(e.next) && T(e.error) && T(e.complete)
}

function Zg(e) {
	return e && e instanceof $t || Wg(e) && li(e)
}

function xs(e) {
	return T(e?.lift)
}

function L(e) {
	return t => {
		if (xs(t)) return t.lift(function(r) {
			try {
				return e(r, this)
			} catch (n) {
				this.error(n)
			}
		});
		throw new TypeError("Unable to lift unknown Observable type")
	}
}

function F(e, t, r, n, i) {
	return new As(e, t, r, n, i)
}
var As = class extends $t {
	constructor(t, r, n, i, o, s) {
		super(t), this.onFinalize = o, this.shouldUnsubscribe = s, this._next = r ? function(a) {
			try {
				r(a)
			} catch (u) {
				t.error(u)
			}
		} : super._next, this._error = i ? function(a) {
			try {
				i(a)
			} catch (u) {
				t.error(u)
			} finally {
				this.unsubscribe()
			}
		} : super._error, this._complete = n ? function() {
			try {
				n()
			} catch (a) {
				t.error(a)
			} finally {
				this.unsubscribe()
			}
		} : super._complete
	}
	unsubscribe() {
		var t;
		if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
			let {
				closed: r
			} = this;
			super.unsubscribe(), !r && ((t = this.onFinalize) === null || t === void 0 || t.call(this))
		}
	}
};

function mn() {
	return L((e, t) => {
		let r = null;
		e._refCount++;
		let n = F(t, void 0, void 0, void 0, () => {
			if (!e || e._refCount <= 0 || 0 < --e._refCount) {
				r = null;
				return
			}
			let i = e._connection,
				o = r;
			r = null, i && (!o || i === o) && i.unsubscribe(), t.unsubscribe()
		});
		e.subscribe(n), n.closed || (r = e.connect())
	})
}
var vn = class extends V {
	constructor(t, r) {
		super(), this.source = t, this.subjectFactory = r, this._subject = null, this._refCount = 0, this._connection = null, xs(t) && (this.lift = t.lift)
	}
	_subscribe(t) {
		return this.getSubject().subscribe(t)
	}
	getSubject() {
		let t = this._subject;
		return (!t || t.isStopped) && (this._subject = this.subjectFactory()), this._subject
	}
	_teardown() {
		this._refCount = 0;
		let {
			_connection: t
		} = this;
		this._subject = this._connection = null, t?.unsubscribe()
	}
	connect() {
		let t = this._connection;
		if (!t) {
			t = this._connection = new J;
			let r = this.getSubject();
			t.add(this.source.subscribe(F(r, void 0, () => {
				this._teardown(), r.complete()
			}, n => {
				this._teardown(), r.error(n)
			}, () => this._teardown()))), t.closed && (this._connection = null, t = J.EMPTY)
		}
		return t
	}
	refCount() {
		return mn()(this)
	}
};
var pl = dn(e => function() {
	e(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"
});
var X = (() => {
		class e extends V {
			constructor() {
				super(), this.closed = !1, this.currentObservers = null, this.observers = [], this.isStopped = !1, this.hasError = !1, this.thrownError = null
			}
			lift(r) {
				let n = new hi(this, this);
				return n.operator = r, n
			}
			_throwIfClosed() {
				if (this.closed) throw new pl
			}
			next(r) {
				hn(() => {
					if (this._throwIfClosed(), !this.isStopped) {
						this.currentObservers || (this.currentObservers = Array.from(this.observers));
						for (let n of this.currentObservers) n.next(r)
					}
				})
			}
			error(r) {
				hn(() => {
					if (this._throwIfClosed(), !this.isStopped) {
						this.hasError = this.isStopped = !0, this.thrownError = r;
						let {
							observers: n
						} = this;
						for (; n.length;) n.shift().error(r)
					}
				})
			}
			complete() {
				hn(() => {
					if (this._throwIfClosed(), !this.isStopped) {
						this.isStopped = !0;
						let {
							observers: r
						} = this;
						for (; r.length;) r.shift().complete()
					}
				})
			}
			unsubscribe() {
				this.isStopped = this.closed = !0, this.observers = this.currentObservers = null
			}
			get observed() {
				var r;
				return ((r = this.observers) === null || r === void 0 ? void 0 : r.length) > 0
			}
			_trySubscribe(r) {
				return this._throwIfClosed(), super._trySubscribe(r)
			}
			_subscribe(r) {
				return this._throwIfClosed(), this._checkFinalizedStatuses(r), this._innerSubscribe(r)
			}
			_innerSubscribe(r) {
				let {
					hasError: n,
					isStopped: i,
					observers: o
				} = this;
				return n || i ? Es : (this.currentObservers = null, o.push(r), new J(() => {
					this.currentObservers = null, nr(o, r)
				}))
			}
			_checkFinalizedStatuses(r) {
				let {
					hasError: n,
					thrownError: i,
					isStopped: o
				} = this;
				n ? r.error(i) : o && r.complete()
			}
			asObservable() {
				let r = new V;
				return r.source = this, r
			}
		}
		return e.create = (t, r) => new hi(t, r), e
	})(),
	hi = class extends X {
		constructor(t, r) {
			super(), this.destination = t, this.source = r
		}
		next(t) {
			var r, n;
			(n = (r = this.destination) === null || r === void 0 ? void 0 : r.next) === null || n === void 0 || n.call(r, t)
		}
		error(t) {
			var r, n;
			(n = (r = this.destination) === null || r === void 0 ? void 0 : r.error) === null || n === void 0 || n.call(r, t)
		}
		complete() {
			var t, r;
			(r = (t = this.destination) === null || t === void 0 ? void 0 : t.complete) === null || r === void 0 || r.call(t)
		}
		_subscribe(t) {
			var r, n;
			return (n = (r = this.source) === null || r === void 0 ? void 0 : r.subscribe(t)) !== null && n !== void 0 ? n : Es
		}
	};
var W = class extends X {
	constructor(t) {
		super(), this._value = t
	}
	get value() {
		return this.getValue()
	}
	_subscribe(t) {
		let r = super._subscribe(t);
		return !r.closed && t.next(this._value), r
	}
	getValue() {
		let {
			hasError: t,
			thrownError: r,
			_value: n
		} = this;
		if (t) throw r;
		return this._throwIfClosed(), n
	}
	next(t) {
		super.next(this._value = t)
	}
};
var Ie = new V(e => e.complete());

function gl(e) {
	return e && T(e.schedule)
}

function ml(e) {
	return e[e.length - 1]
}

function pi(e) {
	return T(ml(e)) ? e.pop() : void 0
}

function Dt(e) {
	return gl(ml(e)) ? e.pop() : void 0
}

function yl(e, t, r, n) {
	function i(o) {
		return o instanceof r ? o : new r(function(s) {
			s(o)
		})
	}
	return new(r || (r = Promise))(function(o, s) {
		function a(l) {
			try {
				c(n.next(l))
			} catch (d) {
				s(d)
			}
		}

		function u(l) {
			try {
				c(n.throw(l))
			} catch (d) {
				s(d)
			}
		}

		function c(l) {
			l.done ? o(l.value) : i(l.value).then(a, u)
		}
		c((n = n.apply(e, t || [])).next())
	})
}

function vl(e) {
	var t = typeof Symbol == "function" && Symbol.iterator,
		r = t && e[t],
		n = 0;
	if (r) return r.call(e);
	if (e && typeof e.length == "number") return {
		next: function() {
			return e && n >= e.length && (e = void 0), {
				value: e && e[n++],
				done: !e
			}
		}
	};
	throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function Bt(e) {
	return this instanceof Bt ? (this.v = e, this) : new Bt(e)
}

function Dl(e, t, r) {
	if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
	var n = r.apply(e, t || []),
		i, o = [];
	return i = {}, s("next"), s("throw"), s("return"), i[Symbol.asyncIterator] = function() {
		return this
	}, i;

	function s(f) {
		n[f] && (i[f] = function(h) {
			return new Promise(function(m, S) {
				o.push([f, h, m, S]) > 1 || a(f, h)
			})
		})
	}

	function a(f, h) {
		try {
			u(n[f](h))
		} catch (m) {
			d(o[0][3], m)
		}
	}

	function u(f) {
		f.value instanceof Bt ? Promise.resolve(f.value.v).then(c, l) : d(o[0][2], f)
	}

	function c(f) {
		a("next", f)
	}

	function l(f) {
		a("throw", f)
	}

	function d(f, h) {
		f(h), o.shift(), o.length && a(o[0][0], o[0][1])
	}
}

function wl(e) {
	if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
	var t = e[Symbol.asyncIterator],
		r;
	return t ? t.call(e) : (e = typeof vl == "function" ? vl(e) : e[Symbol.iterator](), r = {}, n("next"), n("throw"), n("return"), r[Symbol.asyncIterator] = function() {
		return this
	}, r);

	function n(o) {
		r[o] = e[o] && function(s) {
			return new Promise(function(a, u) {
				s = e[o](s), i(a, u, s.done, s.value)
			})
		}
	}

	function i(o, s, a, u) {
		Promise.resolve(u).then(function(c) {
			o({
				value: c,
				done: a
			})
		}, s)
	}
}
var gi = e => e && typeof e.length == "number" && typeof e != "function";

function mi(e) {
	return T(e?.then)
}

function vi(e) {
	return T(e[gn])
}

function yi(e) {
	return Symbol.asyncIterator && T(e?.[Symbol.asyncIterator])
}

function Di(e) {
	return new TypeError(`You provided ${e!==null&&typeof e=="object"?"an invalid object":`'${e}'`} where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.`)
}

function Yg() {
	return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator
}
var wi = Yg();

function Ci(e) {
	return T(e?.[wi])
}

function Ei(e) {
	return Dl(this, arguments, function*() {
		let r = e.getReader();
		try {
			for (;;) {
				let {
					value: n,
					done: i
				} = yield Bt(r.read());
				if (i) return yield Bt(void 0);
				yield yield Bt(n)
			}
		} finally {
			r.releaseLock()
		}
	})
}

function bi(e) {
	return T(e?.getReader)
}

function Q(e) {
	if (e instanceof V) return e;
	if (e != null) {
		if (vi(e)) return Qg(e);
		if (gi(e)) return Kg(e);
		if (mi(e)) return Jg(e);
		if (yi(e)) return Cl(e);
		if (Ci(e)) return Xg(e);
		if (bi(e)) return em(e)
	}
	throw Di(e)
}

function Qg(e) {
	return new V(t => {
		let r = e[gn]();
		if (T(r.subscribe)) return r.subscribe(t);
		throw new TypeError("Provided object does not correctly implement Symbol.observable")
	})
}

function Kg(e) {
	return new V(t => {
		for (let r = 0; r < e.length && !t.closed; r++) t.next(e[r]);
		t.complete()
	})
}

function Jg(e) {
	return new V(t => {
		e.then(r => {
			t.closed || (t.next(r), t.complete())
		}, r => t.error(r)).then(null, di)
	})
}

function Xg(e) {
	return new V(t => {
		for (let r of e)
			if (t.next(r), t.closed) return;
		t.complete()
	})
}

function Cl(e) {
	return new V(t => {
		tm(e, t).catch(r => t.error(r))
	})
}

function em(e) {
	return Cl(Ei(e))
}

function tm(e, t) {
	var r, n, i, o;
	return yl(this, void 0, void 0, function*() {
		try {
			for (r = wl(e); n = yield r.next(), !n.done;) {
				let s = n.value;
				if (t.next(s), t.closed) return
			}
		} catch (s) {
			i = {
				error: s
			}
		} finally {
			try {
				n && !n.done && (o = r.return) && (yield o.call(r))
			} finally {
				if (i) throw i.error
			}
		}
		t.complete()
	})
}

function me(e, t, r, n = 0, i = !1) {
	let o = t.schedule(function() {
		r(), i ? e.add(this.schedule(null, n)) : this.unsubscribe()
	}, n);
	if (e.add(o), !i) return o
}

function Ii(e, t = 0) {
	return L((r, n) => {
		r.subscribe(F(n, i => me(n, e, () => n.next(i), t), () => me(n, e, () => n.complete(), t), i => me(n, e, () => n.error(i), t)))
	})
}

function Mi(e, t = 0) {
	return L((r, n) => {
		n.add(e.schedule(() => r.subscribe(n), t))
	})
}

function El(e, t) {
	return Q(e).pipe(Mi(t), Ii(t))
}

function bl(e, t) {
	return Q(e).pipe(Mi(t), Ii(t))
}

function Il(e, t) {
	return new V(r => {
		let n = 0;
		return t.schedule(function() {
			n === e.length ? r.complete() : (r.next(e[n++]), r.closed || this.schedule())
		})
	})
}

function Ml(e, t) {
	return new V(r => {
		let n;
		return me(r, t, () => {
			n = e[wi](), me(r, t, () => {
				let i, o;
				try {
					({
						value: i,
						done: o
					} = n.next())
				} catch (s) {
					r.error(s);
					return
				}
				o ? r.complete() : r.next(i)
			}, 0, !0)
		}), () => T(n?.return) && n.return()
	})
}

function _i(e, t) {
	if (!e) throw new Error("Iterable cannot be null");
	return new V(r => {
		me(r, t, () => {
			let n = e[Symbol.asyncIterator]();
			me(r, t, () => {
				n.next().then(i => {
					i.done ? r.complete() : r.next(i.value)
				})
			}, 0, !0)
		})
	})
}

function _l(e, t) {
	return _i(Ei(e), t)
}

function Sl(e, t) {
	if (e != null) {
		if (vi(e)) return El(e, t);
		if (gi(e)) return Il(e, t);
		if (mi(e)) return bl(e, t);
		if (yi(e)) return _i(e, t);
		if (Ci(e)) return Ml(e, t);
		if (bi(e)) return _l(e, t)
	}
	throw Di(e)
}

function G(e, t) {
	return t ? Sl(e, t) : Q(e)
}

function b(...e) {
	let t = Dt(e);
	return G(e, t)
}

function yn(e, t) {
	let r = T(e) ? e : () => e,
		n = i => i.error(r());
	return new V(t ? i => t.schedule(n, 0, i) : n)
}

function Ns(e) {
	return !!e && (e instanceof V || T(e.lift) && T(e.subscribe))
}
var ot = dn(e => function() {
	e(this), this.name = "EmptyError", this.message = "no elements in sequence"
});

function A(e, t) {
	return L((r, n) => {
		let i = 0;
		r.subscribe(F(n, o => {
			n.next(e.call(t, o, i++))
		}))
	})
}
var {
	isArray: nm
} = Array;

function rm(e, t) {
	return nm(t) ? e(...t) : e(t)
}

function Si(e) {
	return A(t => rm(e, t))
}
var {
	isArray: im
} = Array, {
	getPrototypeOf: om,
	prototype: sm,
	keys: am
} = Object;

function Ti(e) {
	if (e.length === 1) {
		let t = e[0];
		if (im(t)) return {
			args: t,
			keys: null
		};
		if (um(t)) {
			let r = am(t);
			return {
				args: r.map(n => t[n]),
				keys: r
			}
		}
	}
	return {
		args: e,
		keys: null
	}
}

function um(e) {
	return e && typeof e == "object" && om(e) === sm
}

function xi(e, t) {
	return e.reduce((r, n, i) => (r[n] = t[i], r), {})
}

function ir(...e) {
	let t = Dt(e),
		r = pi(e),
		{
			args: n,
			keys: i
		} = Ti(e);
	if (n.length === 0) return G([], t);
	let o = new V(cm(n, t, i ? s => xi(i, s) : be));
	return r ? o.pipe(Si(r)) : o
}

function cm(e, t, r = be) {
	return n => {
		Tl(t, () => {
			let {
				length: i
			} = e, o = new Array(i), s = i, a = i;
			for (let u = 0; u < i; u++) Tl(t, () => {
				let c = G(e[u], t),
					l = !1;
				c.subscribe(F(n, d => {
					o[u] = d, l || (l = !0, a--), a || n.next(r(o.slice()))
				}, () => {
					--s || n.complete()
				}))
			}, n)
		}, n)
	}
}

function Tl(e, t, r) {
	e ? me(r, e, t) : t()
}

function xl(e, t, r, n, i, o, s, a) {
	let u = [],
		c = 0,
		l = 0,
		d = !1,
		f = () => {
			d && !u.length && !c && t.complete()
		},
		h = S => c < n ? m(S) : u.push(S),
		m = S => {
			o && t.next(S), c++;
			let E = !1;
			Q(r(S, l++)).subscribe(F(t, D => {
				i?.(D), o ? h(D) : t.next(D)
			}, () => {
				E = !0
			}, void 0, () => {
				if (E) try {
					for (c--; u.length && c < n;) {
						let D = u.shift();
						s ? me(t, s, () => m(D)) : m(D)
					}
					f()
				} catch (D) {
					t.error(D)
				}
			}))
		};
	return e.subscribe(F(t, h, () => {
		d = !0, f()
	})), () => {
		a?.()
	}
}

function K(e, t, r = 1 / 0) {
	return T(t) ? K((n, i) => A((o, s) => t(n, o, i, s))(Q(e(n, i))), r) : (typeof t == "number" && (r = t), L((n, i) => xl(n, i, e, r)))
}

function wt(e = 1 / 0) {
	return K(be, e)
}

function Al() {
	return wt(1)
}

function Dn(...e) {
	return Al()(G(e, Dt(e)))
}

function Ai(e) {
	return new V(t => {
		Q(e()).subscribe(t)
	})
}

function Rs(...e) {
	let t = pi(e),
		{
			args: r,
			keys: n
		} = Ti(e),
		i = new V(o => {
			let {
				length: s
			} = r;
			if (!s) {
				o.complete();
				return
			}
			let a = new Array(s),
				u = s,
				c = s;
			for (let l = 0; l < s; l++) {
				let d = !1;
				Q(r[l]).subscribe(F(o, f => {
					d || (d = !0, c--), a[l] = f
				}, () => u--, void 0, () => {
					(!u || !d) && (c || o.next(n ? xi(n, a) : a), o.complete())
				}))
			}
		});
	return t ? i.pipe(Si(t)) : i
}

function ve(e, t) {
	return L((r, n) => {
		let i = 0;
		r.subscribe(F(n, o => e.call(t, o, i++) && n.next(o)))
	})
}

function Ct(e) {
	return L((t, r) => {
		let n = null,
			i = !1,
			o;
		n = t.subscribe(F(r, void 0, void 0, s => {
			o = Q(e(s, Ct(e)(t))), n ? (n.unsubscribe(), n = null, o.subscribe(r)) : i = !0
		})), i && (n.unsubscribe(), n = null, o.subscribe(r))
	})
}

function Nl(e, t, r, n, i) {
	return (o, s) => {
		let a = r,
			u = t,
			c = 0;
		o.subscribe(F(s, l => {
			let d = c++;
			u = a ? e(u, l, d) : (a = !0, l), n && s.next(u)
		}, i && (() => {
			a && s.next(u), s.complete()
		})))
	}
}

function st(e, t) {
	return T(t) ? K(e, t, 1) : K(e, 1)
}

function Et(e) {
	return L((t, r) => {
		let n = !1;
		t.subscribe(F(r, i => {
			n = !0, r.next(i)
		}, () => {
			n || r.next(e), r.complete()
		}))
	})
}

function at(e) {
	return e <= 0 ? () => Ie : L((t, r) => {
		let n = 0;
		t.subscribe(F(r, i => {
			++n <= e && (r.next(i), e <= n && r.complete())
		}))
	})
}

function Os(e) {
	return A(() => e)
}

function Ni(e = lm) {
	return L((t, r) => {
		let n = !1;
		t.subscribe(F(r, i => {
			n = !0, r.next(i)
		}, () => n ? r.complete() : r.error(e())))
	})
}

function lm() {
	return new ot
}

function bt(e) {
	return L((t, r) => {
		try {
			t.subscribe(r)
		} finally {
			r.add(e)
		}
	})
}

function We(e, t) {
	let r = arguments.length >= 2;
	return n => n.pipe(e ? ve((i, o) => e(i, o, n)) : be, at(1), r ? Et(t) : Ni(() => new ot))
}

function wn(e) {
	return e <= 0 ? () => Ie : L((t, r) => {
		let n = [];
		t.subscribe(F(r, i => {
			n.push(i), e < n.length && n.shift()
		}, () => {
			for (let i of n) r.next(i);
			r.complete()
		}, void 0, () => {
			n = null
		}))
	})
}

function Fs(e, t) {
	let r = arguments.length >= 2;
	return n => n.pipe(e ? ve((i, o) => e(i, o, n)) : be, wn(1), r ? Et(t) : Ni(() => new ot))
}

function Ps(e, t) {
	return L(Nl(e, t, arguments.length >= 2, !0))
}

function ks(...e) {
	let t = Dt(e);
	return L((r, n) => {
		(t ? Dn(e, r, t) : Dn(e, r)).subscribe(n)
	})
}

function ye(e, t) {
	return L((r, n) => {
		let i = null,
			o = 0,
			s = !1,
			a = () => s && !i && n.complete();
		r.subscribe(F(n, u => {
			i?.unsubscribe();
			let c = 0,
				l = o++;
			Q(e(u, l)).subscribe(i = F(n, d => n.next(t ? t(u, d, l, c++) : d), () => {
				i = null, a()
			}))
		}, () => {
			s = !0, a()
		}))
	})
}

function Cn(e) {
	return L((t, r) => {
		Q(e).subscribe(F(r, () => r.complete(), rr)), !r.closed && t.subscribe(r)
	})
}

function ee(e, t, r) {
	let n = T(e) || t || r ? {
		next: e,
		error: t,
		complete: r
	} : e;
	return n ? L((i, o) => {
		var s;
		(s = n.subscribe) === null || s === void 0 || s.call(n);
		let a = !0;
		i.subscribe(F(o, u => {
			var c;
			(c = n.next) === null || c === void 0 || c.call(n, u), o.next(u)
		}, () => {
			var u;
			a = !1, (u = n.complete) === null || u === void 0 || u.call(n), o.complete()
		}, u => {
			var c;
			a = !1, (c = n.error) === null || c === void 0 || c.call(n, u), o.error(u)
		}, () => {
			var u, c;
			a && ((u = n.unsubscribe) === null || u === void 0 || u.call(n)), (c = n.finalize) === null || c === void 0 || c.call(n)
		}))
	}) : be
}
var pd = "https://g.co/ng/security#xss",
	I = class extends Error {
		constructor(t, r) {
			super(ao(t, r)), this.code = t
		}
	};

function ao(e, t) {
	return `${`NG0${Math.abs(e)}`}${t?": "+t:""}`
}

function Cr(e) {
	return {
		toString: e
	}.toString()
}
var Ri = "__parameters__";

function fm(e) {
	return function(...r) {
		if (e) {
			let n = e(...r);
			for (let i in n) this[i] = n[i]
		}
	}
}

function gd(e, t, r) {
	return Cr(() => {
		let n = fm(t);

		function i(...o) {
			if (this instanceof i) return n.apply(this, o), this;
			let s = new i(...o);
			return a.annotation = s, a;

			function a(u, c, l) {
				let d = u.hasOwnProperty(Ri) ? u[Ri] : Object.defineProperty(u, Ri, {
					value: []
				})[Ri];
				for (; d.length <= l;) d.push(null);
				return (d[l] = d[l] || []).push(s), u
			}
		}
		return r && (i.prototype = Object.create(r.prototype)), i.prototype.ngMetadataName = e, i.annotationCls = i, i
	})
}
var Ht = globalThis;

function H(e) {
	for (let t in e)
		if (e[t] === H) return t;
	throw Error("Could not find renamed property on target object.")
}

function hm(e, t) {
	for (let r in t) t.hasOwnProperty(r) && !e.hasOwnProperty(r) && (e[r] = t[r])
}

function De(e) {
	if (typeof e == "string") return e;
	if (Array.isArray(e)) return "[" + e.map(De).join(", ") + "]";
	if (e == null) return "" + e;
	if (e.overriddenName) return `${e.overriddenName}`;
	if (e.name) return `${e.name}`;
	let t = e.toString();
	if (t == null) return "" + t;
	let r = t.indexOf(`
`);
	return r === -1 ? t : t.substring(0, r)
}

function Rl(e, t) {
	return e == null || e === "" ? t === null ? "" : t : t == null || t === "" ? e : e + " " + t
}
var pm = H({
	__forward_ref__: H
});

function Er(e) {
	return e.__forward_ref__ = Er, e.toString = function() {
		return De(this())
	}, e
}

function pe(e) {
	return md(e) ? e() : e
}

function md(e) {
	return typeof e == "function" && e.hasOwnProperty(pm) && e.__forward_ref__ === Er
}

function C(e) {
	return {
		token: e.token,
		providedIn: e.providedIn || null,
		factory: e.factory,
		value: void 0
	}
}

function Xe(e) {
	return {
		providers: e.providers || [],
		imports: e.imports || []
	}
}

function uo(e) {
	return Ol(e, yd) || Ol(e, Dd)
}

function vd(e) {
	return uo(e) !== null
}

function Ol(e, t) {
	return e.hasOwnProperty(t) ? e[t] : null
}

function gm(e) {
	let t = e && (e[yd] || e[Dd]);
	return t || null
}

function Fl(e) {
	return e && (e.hasOwnProperty(Pl) || e.hasOwnProperty(mm)) ? e[Pl] : null
}
var yd = H({
		\u0275prov: H
	}),
	Pl = H({
		\u0275inj: H
	}),
	Dd = H({
		ngInjectableDef: H
	}),
	mm = H({
		ngInjectorDef: H
	}),
	w = class {
		constructor(t, r) {
			this._desc = t, this.ngMetadataName = "InjectionToken", this.\u0275prov = void 0, typeof r == "number" ? this.__NG_ELEMENT_ID__ = r : r !== void 0 && (this.\u0275prov = C({
				token: this,
				providedIn: r.providedIn || "root",
				factory: r.factory
			}))
		}
		get multi() {
			return this
		}
		toString() {
			return `InjectionToken ${this._desc}`
		}
	};

function wd(e) {
	return e && !!e.\u0275providers
}
var vm = H({
		\u0275cmp: H
	}),
	ym = H({
		\u0275dir: H
	}),
	Dm = H({
		\u0275pipe: H
	}),
	wm = H({
		\u0275mod: H
	}),
	Bi = H({
		\u0275fac: H
	}),
	or = H({
		__NG_ELEMENT_ID__: H
	}),
	kl = H({
		__NG_ENV_ID__: H
	});

function co(e) {
	return typeof e == "string" ? e : e == null ? "" : String(e)
}

function Cm(e) {
	return typeof e == "function" ? e.name || e.toString() : typeof e == "object" && e != null && typeof e.type == "function" ? e.type.name || e.type.toString() : co(e)
}

function Em(e, t) {
	let r = t ? `. Dependency path: ${t.join(" > ")} > ${e}` : "";
	throw new I(-200, e)
}

function Ya(e, t) {
	throw new I(-201, !1)
}
var O = function(e) {
		return e[e.Default = 0] = "Default", e[e.Host = 1] = "Host", e[e.Self = 2] = "Self", e[e.SkipSelf = 4] = "SkipSelf", e[e.Optional = 8] = "Optional", e
	}(O || {}),
	Xs;

function Cd() {
	return Xs
}

function Re(e) {
	let t = Xs;
	return Xs = e, t
}

function Ed(e, t, r) {
	let n = uo(e);
	if (n && n.providedIn == "root") return n.value === void 0 ? n.value = n.factory() : n.value;
	if (r & O.Optional) return null;
	if (t !== void 0) return t;
	Ya(e, "Injector")
}
var bm = {},
	sr = bm,
	ea = "__NG_DI_FLAG__",
	Hi = "ngTempTokenPath",
	Im = "ngTokenPath",
	Mm = /\n/gm,
	_m = "\u0275",
	Ll = "__source",
	_n;

function Sm() {
	return _n
}

function It(e) {
	let t = _n;
	return _n = e, t
}

function Tm(e, t = O.Default) {
	if (_n === void 0) throw new I(-203, !1);
	return _n === null ? Ed(e, void 0, t) : _n.get(e, t & O.Optional ? null : void 0, t)
}

function M(e, t = O.Default) {
	return (Cd() || Tm)(pe(e), t)
}

function p(e, t = O.Default) {
	return M(e, lo(t))
}

function lo(e) {
	return typeof e > "u" || typeof e == "number" ? e : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4)
}

function ta(e) {
	let t = [];
	for (let r = 0; r < e.length; r++) {
		let n = pe(e[r]);
		if (Array.isArray(n)) {
			if (n.length === 0) throw new I(900, !1);
			let i, o = O.Default;
			for (let s = 0; s < n.length; s++) {
				let a = n[s],
					u = xm(a);
				typeof u == "number" ? u === -1 ? i = a.token : o |= u : i = a
			}
			t.push(M(i, o))
		} else t.push(M(n))
	}
	return t
}

function bd(e, t) {
	return e[ea] = t, e.prototype[ea] = t, e
}

function xm(e) {
	return e[ea]
}

function Am(e, t, r, n) {
	let i = e[Hi];
	throw t[Ll] && i.unshift(t[Ll]), e.message = Nm(`
` + e.message, i, r, n), e[Im] = i, e[Hi] = null, e
}

function Nm(e, t, r, n = null) {
	e = e && e.charAt(0) === `
` && e.charAt(1) == _m ? e.slice(2) : e;
	let i = De(t);
	if (Array.isArray(t)) i = t.map(De).join(" -> ");
	else if (typeof t == "object") {
		let o = [];
		for (let s in t)
			if (t.hasOwnProperty(s)) {
				let a = t[s];
				o.push(s + ":" + (typeof a == "string" ? JSON.stringify(a) : De(a)))
			} i = `{${o.join(", ")}}`
	}
	return `${r}${n?"("+n+")":""}[${i}]: ${e.replace(Mm,`
  `)}`
}
var Qa = bd(gd("Optional"), 8);
var Id = bd(gd("SkipSelf"), 4);

function Tn(e, t) {
	let r = e.hasOwnProperty(Bi);
	return r ? e[Bi] : null
}

function Rm(e, t, r) {
	if (e.length !== t.length) return !1;
	for (let n = 0; n < e.length; n++) {
		let i = e[n],
			o = t[n];
		if (r && (i = r(i), o = r(o)), o !== i) return !1
	}
	return !0
}

function Om(e) {
	return e.flat(Number.POSITIVE_INFINITY)
}

function Ka(e, t) {
	e.forEach(r => Array.isArray(r) ? Ka(r, t) : t(r))
}

function Md(e, t, r) {
	t >= e.length ? e.push(r) : e.splice(t, 0, r)
}

function zi(e, t) {
	return t >= e.length - 1 ? e.pop() : e.splice(t, 1)[0]
}

function Fm(e, t, r, n) {
	let i = e.length;
	if (i == t) e.push(r, n);
	else if (i === 1) e.push(n, e[0]), e[0] = r;
	else {
		for (i--, e.push(e[i - 1], e[i]); i > t;) {
			let o = i - 2;
			e[i] = e[o], i--
		}
		e[t] = r, e[t + 1] = n
	}
}

function Pm(e, t, r) {
	let n = br(e, t);
	return n >= 0 ? e[n | 1] = r : (n = ~n, Fm(e, n, t, r)), n
}

function Ls(e, t) {
	let r = br(e, t);
	if (r >= 0) return e[r | 1]
}

function br(e, t) {
	return km(e, t, 1)
}

function km(e, t, r) {
	let n = 0,
		i = e.length >> r;
	for (; i !== n;) {
		let o = n + (i - n >> 1),
			s = e[o << r];
		if (t === s) return o << r;
		s > t ? i = o : n = o + 1
	}
	return ~(i << r)
}
var xn = {},
	Oe = [],
	An = new w(""),
	_d = new w("", -1),
	Sd = new w(""),
	Gi = class {
		get(t, r = sr) {
			if (r === sr) {
				let n = new Error(`NullInjectorError: No provider for ${De(t)}!`);
				throw n.name = "NullInjectorError", n
			}
			return r
		}
	},
	Td = function(e) {
		return e[e.OnPush = 0] = "OnPush", e[e.Default = 1] = "Default", e
	}(Td || {}),
	Qe = function(e) {
		return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e
	}(Qe || {}),
	le = function(e) {
		return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e
	}(le || {});

function Lm(e, t, r) {
	let n = e.length;
	for (;;) {
		let i = e.indexOf(t, r);
		if (i === -1) return i;
		if (i === 0 || e.charCodeAt(i - 1) <= 32) {
			let o = t.length;
			if (i + o === n || e.charCodeAt(i + o) <= 32) return i
		}
		r = i + 1
	}
}

function na(e, t, r) {
	let n = 0;
	for (; n < r.length;) {
		let i = r[n];
		if (typeof i == "number") {
			if (i !== 0) break;
			n++;
			let o = r[n++],
				s = r[n++],
				a = r[n++];
			e.setAttribute(t, s, a, o)
		} else {
			let o = i,
				s = r[++n];
			Vm(o) ? e.setProperty(t, o, s) : e.setAttribute(t, o, s), n++
		}
	}
	return n
}

function xd(e) {
	return e === 3 || e === 4 || e === 6
}

function Vm(e) {
	return e.charCodeAt(0) === 64
}

function ar(e, t) {
	if (!(t === null || t.length === 0))
		if (e === null || e.length === 0) e = t.slice();
		else {
			let r = -1;
			for (let n = 0; n < t.length; n++) {
				let i = t[n];
				typeof i == "number" ? r = i : r === 0 || (r === -1 || r === 2 ? Vl(e, r, i, null, t[++n]) : Vl(e, r, i, null, null))
			}
		} return e
}

function Vl(e, t, r, n, i) {
	let o = 0,
		s = e.length;
	if (t === -1) s = -1;
	else
		for (; o < e.length;) {
			let a = e[o++];
			if (typeof a == "number") {
				if (a === t) {
					s = -1;
					break
				} else if (a > t) {
					s = o - 1;
					break
				}
			}
		}
	for (; o < e.length;) {
		let a = e[o];
		if (typeof a == "number") break;
		if (a === r) {
			if (n === null) {
				i !== null && (e[o + 1] = i);
				return
			} else if (n === e[o + 1]) {
				e[o + 2] = i;
				return
			}
		}
		o++, n !== null && o++, i !== null && o++
	}
	s !== -1 && (e.splice(s, 0, t), o = s + 1), e.splice(o++, 0, r), n !== null && e.splice(o++, 0, n), i !== null && e.splice(o++, 0, i)
}
var Ad = "ng-template";

function jm(e, t, r, n) {
	let i = 0;
	if (n) {
		for (; i < t.length && typeof t[i] == "string"; i += 2)
			if (t[i] === "class" && Lm(t[i + 1].toLowerCase(), r, 0) !== -1) return !0
	} else if (Ja(e)) return !1;
	if (i = t.indexOf(1, i), i > -1) {
		let o;
		for (; ++i < t.length && typeof(o = t[i]) == "string";)
			if (o.toLowerCase() === r) return !0
	}
	return !1
}

function Ja(e) {
	return e.type === 4 && e.value !== Ad
}

function Um(e, t, r) {
	let n = e.type === 4 && !r ? Ad : e.value;
	return t === n
}

function $m(e, t, r) {
	let n = 4,
		i = e.attrs,
		o = i !== null ? zm(i) : 0,
		s = !1;
	for (let a = 0; a < t.length; a++) {
		let u = t[a];
		if (typeof u == "number") {
			if (!s && !Ve(n) && !Ve(u)) return !1;
			if (s && Ve(u)) continue;
			s = !1, n = u | n & 1;
			continue
		}
		if (!s)
			if (n & 4) {
				if (n = 2 | n & 1, u !== "" && !Um(e, u, r) || u === "" && t.length === 1) {
					if (Ve(n)) return !1;
					s = !0
				}
			} else if (n & 8) {
			if (i === null || !jm(e, i, u, r)) {
				if (Ve(n)) return !1;
				s = !0
			}
		} else {
			let c = t[++a],
				l = Bm(u, i, Ja(e), r);
			if (l === -1) {
				if (Ve(n)) return !1;
				s = !0;
				continue
			}
			if (c !== "") {
				let d;
				if (l > o ? d = "" : d = i[l + 1].toLowerCase(), n & 2 && c !== d) {
					if (Ve(n)) return !1;
					s = !0
				}
			}
		}
	}
	return Ve(n) || s
}

function Ve(e) {
	return (e & 1) === 0
}

function Bm(e, t, r, n) {
	if (t === null) return -1;
	let i = 0;
	if (n || !r) {
		let o = !1;
		for (; i < t.length;) {
			let s = t[i];
			if (s === e) return i;
			if (s === 3 || s === 6) o = !0;
			else if (s === 1 || s === 2) {
				let a = t[++i];
				for (; typeof a == "string";) a = t[++i];
				continue
			} else {
				if (s === 4) break;
				if (s === 0) {
					i += 4;
					continue
				}
			}
			i += o ? 1 : 2
		}
		return -1
	} else return Gm(t, e)
}

function Hm(e, t, r = !1) {
	for (let n = 0; n < t.length; n++)
		if ($m(e, t[n], r)) return !0;
	return !1
}

function zm(e) {
	for (let t = 0; t < e.length; t++) {
		let r = e[t];
		if (xd(r)) return t
	}
	return e.length
}

function Gm(e, t) {
	let r = e.indexOf(4);
	if (r > -1)
		for (r++; r < e.length;) {
			let n = e[r];
			if (typeof n == "number") return -1;
			if (n === t) return r;
			r++
		}
	return -1
}

function jl(e, t) {
	return e ? ":not(" + t.trim() + ")" : t
}

function qm(e) {
	let t = e[0],
		r = 1,
		n = 2,
		i = "",
		o = !1;
	for (; r < e.length;) {
		let s = e[r];
		if (typeof s == "string")
			if (n & 2) {
				let a = e[++r];
				i += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]"
			} else n & 8 ? i += "." + s : n & 4 && (i += " " + s);
		else i !== "" && !Ve(s) && (t += jl(o, i), i = ""), n = s, o = o || !Ve(n);
		r++
	}
	return i !== "" && (t += jl(o, i)), t
}

function Wm(e) {
	return e.map(qm).join(",")
}

function Zm(e) {
	let t = [],
		r = [],
		n = 1,
		i = 2;
	for (; n < e.length;) {
		let o = e[n];
		if (typeof o == "string") i === 2 ? o !== "" && t.push(o, e[++n]) : i === 8 && r.push(o);
		else {
			if (!Ve(i)) break;
			i = o
		}
		n++
	}
	return {
		attrs: t,
		classes: r
	}
}

function de(e) {
	return Cr(() => {
		let t = Pd(e),
			r = z(g({}, t), {
				decls: e.decls,
				vars: e.vars,
				template: e.template,
				consts: e.consts || null,
				ngContentSelectors: e.ngContentSelectors,
				onPush: e.changeDetection === Td.OnPush,
				directiveDefs: null,
				pipeDefs: null,
				dependencies: t.standalone && e.dependencies || null,
				getStandaloneInjector: null,
				signals: e.signals ?? !1,
				data: e.data || {},
				encapsulation: e.encapsulation || Qe.Emulated,
				styles: e.styles || Oe,
				_: null,
				schemas: e.schemas || null,
				tView: null,
				id: ""
			});
		kd(r);
		let n = e.dependencies;
		return r.directiveDefs = $l(n, !1), r.pipeDefs = $l(n, !0), r.id = Km(r), r
	})
}

function Ym(e) {
	return _t(e) || Nd(e)
}

function Qm(e) {
	return e !== null
}

function et(e) {
	return Cr(() => ({
		type: e.type,
		bootstrap: e.bootstrap || Oe,
		declarations: e.declarations || Oe,
		imports: e.imports || Oe,
		exports: e.exports || Oe,
		transitiveCompileScopes: null,
		schemas: e.schemas || null,
		id: e.id || null
	}))
}

function Ul(e, t) {
	if (e == null) return xn;
	let r = {};
	for (let n in e)
		if (e.hasOwnProperty(n)) {
			let i = e[n],
				o, s, a = le.None;
			Array.isArray(i) ? (a = i[0], o = i[1], s = i[2] ?? o) : (o = i, s = i), t ? (r[o] = a !== le.None ? [n, a] : n, t[o] = s) : r[o] = n
		} return r
}

function we(e) {
	return Cr(() => {
		let t = Pd(e);
		return kd(t), t
	})
}

function _t(e) {
	return e[vm] || null
}

function Nd(e) {
	return e[ym] || null
}

function Rd(e) {
	return e[Dm] || null
}

function Od(e) {
	let t = _t(e) || Nd(e) || Rd(e);
	return t !== null ? t.standalone : !1
}

function Fd(e, t) {
	let r = e[wm] || null;
	if (!r && t === !0) throw new Error(`Type ${De(e)} does not have '\u0275mod' property.`);
	return r
}

function Pd(e) {
	let t = {};
	return {
		type: e.type,
		providersResolver: null,
		factory: null,
		hostBindings: e.hostBindings || null,
		hostVars: e.hostVars || 0,
		hostAttrs: e.hostAttrs || null,
		contentQueries: e.contentQueries || null,
		declaredInputs: t,
		inputTransforms: null,
		inputConfig: e.inputs || xn,
		exportAs: e.exportAs || null,
		standalone: e.standalone === !0,
		signals: e.signals === !0,
		selectors: e.selectors || Oe,
		viewQuery: e.viewQuery || null,
		features: e.features || null,
		setInput: null,
		findHostDirectiveDefs: null,
		hostDirectives: null,
		inputs: Ul(e.inputs, t),
		outputs: Ul(e.outputs),
		debugInfo: null
	}
}

function kd(e) {
	e.features?.forEach(t => t(e))
}

function $l(e, t) {
	if (!e) return null;
	let r = t ? Rd : Ym;
	return () => (typeof e == "function" ? e() : e).map(n => r(n)).filter(Qm)
}

function Km(e) {
	let t = 0,
		r = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, e.consts, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery].join("|");
	for (let i of r) t = Math.imul(31, t) + i.charCodeAt(0) << 0;
	return t += 2147483648, "c" + t
}

function kn(e) {
	return {
		\u0275providers: e
	}
}

function Jm(...e) {
	return {
		\u0275providers: Ld(!0, e),
		\u0275fromNgModule: !0
	}
}

function Ld(e, ...t) {
	let r = [],
		n = new Set,
		i, o = s => {
			r.push(s)
		};
	return Ka(t, s => {
		let a = s;
		ra(a, o, [], n) && (i ||= [], i.push(a))
	}), i !== void 0 && Vd(i, o), r
}

function Vd(e, t) {
	for (let r = 0; r < e.length; r++) {
		let {
			ngModule: n,
			providers: i
		} = e[r];
		Xa(i, o => {
			t(o, n)
		})
	}
}

function ra(e, t, r, n) {
	if (e = pe(e), !e) return !1;
	let i = null,
		o = Fl(e),
		s = !o && _t(e);
	if (!o && !s) {
		let u = e.ngModule;
		if (o = Fl(u), o) i = u;
		else return !1
	} else {
		if (s && !s.standalone) return !1;
		i = e
	}
	let a = n.has(i);
	if (s) {
		if (a) return !1;
		if (n.add(i), s.dependencies) {
			let u = typeof s.dependencies == "function" ? s.dependencies() : s.dependencies;
			for (let c of u) ra(c, t, r, n)
		}
	} else if (o) {
		if (o.imports != null && !a) {
			n.add(i);
			let c;
			try {
				Ka(o.imports, l => {
					ra(l, t, r, n) && (c ||= [], c.push(l))
				})
			} finally {}
			c !== void 0 && Vd(c, t)
		}
		if (!a) {
			let c = Tn(i) || (() => new i);
			t({
				provide: i,
				useFactory: c,
				deps: Oe
			}, i), t({
				provide: Sd,
				useValue: i,
				multi: !0
			}, i), t({
				provide: An,
				useValue: () => M(i),
				multi: !0
			}, i)
		}
		let u = o.providers;
		if (u != null && !a) {
			let c = e;
			Xa(u, l => {
				t(l, c)
			})
		}
	} else return !1;
	return i !== e && e.providers !== void 0
}

function Xa(e, t) {
	for (let r of e) wd(r) && (r = r.\u0275providers), Array.isArray(r) ? Xa(r, t) : t(r)
}
var Xm = H({
	provide: String,
	useValue: H
});

function jd(e) {
	return e !== null && typeof e == "object" && Xm in e
}

function ev(e) {
	return !!(e && e.useExisting)
}

function tv(e) {
	return !!(e && e.useFactory)
}

function Nn(e) {
	return typeof e == "function"
}

function nv(e) {
	return !!e.useClass
}
var fo = new w(""),
	ki = {},
	rv = {},
	Vs;

function eu() {
	return Vs === void 0 && (Vs = new Gi), Vs
}
var ge = class {},
	ur = class extends ge {
		get destroyed() {
			return this._destroyed
		}
		constructor(t, r, n, i) {
			super(), this.parent = r, this.source = n, this.scopes = i, this.records = new Map, this._ngOnDestroyHooks = new Set, this._onDestroyHooks = [], this._destroyed = !1, oa(t, s => this.processProvider(s)), this.records.set(_d, En(void 0, this)), i.has("environment") && this.records.set(ge, En(void 0, this));
			let o = this.records.get(fo);
			o != null && typeof o.value == "string" && this.scopes.add(o.value), this.injectorDefTypes = new Set(this.get(Sd, Oe, O.Self))
		}
		destroy() {
			this.assertNotDestroyed(), this._destroyed = !0;
			let t = k(null);
			try {
				for (let n of this._ngOnDestroyHooks) n.ngOnDestroy();
				let r = this._onDestroyHooks;
				this._onDestroyHooks = [];
				for (let n of r) n()
			} finally {
				this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), k(t)
			}
		}
		onDestroy(t) {
			return this.assertNotDestroyed(), this._onDestroyHooks.push(t), () => this.removeOnDestroy(t)
		}
		runInContext(t) {
			this.assertNotDestroyed();
			let r = It(this),
				n = Re(void 0),
				i;
			try {
				return t()
			} finally {
				It(r), Re(n)
			}
		}
		get(t, r = sr, n = O.Default) {
			if (this.assertNotDestroyed(), t.hasOwnProperty(kl)) return t[kl](this);
			n = lo(n);
			let i, o = It(this),
				s = Re(void 0);
			try {
				if (!(n & O.SkipSelf)) {
					let u = this.records.get(t);
					if (u === void 0) {
						let c = uv(t) && uo(t);
						c && this.injectableDefInScope(c) ? u = En(ia(t), ki) : u = null, this.records.set(t, u)
					}
					if (u != null) return this.hydrate(t, u)
				}
				let a = n & O.Self ? eu() : this.parent;
				return r = n & O.Optional && r === sr ? null : r, a.get(t, r)
			} catch (a) {
				if (a.name === "NullInjectorError") {
					if ((a[Hi] = a[Hi] || []).unshift(De(t)), o) throw a;
					return Am(a, t, "R3InjectorError", this.source)
				} else throw a
			} finally {
				Re(s), It(o)
			}
		}
		resolveInjectorInitializers() {
			let t = k(null),
				r = It(this),
				n = Re(void 0),
				i;
			try {
				let o = this.get(An, Oe, O.Self);
				for (let s of o) s()
			} finally {
				It(r), Re(n), k(t)
			}
		}
		toString() {
			let t = [],
				r = this.records;
			for (let n of r.keys()) t.push(De(n));
			return `R3Injector[${t.join(", ")}]`
		}
		assertNotDestroyed() {
			if (this._destroyed) throw new I(205, !1)
		}
		processProvider(t) {
			t = pe(t);
			let r = Nn(t) ? t : pe(t && t.provide),
				n = ov(t);
			if (!Nn(t) && t.multi === !0) {
				let i = this.records.get(r);
				i || (i = En(void 0, ki, !0), i.factory = () => ta(i.multi), this.records.set(r, i)), r = t, i.multi.push(t)
			}
			this.records.set(r, n)
		}
		hydrate(t, r) {
			let n = k(null);
			try {
				return r.value === ki && (r.value = rv, r.value = r.factory()), typeof r.value == "object" && r.value && av(r.value) && this._ngOnDestroyHooks.add(r.value), r.value
			} finally {
				k(n)
			}
		}
		injectableDefInScope(t) {
			if (!t.providedIn) return !1;
			let r = pe(t.providedIn);
			return typeof r == "string" ? r === "any" || this.scopes.has(r) : this.injectorDefTypes.has(r)
		}
		removeOnDestroy(t) {
			let r = this._onDestroyHooks.indexOf(t);
			r !== -1 && this._onDestroyHooks.splice(r, 1)
		}
	};

function ia(e) {
	let t = uo(e),
		r = t !== null ? t.factory : Tn(e);
	if (r !== null) return r;
	if (e instanceof w) throw new I(204, !1);
	if (e instanceof Function) return iv(e);
	throw new I(204, !1)
}

function iv(e) {
	if (e.length > 0) throw new I(204, !1);
	let r = gm(e);
	return r !== null ? () => r.factory(e) : () => new e
}

function ov(e) {
	if (jd(e)) return En(void 0, e.useValue);
	{
		let t = Ud(e);
		return En(t, ki)
	}
}

function Ud(e, t, r) {
	let n;
	if (Nn(e)) {
		let i = pe(e);
		return Tn(i) || ia(i)
	} else if (jd(e)) n = () => pe(e.useValue);
	else if (tv(e)) n = () => e.useFactory(...ta(e.deps || []));
	else if (ev(e)) n = () => M(pe(e.useExisting));
	else {
		let i = pe(e && (e.useClass || e.provide));
		if (sv(e)) n = () => new i(...ta(e.deps));
		else return Tn(i) || ia(i)
	}
	return n
}

function En(e, t, r = !1) {
	return {
		factory: e,
		value: t,
		multi: r ? [] : void 0
	}
}

function sv(e) {
	return !!e.deps
}

function av(e) {
	return e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"
}

function uv(e) {
	return typeof e == "function" || typeof e == "object" && e instanceof w
}

function oa(e, t) {
	for (let r of e) Array.isArray(r) ? oa(r, t) : r && wd(r) ? oa(r.\u0275providers, t) : t(r)
}

function He(e, t) {
	e instanceof ur && e.assertNotDestroyed();
	let r, n = It(e),
		i = Re(void 0);
	try {
		return t()
	} finally {
		It(n), Re(i)
	}
}

function $d() {
	return Cd() !== void 0 || Sm() != null
}

function cv(e) {
	if (!$d()) throw new I(-203, !1)
}

function lv(e) {
	return typeof e == "function"
}
var lt = 0,
	x = 1,
	_ = 2,
	oe = 3,
	je = 4,
	ze = 5,
	cr = 6,
	lr = 7,
	ue = 8,
	Rn = 9,
	Ue = 10,
	se = 11,
	dr = 12,
	Bl = 13,
	Ln = 14,
	$e = 15,
	Ir = 16,
	bn = 17,
	ut = 18,
	ho = 19,
	Bd = 20,
	Mt = 21,
	js = 22,
	qt = 23,
	Be = 25,
	Hd = 1;
var Wt = 7,
	qi = 8,
	On = 9,
	ce = 10,
	tu = function(e) {
		return e[e.None = 0] = "None", e[e.HasTransplantedViews = 2] = "HasTransplantedViews", e
	}(tu || {});

function zt(e) {
	return Array.isArray(e) && typeof e[Hd] == "object"
}

function dt(e) {
	return Array.isArray(e) && e[Hd] === !0
}

function zd(e) {
	return (e.flags & 4) !== 0
}

function po(e) {
	return e.componentOffset > -1
}

function nu(e) {
	return (e.flags & 1) === 1
}

function St(e) {
	return !!e.template
}

function dv(e) {
	return (e[_] & 512) !== 0
}
var sa = class {
	constructor(t, r, n) {
		this.previousValue = t, this.currentValue = r, this.firstChange = n
	}
	isFirstChange() {
		return this.firstChange
	}
};

function Gd(e, t, r, n) {
	t !== null ? t.applyValueToInputSignal(t, n) : e[r] = n
}

function xt() {
	return qd
}

function qd(e) {
	return e.type.prototype.ngOnChanges && (e.setInput = hv), fv
}
xt.ngInherit = !0;

function fv() {
	let e = Zd(this),
		t = e?.current;
	if (t) {
		let r = e.previous;
		if (r === xn) e.previous = t;
		else
			for (let n in t) r[n] = t[n];
		e.current = null, this.ngOnChanges(t)
	}
}

function hv(e, t, r, n, i) {
	let o = this.declaredInputs[n],
		s = Zd(e) || pv(e, {
			previous: xn,
			current: null
		}),
		a = s.current || (s.current = {}),
		u = s.previous,
		c = u[o];
	a[o] = new sa(c && c.currentValue, r, u === xn), Gd(e, t, i, r)
}
var Wd = "__ngSimpleChanges__";

function Zd(e) {
	return e[Wd] || null
}

function pv(e, t) {
	return e[Wd] = t
}
var Hl = null;
var Ze = function(e, t, r) {
		Hl?.(e, t, r)
	},
	Yd = "svg",
	gv = "math",
	mv = !1;

function vv() {
	return mv
}

function Ke(e) {
	for (; Array.isArray(e);) e = e[lt];
	return e
}

function Qd(e, t) {
	return Ke(t[e])
}

function Fe(e, t) {
	return Ke(t[e.index])
}

function ru(e, t) {
	return e.data[t]
}

function At(e, t) {
	let r = t[e];
	return zt(r) ? r : r[lt]
}

function yv(e) {
	return (e[_] & 4) === 4
}

function iu(e) {
	return (e[_] & 128) === 128
}

function Dv(e) {
	return dt(e[oe])
}

function Wi(e, t) {
	return t == null ? null : e[t]
}

function Kd(e) {
	e[bn] = 0
}

function wv(e) {
	e[_] & 1024 || (e[_] |= 1024, iu(e) && fr(e))
}

function Cv(e, t) {
	for (; e > 0;) t = t[Ln], e--;
	return t
}

function ou(e) {
	return !!(e[_] & 9216 || e[qt]?.dirty)
}

function aa(e) {
	e[Ue].changeDetectionScheduler?.notify(1), ou(e) ? fr(e) : e[_] & 64 && (vv() ? (e[_] |= 1024, fr(e)) : e[Ue].changeDetectionScheduler?.notify())
}

function fr(e) {
	e[Ue].changeDetectionScheduler?.notify();
	let t = hr(e);
	for (; t !== null && !(t[_] & 8192 || (t[_] |= 8192, !iu(t)));) t = hr(t)
}

function Jd(e, t) {
	if ((e[_] & 256) === 256) throw new I(911, !1);
	e[Mt] === null && (e[Mt] = []), e[Mt].push(t)
}

function Ev(e, t) {
	if (e[Mt] === null) return;
	let r = e[Mt].indexOf(t);
	r !== -1 && e[Mt].splice(r, 1)
}

function hr(e) {
	let t = e[oe];
	return dt(t) ? t[oe] : t
}
var R = {
	lFrame: af(null),
	bindingsEnabled: !0,
	skipHydrationRootTNode: null
};

function bv() {
	return R.lFrame.elementDepthCount
}

function Iv() {
	R.lFrame.elementDepthCount++
}

function Mv() {
	R.lFrame.elementDepthCount--
}

function Xd() {
	return R.bindingsEnabled
}

function _v() {
	return R.skipHydrationRootTNode !== null
}

function Sv(e) {
	return R.skipHydrationRootTNode === e
}

function Tv() {
	R.skipHydrationRootTNode = null
}

function U() {
	return R.lFrame.lView
}

function _e() {
	return R.lFrame.tView
}

function go(e) {
	return R.lFrame.contextLView = e, e[ue]
}

function mo(e) {
	return R.lFrame.contextLView = null, e
}

function Ce() {
	let e = ef();
	for (; e !== null && e.type === 64;) e = e.parent;
	return e
}

function ef() {
	return R.lFrame.currentTNode
}

function xv() {
	let e = R.lFrame,
		t = e.currentTNode;
	return e.isParent ? t : t.parent
}

function Mr(e, t) {
	let r = R.lFrame;
	r.currentTNode = e, r.isParent = t
}

function tf() {
	return R.lFrame.isParent
}

function Av() {
	R.lFrame.isParent = !1
}

function nf() {
	let e = R.lFrame,
		t = e.bindingRootIndex;
	return t === -1 && (t = e.bindingRootIndex = e.tView.bindingStartIndex), t
}

function Nv(e) {
	return R.lFrame.bindingIndex = e
}

function _r() {
	return R.lFrame.bindingIndex++
}

function Rv(e) {
	let t = R.lFrame,
		r = t.bindingIndex;
	return t.bindingIndex = t.bindingIndex + e, r
}

function Ov() {
	return R.lFrame.inI18n
}

function Fv(e, t) {
	let r = R.lFrame;
	r.bindingIndex = r.bindingRootIndex = e, ua(t)
}

function Pv() {
	return R.lFrame.currentDirectiveIndex
}

function ua(e) {
	R.lFrame.currentDirectiveIndex = e
}

function kv(e) {
	let t = R.lFrame.currentDirectiveIndex;
	return t === -1 ? null : e[t]
}

function rf() {
	return R.lFrame.currentQueryIndex
}

function su(e) {
	R.lFrame.currentQueryIndex = e
}

function Lv(e) {
	let t = e[x];
	return t.type === 2 ? t.declTNode : t.type === 1 ? e[ze] : null
}

function of(e, t, r) {
	if (r & O.SkipSelf) {
		let i = t,
			o = e;
		for (; i = i.parent, i === null && !(r & O.Host);)
			if (i = Lv(o), i === null || (o = o[Ln], i.type & 10)) break;
		if (i === null) return !1;
		t = i, e = o
	}
	let n = R.lFrame = sf();
	return n.currentTNode = t, n.lView = e, !0
}

function au(e) {
	let t = sf(),
		r = e[x];
	R.lFrame = t, t.currentTNode = r.firstChild, t.lView = e, t.tView = r, t.contextLView = e, t.bindingIndex = r.bindingStartIndex, t.inI18n = !1
}

function sf() {
	let e = R.lFrame,
		t = e === null ? null : e.child;
	return t === null ? af(e) : t
}

function af(e) {
	let t = {
		currentTNode: null,
		isParent: !0,
		lView: null,
		tView: null,
		selectedIndex: -1,
		contextLView: null,
		elementDepthCount: 0,
		currentNamespace: null,
		currentDirectiveIndex: -1,
		bindingRootIndex: -1,
		bindingIndex: -1,
		currentQueryIndex: 0,
		parent: e,
		child: null,
		inI18n: !1
	};
	return e !== null && (e.child = t), t
}

function uf() {
	let e = R.lFrame;
	return R.lFrame = e.parent, e.currentTNode = null, e.lView = null, e
}
var cf = uf;

function uu() {
	let e = uf();
	e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e.currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e.currentQueryIndex = 0
}

function Vv(e) {
	return (R.lFrame.contextLView = Cv(e, R.lFrame.contextLView))[ue]
}

function en() {
	return R.lFrame.selectedIndex
}

function Zt(e) {
	R.lFrame.selectedIndex = e
}

function lf() {
	let e = R.lFrame;
	return ru(e.tView, e.selectedIndex)
}

function cu() {
	R.lFrame.currentNamespace = Yd
}

function lu() {
	jv()
}

function jv() {
	R.lFrame.currentNamespace = null
}

function Uv() {
	return R.lFrame.currentNamespace
}
var df = !0;

function du() {
	return df
}

function fu(e) {
	df = e
}

function $v(e, t, r) {
	let {
		ngOnChanges: n,
		ngOnInit: i,
		ngDoCheck: o
	} = t.type.prototype;
	if (n) {
		let s = qd(t);
		(r.preOrderHooks ??= []).push(e, s), (r.preOrderCheckHooks ??= []).push(e, s)
	}
	i && (r.preOrderHooks ??= []).push(0 - e, i), o && ((r.preOrderHooks ??= []).push(e, o), (r.preOrderCheckHooks ??= []).push(e, o))
}

function hu(e, t) {
	for (let r = t.directiveStart, n = t.directiveEnd; r < n; r++) {
		let o = e.data[r].type.prototype,
			{
				ngAfterContentInit: s,
				ngAfterContentChecked: a,
				ngAfterViewInit: u,
				ngAfterViewChecked: c,
				ngOnDestroy: l
			} = o;
		s && (e.contentHooks ??= []).push(-r, s), a && ((e.contentHooks ??= []).push(r, a), (e.contentCheckHooks ??= []).push(r, a)), u && (e.viewHooks ??= []).push(-r, u), c && ((e.viewHooks ??= []).push(r, c), (e.viewCheckHooks ??= []).push(r, c)), l != null && (e.destroyHooks ??= []).push(r, l)
	}
}

function Li(e, t, r) {
	ff(e, t, 3, r)
}

function Vi(e, t, r, n) {
	(e[_] & 3) === r && ff(e, t, r, n)
}

function Us(e, t) {
	let r = e[_];
	(r & 3) === t && (r &= 16383, r += 1, e[_] = r)
}

function ff(e, t, r, n) {
	let i = n !== void 0 ? e[bn] & 65535 : 0,
		o = n ?? -1,
		s = t.length - 1,
		a = 0;
	for (let u = i; u < s; u++)
		if (typeof t[u + 1] == "number") {
			if (a = t[u], n != null && a >= n) break
		} else t[u] < 0 && (e[bn] += 65536), (a < o || o == -1) && (Bv(e, r, t, u), e[bn] = (e[bn] & 4294901760) + u + 2), u++
}

function zl(e, t) {
	Ze(4, e, t);
	let r = k(null);
	try {
		t.call(e)
	} finally {
		k(r), Ze(5, e, t)
	}
}

function Bv(e, t, r, n) {
	let i = r[n] < 0,
		o = r[n + 1],
		s = i ? -r[n] : r[n],
		a = e[s];
	i ? e[_] >> 14 < e[bn] >> 16 && (e[_] & 3) === t && (e[_] += 16384, zl(a, o)) : zl(a, o)
}
var Sn = -1,
	Yt = class {
		constructor(t, r, n) {
			this.factory = t, this.resolving = !1, this.canSeeViewProviders = r, this.injectImpl = n
		}
	};

function Hv(e) {
	return e instanceof Yt
}

function zv(e) {
	return (e.flags & 8) !== 0
}

function Gv(e) {
	return (e.flags & 16) !== 0
}

function hf(e) {
	return e !== Sn
}

function Zi(e) {
	return e & 32767
}

function qv(e) {
	return e >> 16
}

function Yi(e, t) {
	let r = qv(e),
		n = t;
	for (; r > 0;) n = n[Ln], r--;
	return n
}
var ca = !0;

function Gl(e) {
	let t = ca;
	return ca = e, t
}
var Wv = 256,
	pf = Wv - 1,
	gf = 5,
	Zv = 0,
	Ye = {};

function Yv(e, t, r) {
	let n;
	typeof r == "string" ? n = r.charCodeAt(0) || 0 : r.hasOwnProperty(or) && (n = r[or]), n == null && (n = r[or] = Zv++);
	let i = n & pf,
		o = 1 << i;
	t.data[e + (i >> gf)] |= o
}

function Qi(e, t) {
	let r = mf(e, t);
	if (r !== -1) return r;
	let n = t[x];
	n.firstCreatePass && (e.injectorIndex = t.length, $s(n.data, e), $s(t, null), $s(n.blueprint, null));
	let i = pu(e, t),
		o = e.injectorIndex;
	if (hf(i)) {
		let s = Zi(i),
			a = Yi(i, t),
			u = a[x].data;
		for (let c = 0; c < 8; c++) t[o + c] = a[s + c] | u[s + c]
	}
	return t[o + 8] = i, o
}

function $s(e, t) {
	e.push(0, 0, 0, 0, 0, 0, 0, 0, t)
}

function mf(e, t) {
	return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex
}

function pu(e, t) {
	if (e.parent && e.parent.injectorIndex !== -1) return e.parent.injectorIndex;
	let r = 0,
		n = null,
		i = t;
	for (; i !== null;) {
		if (n = Cf(i), n === null) return Sn;
		if (r++, i = i[Ln], n.injectorIndex !== -1) return n.injectorIndex | r << 16
	}
	return Sn
}

function la(e, t, r) {
	Yv(e, t, r)
}

function Qv(e, t) {
	if (t === "class") return e.classes;
	if (t === "style") return e.styles;
	let r = e.attrs;
	if (r) {
		let n = r.length,
			i = 0;
		for (; i < n;) {
			let o = r[i];
			if (xd(o)) break;
			if (o === 0) i = i + 2;
			else if (typeof o == "number")
				for (i++; i < n && typeof r[i] == "string";) i++;
			else {
				if (o === t) return r[i + 1];
				i = i + 2
			}
		}
	}
	return null
}

function vf(e, t, r) {
	if (r & O.Optional || e !== void 0) return e;
	Ya(t, "NodeInjector")
}

function yf(e, t, r, n) {
	if (r & O.Optional && n === void 0 && (n = null), !(r & (O.Self | O.Host))) {
		let i = e[Rn],
			o = Re(void 0);
		try {
			return i ? i.get(t, n, r & O.Optional) : Ed(t, n, r & O.Optional)
		} finally {
			Re(o)
		}
	}
	return vf(n, t, r)
}

function Df(e, t, r, n = O.Default, i) {
	if (e !== null) {
		if (t[_] & 2048 && !(n & O.Self)) {
			let s = ey(e, t, r, n, Ye);
			if (s !== Ye) return s
		}
		let o = wf(e, t, r, n, Ye);
		if (o !== Ye) return o
	}
	return yf(t, r, n, i)
}

function wf(e, t, r, n, i) {
	let o = Jv(r);
	if (typeof o == "function") {
		if (!of(t, e, n)) return n & O.Host ? vf(i, r, n) : yf(t, r, n, i);
		try {
			let s;
			if (s = o(n), s == null && !(n & O.Optional)) Ya(r);
			else return s
		} finally {
			cf()
		}
	} else if (typeof o == "number") {
		let s = null,
			a = mf(e, t),
			u = Sn,
			c = n & O.Host ? t[$e][ze] : null;
		for ((a === -1 || n & O.SkipSelf) && (u = a === -1 ? pu(e, t) : t[a + 8], u === Sn || !Wl(n, !1) ? a = -1 : (s = t[x], a = Zi(u), t = Yi(u, t))); a !== -1;) {
			let l = t[x];
			if (ql(o, a, l.data)) {
				let d = Kv(a, t, r, s, n, c);
				if (d !== Ye) return d
			}
			u = t[a + 8], u !== Sn && Wl(n, t[x].data[a + 8] === c) && ql(o, a, t) ? (s = l, a = Zi(u), t = Yi(u, t)) : a = -1
		}
	}
	return i
}

function Kv(e, t, r, n, i, o) {
	let s = t[x],
		a = s.data[e + 8],
		u = n == null ? po(a) && ca : n != s && (a.type & 3) !== 0,
		c = i & O.Host && o === a,
		l = ji(a, s, r, u, c);
	return l !== null ? Qt(t, s, l, a) : Ye
}

function ji(e, t, r, n, i) {
	let o = e.providerIndexes,
		s = t.data,
		a = o & 1048575,
		u = e.directiveStart,
		c = e.directiveEnd,
		l = o >> 20,
		d = n ? a : a + l,
		f = i ? a + l : c;
	for (let h = d; h < f; h++) {
		let m = s[h];
		if (h < u && r === m || h >= u && m.type === r) return h
	}
	if (i) {
		let h = s[u];
		if (h && St(h) && h.type === r) return u
	}
	return null
}

function Qt(e, t, r, n) {
	let i = e[r],
		o = t.data;
	if (Hv(i)) {
		let s = i;
		s.resolving && Em(Cm(o[r]));
		let a = Gl(s.canSeeViewProviders);
		s.resolving = !0;
		let u, c = s.injectImpl ? Re(s.injectImpl) : null,
			l = of(e, n, O.Default);
		try {
			i = e[r] = s.factory(void 0, o, e, n), t.firstCreatePass && r >= n.directiveStart && $v(r, o[r], t)
		} finally {
			c !== null && Re(c), Gl(a), s.resolving = !1, cf()
		}
	}
	return i
}

function Jv(e) {
	if (typeof e == "string") return e.charCodeAt(0) || 0;
	let t = e.hasOwnProperty(or) ? e[or] : void 0;
	return typeof t == "number" ? t >= 0 ? t & pf : Xv : t
}

function ql(e, t, r) {
	let n = 1 << e;
	return !!(r[t + (e >> gf)] & n)
}

function Wl(e, t) {
	return !(e & O.Self) && !(e & O.Host && t)
}
var Gt = class {
	constructor(t, r) {
		this._tNode = t, this._lView = r
	}
	get(t, r, n) {
		return Df(this._tNode, this._lView, t, lo(n), r)
	}
};

function Xv() {
	return new Gt(Ce(), U())
}

function Sr(e) {
	return Cr(() => {
		let t = e.prototype.constructor,
			r = t[Bi] || da(t),
			n = Object.prototype,
			i = Object.getPrototypeOf(e.prototype).constructor;
		for (; i && i !== n;) {
			let o = i[Bi] || da(i);
			if (o && o !== r) return o;
			i = Object.getPrototypeOf(i)
		}
		return o => new o
	})
}

function da(e) {
	return md(e) ? () => {
		let t = da(pe(e));
		return t && t()
	} : Tn(e)
}

function ey(e, t, r, n, i) {
	let o = e,
		s = t;
	for (; o !== null && s !== null && s[_] & 2048 && !(s[_] & 512);) {
		let a = wf(o, s, r, n | O.Self, Ye);
		if (a !== Ye) return a;
		let u = o.parent;
		if (!u) {
			let c = s[Bd];
			if (c) {
				let l = c.get(r, Ye, n);
				if (l !== Ye) return l
			}
			u = Cf(s), s = s[Ln]
		}
		o = u
	}
	return i
}

function Cf(e) {
	let t = e[x],
		r = t.type;
	return r === 2 ? t.declTNode : r === 1 ? e[ze] : null
}

function gu(e) {
	return Qv(Ce(), e)
}

function Zl(e, t = null, r = null, n) {
	let i = Ef(e, t, r, n);
	return i.resolveInjectorInitializers(), i
}

function Ef(e, t = null, r = null, n, i = new Set) {
	let o = [r || Oe, Jm(e)];
	return n = n || (typeof e == "object" ? void 0 : De(e)), new ur(o, t || eu(), n || null, i)
}
var ft = (() => {
	let t = class t {
		static create(n, i) {
			if (Array.isArray(n)) return Zl({
				name: ""
			}, i, n, "");
			{
				let o = n.name ?? "";
				return Zl({
					name: o
				}, n.parent, n.providers, o)
			}
		}
	};
	t.THROW_IF_NOT_FOUND = sr, t.NULL = new Gi, t.\u0275prov = C({
		token: t,
		providedIn: "any",
		factory: () => M(_d)
	}), t.__NG_ELEMENT_ID__ = -1;
	let e = t;
	return e
})();
var ty = "ngOriginalError";

function Bs(e) {
	return e[ty]
}
var Je = class {
		constructor() {
			this._console = console
		}
		handleError(t) {
			let r = this._findOriginalError(t);
			this._console.error("ERROR", t), r && this._console.error("ORIGINAL ERROR", r)
		}
		_findOriginalError(t) {
			let r = t && Bs(t);
			for (; r && Bs(r);) r = Bs(r);
			return r || null
		}
	},
	bf = new w("", {
		providedIn: "root",
		factory: () => p(Je).handleError.bind(void 0)
	}),
	mu = (() => {
		let t = class t {};
		t.__NG_ELEMENT_ID__ = ny, t.__NG_ENV_ID__ = n => n;
		let e = t;
		return e
	})(),
	fa = class extends mu {
		constructor(t) {
			super(), this._lView = t
		}
		onDestroy(t) {
			return Jd(this._lView, t), () => Ev(this._lView, t)
		}
	};

function ny() {
	return new fa(U())
}

function ry() {
	return Vn(Ce(), U())
}

function Vn(e, t) {
	return new Se(Fe(e, t))
}
var Se = (() => {
	let t = class t {
		constructor(n) {
			this.nativeElement = n
		}
	};
	t.__NG_ELEMENT_ID__ = ry;
	let e = t;
	return e
})();

function iy(e) {
	return e instanceof Se ? e.nativeElement : e
}
var ha = class extends X {
	constructor(t = !1) {
		super(), this.destroyRef = void 0, this.__isAsync = t, $d() && (this.destroyRef = p(mu, {
			optional: !0
		}) ?? void 0)
	}
	emit(t) {
		let r = k(null);
		try {
			super.next(t)
		} finally {
			k(r)
		}
	}
	subscribe(t, r, n) {
		let i = t,
			o = r || (() => null),
			s = n;
		if (t && typeof t == "object") {
			let u = t;
			i = u.next?.bind(u), o = u.error?.bind(u), s = u.complete?.bind(u)
		}
		this.__isAsync && (o = Hs(o), i && (i = Hs(i)), s && (s = Hs(s)));
		let a = super.subscribe({
			next: i,
			error: o,
			complete: s
		});
		return t instanceof J && t.add(a), a
	}
};

function Hs(e) {
	return t => {
		setTimeout(e, void 0, t)
	}
}
var ie = ha;

function oy() {
	return this._results[Symbol.iterator]()
}
var pa = class e {
	get changes() {
		return this._changes ??= new ie
	}
	constructor(t = !1) {
		this._emitDistinctChangesOnly = t, this.dirty = !0, this._onDirty = void 0, this._results = [], this._changesDetected = !1, this._changes = void 0, this.length = 0, this.first = void 0, this.last = void 0;
		let r = e.prototype;
		r[Symbol.iterator] || (r[Symbol.iterator] = oy)
	}
	get(t) {
		return this._results[t]
	}
	map(t) {
		return this._results.map(t)
	}
	filter(t) {
		return this._results.filter(t)
	}
	find(t) {
		return this._results.find(t)
	}
	reduce(t, r) {
		return this._results.reduce(t, r)
	}
	forEach(t) {
		this._results.forEach(t)
	}
	some(t) {
		return this._results.some(t)
	}
	toArray() {
		return this._results.slice()
	}
	toString() {
		return this._results.toString()
	}
	reset(t, r) {
		this.dirty = !1;
		let n = Om(t);
		(this._changesDetected = !Rm(this._results, n, r)) && (this._results = n, this.length = n.length, this.last = n[this.length - 1], this.first = n[0])
	}
	notifyOnChanges() {
		this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.emit(this)
	}
	onDirty(t) {
		this._onDirty = t
	}
	setDirty() {
		this.dirty = !0, this._onDirty?.()
	}
	destroy() {
		this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe())
	}
};

function If(e) {
	return (e.flags & 128) === 128
}
var Mf = new Map,
	sy = 0;

function ay() {
	return sy++
}

function uy(e) {
	Mf.set(e[ho], e)
}

function cy(e) {
	Mf.delete(e[ho])
}
var Yl = "__ngContext__";

function Kt(e, t) {
	zt(t) ? (e[Yl] = t[ho], uy(t)) : e[Yl] = t
}

function _f(e) {
	return Tf(e[dr])
}

function Sf(e) {
	return Tf(e[je])
}

function Tf(e) {
	for (; e !== null && !dt(e);) e = e[je];
	return e
}
var ga;

function xf(e) {
	ga = e
}

function ly() {
	if (ga !== void 0) return ga;
	if (typeof document < "u") return document;
	throw new I(210, !1)
}
var vu = new w("", {
		providedIn: "root",
		factory: () => dy
	}),
	dy = "ng",
	yu = new w(""),
	tt = new w("", {
		providedIn: "platform",
		factory: () => "unknown"
	});
var Du = new w("", {
	providedIn: "root",
	factory: () => ly().body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null
});
var fy = "h",
	hy = "b";
var py = () => null;

function wu(e, t, r = !1) {
	return py(e, t, r)
}
var Af = !1,
	gy = new w("", {
		providedIn: "root",
		factory: () => Af
	});
var Oi;

function my() {
	if (Oi === void 0 && (Oi = null, Ht.trustedTypes)) try {
		Oi = Ht.trustedTypes.createPolicy("angular#unsafe-bypass", {
			createHTML: e => e,
			createScript: e => e,
			createScriptURL: e => e
		})
	} catch {}
	return Oi
}

function Ql(e) {
	return my()?.createScriptURL(e) || e
}
var Ki = class {
	constructor(t) {
		this.changingThisBreaksApplicationSecurity = t
	}
	toString() {
		return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${pd})`
	}
};

function Tr(e) {
	return e instanceof Ki ? e.changingThisBreaksApplicationSecurity : e
}

function Cu(e, t) {
	let r = vy(e);
	if (r != null && r !== t) {
		if (r === "ResourceURL" && t === "URL") return !0;
		throw new Error(`Required a safe ${t}, got a ${r} (see ${pd})`)
	}
	return r === t
}

function vy(e) {
	return e instanceof Ki && e.getTypeName() || null
}
var yy = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;

function Nf(e) {
	return e = String(e), e.match(yy) ? e : "unsafe:" + e
}
var vo = function(e) {
	return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e
}(vo || {});

function Dy(e) {
	let t = Of();
	return t ? t.sanitize(vo.URL, e) || "" : Cu(e, "URL") ? Tr(e) : Nf(co(e))
}

function wy(e) {
	let t = Of();
	if (t) return Ql(t.sanitize(vo.RESOURCE_URL, e) || "");
	if (Cu(e, "ResourceURL")) return Ql(Tr(e));
	throw new I(904, !1)
}

function Cy(e, t) {
	return t === "src" && (e === "embed" || e === "frame" || e === "iframe" || e === "media" || e === "script") || t === "href" && (e === "base" || e === "link") ? wy : Dy
}

function Rf(e, t, r) {
	return Cy(t, r)(e)
}

function Of() {
	let e = U();
	return e && e[Ue].sanitizer
}

function Ff(e) {
	return e instanceof Function ? e() : e
}

function Ey(e) {
	return (e ?? p(ft)).get(tt) === "browser"
}
var ct = function(e) {
		return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e
	}(ct || {}),
	by;

function Eu(e, t) {
	return by(e, t)
}

function In(e, t, r, n, i) {
	if (n != null) {
		let o, s = !1;
		dt(n) ? o = n : zt(n) && (s = !0, n = n[lt]);
		let a = Ke(n);
		e === 0 && r !== null ? i == null ? Vf(t, r, a) : Ji(t, r, a, i || null, !0) : e === 1 && r !== null ? Ji(t, r, a, i || null, !0) : e === 2 ? Uy(t, a, s) : e === 3 && t.destroyNode(a), o != null && By(t, e, o, r, i)
	}
}

function Iy(e, t) {
	return e.createText(t)
}

function My(e, t, r) {
	e.setValue(t, r)
}

function Pf(e, t, r) {
	return e.createElement(t, r)
}

function _y(e, t) {
	kf(e, t), t[lt] = null, t[ze] = null
}

function Sy(e, t, r, n, i, o) {
	n[lt] = i, n[ze] = t, Do(e, n, r, 1, i, o)
}

function kf(e, t) {
	t[Ue].changeDetectionScheduler?.notify(1), Do(e, t, t[se], 2, null, null)
}

function Ty(e) {
	let t = e[dr];
	if (!t) return zs(e[x], e);
	for (; t;) {
		let r = null;
		if (zt(t)) r = t[dr];
		else {
			let n = t[ce];
			n && (r = n)
		}
		if (!r) {
			for (; t && !t[je] && t !== e;) zt(t) && zs(t[x], t), t = t[oe];
			t === null && (t = e), zt(t) && zs(t[x], t), r = t && t[je]
		}
		t = r
	}
}

function xy(e, t, r, n) {
	let i = ce + n,
		o = r.length;
	n > 0 && (r[i - 1][je] = t), n < o - ce ? (t[je] = r[i], Md(r, ce + n, t)) : (r.push(t), t[je] = null), t[oe] = r;
	let s = t[Ir];
	s !== null && r !== s && Ay(s, t);
	let a = t[ut];
	a !== null && a.insertView(e), aa(t), t[_] |= 128
}

function Ay(e, t) {
	let r = e[On],
		i = t[oe][oe][$e];
	t[$e] !== i && (e[_] |= tu.HasTransplantedViews), r === null ? e[On] = [t] : r.push(t)
}

function Lf(e, t) {
	let r = e[On],
		n = r.indexOf(t);
	r.splice(n, 1)
}

function pr(e, t) {
	if (e.length <= ce) return;
	let r = ce + t,
		n = e[r];
	if (n) {
		let i = n[Ir];
		i !== null && i !== e && Lf(i, n), t > 0 && (e[r - 1][je] = n[je]);
		let o = zi(e, ce + t);
		_y(n[x], n);
		let s = o[ut];
		s !== null && s.detachView(o[x]), n[oe] = null, n[je] = null, n[_] &= -129
	}
	return n
}

function yo(e, t) {
	if (!(t[_] & 256)) {
		let r = t[se];
		r.destroyNode && Do(e, t, r, 3, null, null), Ty(t)
	}
}

function zs(e, t) {
	if (t[_] & 256) return;
	let r = k(null);
	try {
		t[_] &= -129, t[_] |= 256, t[qt] && sl(t[qt]), Ry(e, t), Ny(e, t), t[x].type === 1 && t[se].destroy();
		let n = t[Ir];
		if (n !== null && dt(t[oe])) {
			n !== t[oe] && Lf(n, t);
			let i = t[ut];
			i !== null && i.detachView(e)
		}
		cy(t)
	} finally {
		k(r)
	}
}

function Ny(e, t) {
	let r = e.cleanup,
		n = t[lr];
	if (r !== null)
		for (let o = 0; o < r.length - 1; o += 2)
			if (typeof r[o] == "string") {
				let s = r[o + 3];
				s >= 0 ? n[s]() : n[-s].unsubscribe(), o += 2
			} else {
				let s = n[r[o + 1]];
				r[o].call(s)
			} n !== null && (t[lr] = null);
	let i = t[Mt];
	if (i !== null) {
		t[Mt] = null;
		for (let o = 0; o < i.length; o++) {
			let s = i[o];
			s()
		}
	}
}

function Ry(e, t) {
	let r;
	if (e != null && (r = e.destroyHooks) != null)
		for (let n = 0; n < r.length; n += 2) {
			let i = t[r[n]];
			if (!(i instanceof Yt)) {
				let o = r[n + 1];
				if (Array.isArray(o))
					for (let s = 0; s < o.length; s += 2) {
						let a = i[o[s]],
							u = o[s + 1];
						Ze(4, a, u);
						try {
							u.call(a)
						} finally {
							Ze(5, a, u)
						}
					} else {
						Ze(4, i, o);
						try {
							o.call(i)
						} finally {
							Ze(5, i, o)
						}
					}
			}
		}
}

function Oy(e, t, r) {
	return Fy(e, t.parent, r)
}

function Fy(e, t, r) {
	let n = t;
	for (; n !== null && n.type & 40;) t = n, n = t.parent;
	if (n === null) return r[lt];
	{
		let {
			componentOffset: i
		} = n;
		if (i > -1) {
			let {
				encapsulation: o
			} = e.data[n.directiveStart + i];
			if (o === Qe.None || o === Qe.Emulated) return null
		}
		return Fe(n, r)
	}
}

function Ji(e, t, r, n, i) {
	e.insertBefore(t, r, n, i)
}

function Vf(e, t, r) {
	e.appendChild(t, r)
}

function Kl(e, t, r, n, i) {
	n !== null ? Ji(e, t, r, n, i) : Vf(e, t, r)
}

function Py(e, t, r, n) {
	e.removeChild(t, r, n)
}

function bu(e, t) {
	return e.parentNode(t)
}

function ky(e, t) {
	return e.nextSibling(t)
}

function Ly(e, t, r) {
	return jy(e, t, r)
}

function Vy(e, t, r) {
	return e.type & 40 ? Fe(e, r) : null
}
var jy = Vy,
	Jl;

function Iu(e, t, r, n) {
	let i = Oy(e, n, t),
		o = t[se],
		s = n.parent || t[ze],
		a = Ly(s, n, t);
	if (i != null)
		if (Array.isArray(r))
			for (let u = 0; u < r.length; u++) Kl(o, i, r[u], a, !1);
		else Kl(o, i, r, a, !1);
	Jl !== void 0 && Jl(o, n, t, r, i)
}

function Ui(e, t) {
	if (t !== null) {
		let r = t.type;
		if (r & 3) return Fe(t, e);
		if (r & 4) return ma(-1, e[t.index]);
		if (r & 8) {
			let n = t.child;
			if (n !== null) return Ui(e, n);
			{
				let i = e[t.index];
				return dt(i) ? ma(-1, i) : Ke(i)
			}
		} else {
			if (r & 32) return Eu(t, e)() || Ke(e[t.index]);
			{
				let n = jf(e, t);
				if (n !== null) {
					if (Array.isArray(n)) return n[0];
					let i = hr(e[$e]);
					return Ui(i, n)
				} else return Ui(e, t.next)
			}
		}
	}
	return null
}

function jf(e, t) {
	if (t !== null) {
		let n = e[$e][ze],
			i = t.projection;
		return n.projection[i]
	}
	return null
}

function ma(e, t) {
	let r = ce + e + 1;
	if (r < t.length) {
		let n = t[r],
			i = n[x].firstChild;
		if (i !== null) return Ui(n, i)
	}
	return t[Wt]
}

function Uy(e, t, r) {
	let n = bu(e, t);
	n && Py(e, n, t, r)
}

function Mu(e, t, r, n, i, o, s) {
	for (; r != null;) {
		let a = n[r.index],
			u = r.type;
		if (s && t === 0 && (a && Kt(Ke(a), n), r.flags |= 2), (r.flags & 32) !== 32)
			if (u & 8) Mu(e, t, r.child, n, i, o, !1), In(t, e, i, a, o);
			else if (u & 32) {
			let c = Eu(r, n),
				l;
			for (; l = c();) In(t, e, i, l, o);
			In(t, e, i, a, o)
		} else u & 16 ? $y(e, t, n, r, i, o) : In(t, e, i, a, o);
		r = s ? r.projectionNext : r.next
	}
}

function Do(e, t, r, n, i, o) {
	Mu(r, n, e.firstChild, t, i, o, !1)
}

function $y(e, t, r, n, i, o) {
	let s = r[$e],
		u = s[ze].projection[n.projection];
	if (Array.isArray(u))
		for (let c = 0; c < u.length; c++) {
			let l = u[c];
			In(t, e, i, l, o)
		} else {
			let c = u,
				l = s[oe];
			If(n) && (c.flags |= 128), Mu(e, t, c, l, i, o, !0)
		}
}

function By(e, t, r, n, i) {
	let o = r[Wt],
		s = Ke(r);
	o !== s && In(t, e, n, o, i);
	for (let a = ce; a < r.length; a++) {
		let u = r[a];
		Do(u[x], u, e, t, n, o)
	}
}

function Hy(e, t, r, n, i) {
	if (t) i ? e.addClass(r, n) : e.removeClass(r, n);
	else {
		let o = n.indexOf("-") === -1 ? void 0 : ct.DashCase;
		i == null ? e.removeStyle(r, n, o) : (typeof i == "string" && i.endsWith("!important") && (i = i.slice(0, -10), o |= ct.Important), e.setStyle(r, n, i, o))
	}
}

function zy(e, t, r) {
	e.setAttribute(t, "style", r)
}

function Uf(e, t, r) {
	r === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", r)
}

function $f(e, t, r) {
	let {
		mergedAttrs: n,
		classes: i,
		styles: o
	} = r;
	n !== null && na(e, t, n), i !== null && Uf(e, t, i), o !== null && zy(e, t, o)
}
var Nt = {};

function j(e = 1) {
	Bf(_e(), U(), en() + e, !1)
}

function Bf(e, t, r, n) {
	if (!n)
		if ((t[_] & 3) === 3) {
			let o = e.preOrderCheckHooks;
			o !== null && Li(t, o, r)
		} else {
			let o = e.preOrderHooks;
			o !== null && Vi(t, o, 0, r)
		} Zt(r)
}

function $(e, t = O.Default) {
	let r = U();
	if (r === null) return M(e, t);
	let n = Ce();
	return Df(n, r, pe(e), t)
}

function Hf() {
	let e = "invalid";
	throw new Error(e)
}

function zf(e, t, r, n, i, o) {
	let s = k(null);
	try {
		let a = null;
		i & le.SignalBased && (a = t[n][nl]), a !== null && a.transformFn !== void 0 && (o = a.transformFn(o)), i & le.HasDecoratorInputTransform && (o = e.inputTransforms[n].call(t, o)), e.setInput !== null ? e.setInput(t, a, o, r, n) : Gd(t, a, n, o)
	} finally {
		k(s)
	}
}

function Gy(e, t) {
	let r = e.hostBindingOpCodes;
	if (r !== null) try {
		for (let n = 0; n < r.length; n++) {
			let i = r[n];
			if (i < 0) Zt(~i);
			else {
				let o = i,
					s = r[++n],
					a = r[++n];
				Fv(s, o);
				let u = t[o];
				a(2, u)
			}
		}
	} finally {
		Zt(-1)
	}
}

function wo(e, t, r, n, i, o, s, a, u, c, l) {
	let d = t.blueprint.slice();
	return d[lt] = i, d[_] = n | 4 | 128 | 8 | 64, (c !== null || e && e[_] & 2048) && (d[_] |= 2048), Kd(d), d[oe] = d[Ln] = e, d[ue] = r, d[Ue] = s || e && e[Ue], d[se] = a || e && e[se], d[Rn] = u || e && e[Rn] || null, d[ze] = o, d[ho] = ay(), d[cr] = l, d[Bd] = c, d[$e] = t.type == 2 ? e[$e] : d, d
}

function Co(e, t, r, n, i) {
	let o = e.data[t];
	if (o === null) o = qy(e, t, r, n, i), Ov() && (o.flags |= 32);
	else if (o.type & 64) {
		o.type = r, o.value = n, o.attrs = i;
		let s = xv();
		o.injectorIndex = s === null ? -1 : s.injectorIndex
	}
	return Mr(o, !0), o
}

function qy(e, t, r, n, i) {
	let o = ef(),
		s = tf(),
		a = s ? o : o && o.parent,
		u = e.data[t] = Jy(e, a, r, t, n, i);
	return e.firstChild === null && (e.firstChild = u), o !== null && (s ? o.child == null && u.parent !== null && (o.child = u) : o.next === null && (o.next = u, u.prev = o)), u
}

function Gf(e, t, r, n) {
	if (r === 0) return -1;
	let i = t.length;
	for (let o = 0; o < r; o++) t.push(n), e.blueprint.push(n), e.data.push(null);
	return i
}

function qf(e, t, r, n, i) {
	let o = en(),
		s = n & 2;
	try {
		Zt(-1), s && t.length > Be && Bf(e, t, Be, !1), Ze(s ? 2 : 0, i), r(n, i)
	} finally {
		Zt(o), Ze(s ? 3 : 1, i)
	}
}

function Wf(e, t, r) {
	if (zd(t)) {
		let n = k(null);
		try {
			let i = t.directiveStart,
				o = t.directiveEnd;
			for (let s = i; s < o; s++) {
				let a = e.data[s];
				if (a.contentQueries) {
					let u = r[s];
					a.contentQueries(1, u, s)
				}
			}
		} finally {
			k(n)
		}
	}
}

function Zf(e, t, r) {
	Xd() && (oD(e, t, r, Fe(r, t)), (r.flags & 64) === 64 && Xf(e, t, r))
}

function Yf(e, t, r = Fe) {
	let n = t.localNames;
	if (n !== null) {
		let i = t.index + 1;
		for (let o = 0; o < n.length; o += 2) {
			let s = n[o + 1],
				a = s === -1 ? r(t, e) : e[s];
			e[i++] = a
		}
	}
}

function Qf(e) {
	let t = e.tView;
	return t === null || t.incompleteFirstPass ? e.tView = _u(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t
}

function _u(e, t, r, n, i, o, s, a, u, c, l) {
	let d = Be + n,
		f = d + i,
		h = Wy(d, f),
		m = typeof c == "function" ? c() : c;
	return h[x] = {
		type: e,
		blueprint: h,
		template: r,
		queries: null,
		viewQuery: a,
		declTNode: t,
		data: h.slice().fill(null, d),
		bindingStartIndex: d,
		expandoStartIndex: f,
		hostBindingOpCodes: null,
		firstCreatePass: !0,
		firstUpdatePass: !0,
		staticViewQueries: !1,
		staticContentQueries: !1,
		preOrderHooks: null,
		preOrderCheckHooks: null,
		contentHooks: null,
		contentCheckHooks: null,
		viewHooks: null,
		viewCheckHooks: null,
		destroyHooks: null,
		cleanup: null,
		contentQueries: null,
		components: null,
		directiveRegistry: typeof o == "function" ? o() : o,
		pipeRegistry: typeof s == "function" ? s() : s,
		firstChild: null,
		schemas: u,
		consts: m,
		incompleteFirstPass: !1,
		ssrId: l
	}
}

function Wy(e, t) {
	let r = [];
	for (let n = 0; n < t; n++) r.push(n < e ? null : Nt);
	return r
}

function Zy(e, t, r, n) {
	let o = n.get(gy, Af) || r === Qe.ShadowDom,
		s = e.selectRootElement(t, o);
	return Yy(s), s
}

function Yy(e) {
	Qy(e)
}
var Qy = () => null;

function Ky(e, t, r, n) {
	let i = nh(t);
	i.push(r), e.firstCreatePass && rh(e).push(n, i.length - 1)
}

function Jy(e, t, r, n, i, o) {
	let s = t ? t.injectorIndex : -1,
		a = 0;
	return _v() && (a |= 128), {
		type: r,
		index: n,
		insertBeforeIndex: null,
		injectorIndex: s,
		directiveStart: -1,
		directiveEnd: -1,
		directiveStylingLast: -1,
		componentOffset: -1,
		propertyBindings: null,
		flags: a,
		providerIndexes: 0,
		value: i,
		attrs: o,
		mergedAttrs: null,
		localNames: null,
		initialInputs: void 0,
		inputs: null,
		outputs: null,
		tView: null,
		next: null,
		prev: null,
		projectionNext: null,
		child: null,
		parent: t,
		projection: null,
		styles: null,
		stylesWithoutHost: null,
		residualStyles: void 0,
		classes: null,
		classesWithoutHost: null,
		residualClasses: void 0,
		classBindings: 0,
		styleBindings: 0
	}
}

function Xl(e, t, r, n, i) {
	for (let o in t) {
		if (!t.hasOwnProperty(o)) continue;
		let s = t[o];
		if (s === void 0) continue;
		n ??= {};
		let a, u = le.None;
		Array.isArray(s) ? (a = s[0], u = s[1]) : a = s;
		let c = o;
		if (i !== null) {
			if (!i.hasOwnProperty(o)) continue;
			c = i[o]
		}
		e === 0 ? ed(n, r, c, a, u) : ed(n, r, c, a)
	}
	return n
}

function ed(e, t, r, n, i) {
	let o;
	e.hasOwnProperty(r) ? (o = e[r]).push(t, n) : o = e[r] = [t, n], i !== void 0 && o.push(i)
}

function Xy(e, t, r) {
	let n = t.directiveStart,
		i = t.directiveEnd,
		o = e.data,
		s = t.attrs,
		a = [],
		u = null,
		c = null;
	for (let l = n; l < i; l++) {
		let d = o[l],
			f = r ? r.get(d) : null,
			h = f ? f.inputs : null,
			m = f ? f.outputs : null;
		u = Xl(0, d.inputs, l, u, h), c = Xl(1, d.outputs, l, c, m);
		let S = u !== null && s !== null && !Ja(t) ? mD(u, l, s) : null;
		a.push(S)
	}
	u !== null && (u.hasOwnProperty("class") && (t.flags |= 8), u.hasOwnProperty("style") && (t.flags |= 16)), t.initialInputs = a, t.inputs = u, t.outputs = c
}

function eD(e) {
	return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e
}

function tD(e, t, r, n, i, o, s, a) {
	let u = Fe(t, r),
		c = t.inputs,
		l;
	!a && c != null && (l = c[n]) ? (Su(e, r, l, n, i), po(t) && nD(r, t.index)) : t.type & 3 ? (n = eD(n), i = s != null ? s(i, t.value || "", n) : i, o.setProperty(u, n, i)) : t.type & 12
}

function nD(e, t) {
	let r = At(t, e);
	r[_] & 16 || (r[_] |= 64)
}

function Kf(e, t, r, n) {
	if (Xd()) {
		let i = n === null ? null : {
				"": -1
			},
			o = aD(e, r),
			s, a;
		o === null ? s = a = null : [s, a] = o, s !== null && Jf(e, t, r, s, i, a), i && uD(r, n, i)
	}
	r.mergedAttrs = ar(r.mergedAttrs, r.attrs)
}

function Jf(e, t, r, n, i, o) {
	for (let c = 0; c < n.length; c++) la(Qi(r, t), e, n[c].type);
	lD(r, e.data.length, n.length);
	for (let c = 0; c < n.length; c++) {
		let l = n[c];
		l.providersResolver && l.providersResolver(l)
	}
	let s = !1,
		a = !1,
		u = Gf(e, t, n.length, null);
	for (let c = 0; c < n.length; c++) {
		let l = n[c];
		r.mergedAttrs = ar(r.mergedAttrs, l.hostAttrs), dD(e, r, t, u, l), cD(u, l, i), l.contentQueries !== null && (r.flags |= 4), (l.hostBindings !== null || l.hostAttrs !== null || l.hostVars !== 0) && (r.flags |= 64);
		let d = l.type.prototype;
		!s && (d.ngOnChanges || d.ngOnInit || d.ngDoCheck) && ((e.preOrderHooks ??= []).push(r.index), s = !0), !a && (d.ngOnChanges || d.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(r.index), a = !0), u++
	}
	Xy(e, r, o)
}

function rD(e, t, r, n, i) {
	let o = i.hostBindings;
	if (o) {
		let s = e.hostBindingOpCodes;
		s === null && (s = e.hostBindingOpCodes = []);
		let a = ~t.index;
		iD(s) != a && s.push(a), s.push(r, n, o)
	}
}

function iD(e) {
	let t = e.length;
	for (; t > 0;) {
		let r = e[--t];
		if (typeof r == "number" && r < 0) return r
	}
	return 0
}

function oD(e, t, r, n) {
	let i = r.directiveStart,
		o = r.directiveEnd;
	po(r) && fD(t, r, e.data[i + r.componentOffset]), e.firstCreatePass || Qi(r, t), Kt(n, t);
	let s = r.initialInputs;
	for (let a = i; a < o; a++) {
		let u = e.data[a],
			c = Qt(t, e, a, r);
		if (Kt(c, t), s !== null && gD(t, a - i, c, u, r, s), St(u)) {
			let l = At(r.index, t);
			l[ue] = Qt(t, e, a, r)
		}
	}
}

function Xf(e, t, r) {
	let n = r.directiveStart,
		i = r.directiveEnd,
		o = r.index,
		s = Pv();
	try {
		Zt(o);
		for (let a = n; a < i; a++) {
			let u = e.data[a],
				c = t[a];
			ua(a), (u.hostBindings !== null || u.hostVars !== 0 || u.hostAttrs !== null) && sD(u, c)
		}
	} finally {
		Zt(-1), ua(s)
	}
}

function sD(e, t) {
	e.hostBindings !== null && e.hostBindings(1, t)
}

function aD(e, t) {
	let r = e.directiveRegistry,
		n = null,
		i = null;
	if (r)
		for (let o = 0; o < r.length; o++) {
			let s = r[o];
			if (Hm(t, s.selectors, !1))
				if (n || (n = []), St(s))
					if (s.findHostDirectiveDefs !== null) {
						let a = [];
						i = i || new Map, s.findHostDirectiveDefs(s, a, i), n.unshift(...a, s);
						let u = a.length;
						va(e, t, u)
					} else n.unshift(s), va(e, t, 0);
			else i = i || new Map, s.findHostDirectiveDefs?.(s, n, i), n.push(s)
		}
	return n === null ? null : [n, i]
}

function va(e, t, r) {
	t.componentOffset = r, (e.components ??= []).push(t.index)
}

function uD(e, t, r) {
	if (t) {
		let n = e.localNames = [];
		for (let i = 0; i < t.length; i += 2) {
			let o = r[t[i + 1]];
			if (o == null) throw new I(-301, !1);
			n.push(t[i], o)
		}
	}
}

function cD(e, t, r) {
	if (r) {
		if (t.exportAs)
			for (let n = 0; n < t.exportAs.length; n++) r[t.exportAs[n]] = e;
		St(t) && (r[""] = e)
	}
}

function lD(e, t, r) {
	e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + r, e.providerIndexes = t
}

function dD(e, t, r, n, i) {
	e.data[n] = i;
	let o = i.factory || (i.factory = Tn(i.type, !0)),
		s = new Yt(o, St(i), $);
	e.blueprint[n] = s, r[n] = s, rD(e, t, n, Gf(e, r, i.hostVars, Nt), i)
}

function fD(e, t, r) {
	let n = Fe(t, e),
		i = Qf(r),
		o = e[Ue].rendererFactory,
		s = 16;
	r.signals ? s = 4096 : r.onPush && (s = 64);
	let a = Eo(e, wo(e, i, null, s, n, t, null, o.createRenderer(n, r), null, null, null));
	e[t.index] = a
}

function hD(e, t, r, n, i, o) {
	let s = Fe(e, t);
	pD(t[se], s, o, e.value, r, n, i)
}

function pD(e, t, r, n, i, o, s) {
	if (o == null) e.removeAttribute(t, i, r);
	else {
		let a = s == null ? co(o) : s(o, n || "", i);
		e.setAttribute(t, i, a, r)
	}
}

function gD(e, t, r, n, i, o) {
	let s = o[t];
	if (s !== null)
		for (let a = 0; a < s.length;) {
			let u = s[a++],
				c = s[a++],
				l = s[a++],
				d = s[a++];
			zf(n, r, u, c, l, d)
		}
}

function mD(e, t, r) {
	let n = null,
		i = 0;
	for (; i < r.length;) {
		let o = r[i];
		if (o === 0) {
			i += 4;
			continue
		} else if (o === 5) {
			i += 2;
			continue
		}
		if (typeof o == "number") break;
		if (e.hasOwnProperty(o)) {
			n === null && (n = []);
			let s = e[o];
			for (let a = 0; a < s.length; a += 3)
				if (s[a] === t) {
					n.push(o, s[a + 1], s[a + 2], r[i + 1]);
					break
				}
		}
		i += 2
	}
	return n
}

function eh(e, t, r, n) {
	return [e, !0, 0, t, null, n, null, r, null, null]
}

function th(e, t) {
	let r = e.contentQueries;
	if (r !== null) {
		let n = k(null);
		try {
			for (let i = 0; i < r.length; i += 2) {
				let o = r[i],
					s = r[i + 1];
				if (s !== -1) {
					let a = e.data[s];
					su(o), a.contentQueries(2, t[s], s)
				}
			}
		} finally {
			k(n)
		}
	}
}

function Eo(e, t) {
	return e[dr] ? e[Bl][je] = t : e[dr] = t, e[Bl] = t, t
}

function ya(e, t, r) {
	su(0);
	let n = k(null);
	try {
		t(e, r)
	} finally {
		k(n)
	}
}

function nh(e) {
	return e[lr] || (e[lr] = [])
}

function rh(e) {
	return e.cleanup || (e.cleanup = [])
}

function ih(e, t) {
	let r = e[Rn],
		n = r ? r.get(Je, null) : null;
	n && n.handleError(t)
}

function Su(e, t, r, n, i) {
	for (let o = 0; o < r.length;) {
		let s = r[o++],
			a = r[o++],
			u = r[o++],
			c = t[s],
			l = e.data[s];
		zf(l, c, n, a, u, i)
	}
}

function vD(e, t, r) {
	let n = Qd(t, e);
	My(e[se], n, r)
}

function yD(e, t) {
	let r = At(t, e),
		n = r[x];
	DD(n, r);
	let i = r[lt];
	i !== null && r[cr] === null && (r[cr] = wu(i, r[Rn])), Tu(n, r, r[ue])
}

function DD(e, t) {
	for (let r = t.length; r < e.blueprint.length; r++) t.push(e.blueprint[r])
}

function Tu(e, t, r) {
	au(t);
	try {
		let n = e.viewQuery;
		n !== null && ya(1, n, r);
		let i = e.template;
		i !== null && qf(e, t, i, 1, r), e.firstCreatePass && (e.firstCreatePass = !1), t[ut]?.finishViewCreation(e), e.staticContentQueries && th(e, t), e.staticViewQueries && ya(2, e.viewQuery, r);
		let o = e.components;
		o !== null && wD(t, o)
	} catch (n) {
		throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), n
	} finally {
		t[_] &= -5, uu()
	}
}

function wD(e, t) {
	for (let r = 0; r < t.length; r++) yD(e, t[r])
}

function bo(e, t, r, n) {
	let i = k(null);
	try {
		let o = t.tView,
			a = e[_] & 4096 ? 4096 : 16,
			u = wo(e, o, r, a, null, t, null, null, n?.injector ?? null, n?.embeddedViewInjector ?? null, n?.dehydratedView ?? null),
			c = e[t.index];
		u[Ir] = c;
		let l = e[ut];
		return l !== null && (u[ut] = l.createEmbeddedView(o)), Tu(o, u, r), u
	} finally {
		k(i)
	}
}

function oh(e, t) {
	let r = ce + t;
	if (r < e.length) return e[r]
}

function gr(e, t) {
	return !t || t.firstChild === null || If(e)
}

function Io(e, t, r, n = !0) {
	let i = t[x];
	if (xy(i, t, e, r), n) {
		let s = ma(r, e),
			a = t[se],
			u = bu(a, e[Wt]);
		u !== null && Sy(i, e[ze], a, t, u, s)
	}
	let o = t[cr];
	o !== null && o.firstChild !== null && (o.firstChild = null)
}

function sh(e, t) {
	let r = pr(e, t);
	return r !== void 0 && yo(r[x], r), r
}

function Xi(e, t, r, n, i = !1) {
	for (; r !== null;) {
		let o = t[r.index];
		o !== null && n.push(Ke(o)), dt(o) && CD(o, n);
		let s = r.type;
		if (s & 8) Xi(e, t, r.child, n);
		else if (s & 32) {
			let a = Eu(r, t),
				u;
			for (; u = a();) n.push(u)
		} else if (s & 16) {
			let a = jf(t, r);
			if (Array.isArray(a)) n.push(...a);
			else {
				let u = hr(t[$e]);
				Xi(u[x], u, a, n, !0)
			}
		}
		r = i ? r.projectionNext : r.next
	}
	return n
}

function CD(e, t) {
	for (let r = ce; r < e.length; r++) {
		let n = e[r],
			i = n[x].firstChild;
		i !== null && Xi(n[x], n, i, t)
	}
	e[Wt] !== e[lt] && t.push(e[Wt])
}
var ah = [];

function ED(e) {
	return e[qt] ?? bD(e)
}

function bD(e) {
	let t = ah.pop() ?? Object.create(MD);
	return t.lView = e, t
}

function ID(e) {
	e.lView[qt] !== e && (e.lView = null, ah.push(e))
}
var MD = z(g({}, rl), {
		consumerIsAlwaysLive: !0,
		consumerMarkedDirty: e => {
			fr(e.lView)
		},
		consumerOnSignalRead() {
			this.lView[qt] = this
		}
	}),
	uh = 100;

function ch(e, t = !0, r = 0) {
	let n = e[Ue],
		i = n.rendererFactory,
		o = !1;
	o || i.begin?.();
	try {
		_D(e, r)
	} catch (s) {
		throw t && ih(e, s), s
	} finally {
		o || (i.end?.(), n.inlineEffectRunner?.flush())
	}
}

function _D(e, t) {
	Da(e, t);
	let r = 0;
	for (; ou(e);) {
		if (r === uh) throw new I(103, !1);
		r++, Da(e, 1)
	}
}

function SD(e, t, r, n) {
	let i = t[_];
	if ((i & 256) === 256) return;
	let o = !1;
	!o && t[Ue].inlineEffectRunner?.flush(), au(t);
	let s = null,
		a = null;
	!o && TD(e) && (a = ED(t), s = il(a));
	try {
		Kd(t), Nv(e.bindingStartIndex), r !== null && qf(e, t, r, 2, n);
		let u = (i & 3) === 3;
		if (!o)
			if (u) {
				let d = e.preOrderCheckHooks;
				d !== null && Li(t, d, null)
			} else {
				let d = e.preOrderHooks;
				d !== null && Vi(t, d, 0, null), Us(t, 0)
			} if (xD(t), lh(t, 0), e.contentQueries !== null && th(e, t), !o)
			if (u) {
				let d = e.contentCheckHooks;
				d !== null && Li(t, d)
			} else {
				let d = e.contentHooks;
				d !== null && Vi(t, d, 1), Us(t, 1)
			} Gy(e, t);
		let c = e.components;
		c !== null && fh(t, c, 0);
		let l = e.viewQuery;
		if (l !== null && ya(2, l, n), !o)
			if (u) {
				let d = e.viewCheckHooks;
				d !== null && Li(t, d)
			} else {
				let d = e.viewHooks;
				d !== null && Vi(t, d, 2), Us(t, 2)
			} if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[js]) {
			for (let d of t[js]) d();
			t[js] = null
		}
		o || (t[_] &= -73)
	} catch (u) {
		throw fr(t), u
	} finally {
		a !== null && (ol(a, s), ID(a)), uu()
	}
}

function TD(e) {
	return e.type !== 2
}

function lh(e, t) {
	for (let r = _f(e); r !== null; r = Sf(r))
		for (let n = ce; n < r.length; n++) {
			let i = r[n];
			dh(i, t)
		}
}

function xD(e) {
	for (let t = _f(e); t !== null; t = Sf(t)) {
		if (!(t[_] & tu.HasTransplantedViews)) continue;
		let r = t[On];
		for (let n = 0; n < r.length; n++) {
			let i = r[n],
				o = i[oe];
			wv(i)
		}
	}
}

function AD(e, t, r) {
	let n = At(t, e);
	dh(n, r)
}

function dh(e, t) {
	iu(e) && Da(e, t)
}

function Da(e, t) {
	let n = e[x],
		i = e[_],
		o = e[qt],
		s = !!(t === 0 && i & 16);
	if (s ||= !!(i & 64 && t === 0), s ||= !!(i & 1024), s ||= !!(o?.dirty && Ds(o)), o && (o.dirty = !1), e[_] &= -9217, s) SD(n, e, n.template, e[ue]);
	else if (i & 8192) {
		lh(e, 1);
		let a = n.components;
		a !== null && fh(e, a, 1)
	}
}

function fh(e, t, r) {
	for (let n = 0; n < t.length; n++) AD(e, t[n], r)
}

function xu(e) {
	for (e[Ue].changeDetectionScheduler?.notify(); e;) {
		e[_] |= 64;
		let t = hr(e);
		if (dv(e) && !t) return e;
		e = t
	}
	return null
}
var Jt = class {
		get rootNodes() {
			let t = this._lView,
				r = t[x];
			return Xi(r, t, r.firstChild, [])
		}
		constructor(t, r, n = !0) {
			this._lView = t, this._cdRefInjectingView = r, this.notifyErrorHandler = n, this._appRef = null, this._attachedToViewContainer = !1
		}
		get context() {
			return this._lView[ue]
		}
		set context(t) {
			this._lView[ue] = t
		}
		get destroyed() {
			return (this._lView[_] & 256) === 256
		}
		destroy() {
			if (this._appRef) this._appRef.detachView(this);
			else if (this._attachedToViewContainer) {
				let t = this._lView[oe];
				if (dt(t)) {
					let r = t[qi],
						n = r ? r.indexOf(this) : -1;
					n > -1 && (pr(t, n), zi(r, n))
				}
				this._attachedToViewContainer = !1
			}
			yo(this._lView[x], this._lView)
		}
		onDestroy(t) {
			Jd(this._lView, t)
		}
		markForCheck() {
			xu(this._cdRefInjectingView || this._lView)
		}
		detach() {
			this._lView[_] &= -129
		}
		reattach() {
			aa(this._lView), this._lView[_] |= 128
		}
		detectChanges() {
			this._lView[_] |= 1024, ch(this._lView, this.notifyErrorHandler)
		}
		checkNoChanges() {}
		attachToViewContainerRef() {
			if (this._appRef) throw new I(902, !1);
			this._attachedToViewContainer = !0
		}
		detachFromAppRef() {
			this._appRef = null, kf(this._lView[x], this._lView)
		}
		attachToAppRef(t) {
			if (this._attachedToViewContainer) throw new I(902, !1);
			this._appRef = t, aa(this._lView)
		}
	},
	mr = (() => {
		let t = class t {};
		t.__NG_ELEMENT_ID__ = OD;
		let e = t;
		return e
	})(),
	ND = mr,
	RD = class extends ND {
		constructor(t, r, n) {
			super(), this._declarationLView = t, this._declarationTContainer = r, this.elementRef = n
		}
		get ssrId() {
			return this._declarationTContainer.tView?.ssrId || null
		}
		createEmbeddedView(t, r) {
			return this.createEmbeddedViewImpl(t, r)
		}
		createEmbeddedViewImpl(t, r, n) {
			let i = bo(this._declarationLView, this._declarationTContainer, t, {
				embeddedViewInjector: r,
				dehydratedView: n
			});
			return new Jt(i)
		}
	};

function OD() {
	return Au(Ce(), U())
}

function Au(e, t) {
	return e.type & 4 ? new RD(t, e, Vn(e, t)) : null
}
var aA = new RegExp(`^(\\d+)*(${hy}|${fy})*(.*)`);
var FD = () => null;

function vr(e, t) {
	return FD(e, t)
}
var eo = class {},
	wa = class {},
	to = class {};

function PD(e) {
	let t = Error(`No component factory found for ${De(e)}.`);
	return t[kD] = e, t
}
var kD = "ngComponent";
var Ca = class {
		resolveComponentFactory(t) {
			throw PD(t)
		}
	},
	Mo = (() => {
		let t = class t {};
		t.NULL = new Ca;
		let e = t;
		return e
	})(),
	yr = class {},
	ht = (() => {
		let t = class t {
			constructor() {
				this.destroyNode = null
			}
		};
		t.__NG_ELEMENT_ID__ = () => LD();
		let e = t;
		return e
	})();

function LD() {
	let e = U(),
		t = Ce(),
		r = At(t.index, e);
	return (zt(r) ? r : e)[se]
}
var VD = (() => {
		let t = class t {};
		t.\u0275prov = C({
			token: t,
			providedIn: "root",
			factory: () => null
		});
		let e = t;
		return e
	})(),
	Gs = {};
var td = new Set;

function jn(e) {
	td.has(e) || (td.add(e), performance?.mark?.("mark_feature_usage", {
		detail: {
			feature: e
		}
	}))
}

function nd(...e) {}

function jD() {
	let e = typeof Ht.requestAnimationFrame == "function",
		t = Ht[e ? "requestAnimationFrame" : "setTimeout"],
		r = Ht[e ? "cancelAnimationFrame" : "clearTimeout"];
	if (typeof Zone < "u" && t && r) {
		let n = t[Zone.__symbol__("OriginalDelegate")];
		n && (t = n);
		let i = r[Zone.__symbol__("OriginalDelegate")];
		i && (r = i)
	}
	return {
		nativeRequestAnimationFrame: t,
		nativeCancelAnimationFrame: r
	}
}
var Z = class e {
		constructor({
			enableLongStackTrace: t = !1,
			shouldCoalesceEventChangeDetection: r = !1,
			shouldCoalesceRunChangeDetection: n = !1
		}) {
			if (this.hasPendingMacrotasks = !1, this.hasPendingMicrotasks = !1, this.isStable = !0, this.onUnstable = new ie(!1), this.onMicrotaskEmpty = new ie(!1), this.onStable = new ie(!1), this.onError = new ie(!1), typeof Zone > "u") throw new I(908, !1);
			Zone.assertZonePatched();
			let i = this;
			i._nesting = 0, i._outer = i._inner = Zone.current, Zone.TaskTrackingZoneSpec && (i._inner = i._inner.fork(new Zone.TaskTrackingZoneSpec)), t && Zone.longStackTraceZoneSpec && (i._inner = i._inner.fork(Zone.longStackTraceZoneSpec)), i.shouldCoalesceEventChangeDetection = !n && r, i.shouldCoalesceRunChangeDetection = n, i.lastRequestAnimationFrameId = -1, i.nativeRequestAnimationFrame = jD().nativeRequestAnimationFrame, BD(i)
		}
		static isInAngularZone() {
			return typeof Zone < "u" && Zone.current.get("isAngularZone") === !0
		}
		static assertInAngularZone() {
			if (!e.isInAngularZone()) throw new I(909, !1)
		}
		static assertNotInAngularZone() {
			if (e.isInAngularZone()) throw new I(909, !1)
		}
		run(t, r, n) {
			return this._inner.run(t, r, n)
		}
		runTask(t, r, n, i) {
			let o = this._inner,
				s = o.scheduleEventTask("NgZoneEvent: " + i, t, UD, nd, nd);
			try {
				return o.runTask(s, r, n)
			} finally {
				o.cancelTask(s)
			}
		}
		runGuarded(t, r, n) {
			return this._inner.runGuarded(t, r, n)
		}
		runOutsideAngular(t) {
			return this._outer.run(t)
		}
	},
	UD = {};

function Nu(e) {
	if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable) try {
		e._nesting++, e.onMicrotaskEmpty.emit(null)
	} finally {
		if (e._nesting--, !e.hasPendingMicrotasks) try {
			e.runOutsideAngular(() => e.onStable.emit(null))
		} finally {
			e.isStable = !0
		}
	}
}

function $D(e) {
	e.isCheckStableRunning || e.lastRequestAnimationFrameId !== -1 || (e.lastRequestAnimationFrameId = e.nativeRequestAnimationFrame.call(Ht, () => {
		e.fakeTopEventTask || (e.fakeTopEventTask = Zone.root.scheduleEventTask("fakeTopEventTask", () => {
			e.lastRequestAnimationFrameId = -1, Ea(e), e.isCheckStableRunning = !0, Nu(e), e.isCheckStableRunning = !1
		}, void 0, () => {}, () => {})), e.fakeTopEventTask.invoke()
	}), Ea(e))
}

function BD(e) {
	let t = () => {
		$D(e)
	};
	e._inner = e._inner.fork({
		name: "angular",
		properties: {
			isAngularZone: !0
		},
		onInvokeTask: (r, n, i, o, s, a) => {
			if (HD(a)) return r.invokeTask(i, o, s, a);
			try {
				return rd(e), r.invokeTask(i, o, s, a)
			} finally {
				(e.shouldCoalesceEventChangeDetection && o.type === "eventTask" || e.shouldCoalesceRunChangeDetection) && t(), id(e)
			}
		},
		onInvoke: (r, n, i, o, s, a, u) => {
			try {
				return rd(e), r.invoke(i, o, s, a, u)
			} finally {
				e.shouldCoalesceRunChangeDetection && t(), id(e)
			}
		},
		onHasTask: (r, n, i, o) => {
			r.hasTask(i, o), n === i && (o.change == "microTask" ? (e._hasPendingMicrotasks = o.microTask, Ea(e), Nu(e)) : o.change == "macroTask" && (e.hasPendingMacrotasks = o.macroTask))
		},
		onHandleError: (r, n, i, o) => (r.handleError(i, o), e.runOutsideAngular(() => e.onError.emit(o)), !1)
	})
}

function Ea(e) {
	e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e.shouldCoalesceRunChangeDetection) && e.lastRequestAnimationFrameId !== -1 ? e.hasPendingMicrotasks = !0 : e.hasPendingMicrotasks = !1
}

function rd(e) {
	e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null))
}

function id(e) {
	e._nesting--, Nu(e)
}

function HD(e) {
	return !Array.isArray(e) || e.length !== 1 ? !1 : e[0].data?.__ignore_ng_zone__ === !0
}
var Mn = function(e) {
		return e[e.EarlyRead = 0] = "EarlyRead", e[e.Write = 1] = "Write", e[e.MixedReadWrite = 2] = "MixedReadWrite", e[e.Read = 3] = "Read", e
	}(Mn || {}),
	zD = {
		destroy() {}
	};

function Ru(e, t) {
	!t && cv(Ru);
	let r = t?.injector ?? p(ft);
	if (!Ey(r)) return zD;
	jn("NgAfterNextRender");
	let n = r.get(Ou),
		i = n.handler ??= new Ia,
		o = t?.phase ?? Mn.MixedReadWrite,
		s = () => {
			i.unregister(u), a()
		},
		a = r.get(mu).onDestroy(s),
		u = He(r, () => new ba(o, () => {
			s(), e()
		}));
	return i.register(u), {
		destroy: s
	}
}
var ba = class {
		constructor(t, r) {
			this.phase = t, this.callbackFn = r, this.zone = p(Z), this.errorHandler = p(Je, {
				optional: !0
			}), p(eo, {
				optional: !0
			})?.notify(1)
		}
		invoke() {
			try {
				this.zone.runOutsideAngular(this.callbackFn)
			} catch (t) {
				this.errorHandler?.handleError(t)
			}
		}
	},
	Ia = class {
		constructor() {
			this.executingCallbacks = !1, this.buckets = {
				[Mn.EarlyRead]: new Set,
				[Mn.Write]: new Set,
				[Mn.MixedReadWrite]: new Set,
				[Mn.Read]: new Set
			}, this.deferredCallbacks = new Set
		}
		register(t) {
			(this.executingCallbacks ? this.deferredCallbacks : this.buckets[t.phase]).add(t)
		}
		unregister(t) {
			this.buckets[t.phase].delete(t), this.deferredCallbacks.delete(t)
		}
		execute() {
			this.executingCallbacks = !0;
			for (let t of Object.values(this.buckets))
				for (let r of t) r.invoke();
			this.executingCallbacks = !1;
			for (let t of this.deferredCallbacks) this.buckets[t.phase].add(t);
			this.deferredCallbacks.clear()
		}
		destroy() {
			for (let t of Object.values(this.buckets)) t.clear();
			this.deferredCallbacks.clear()
		}
	},
	Ou = (() => {
		let t = class t {
			constructor() {
				this.handler = null, this.internalCallbacks = []
			}
			execute() {
				this.executeInternalCallbacks(), this.handler?.execute()
			}
			executeInternalCallbacks() {
				let n = [...this.internalCallbacks];
				this.internalCallbacks.length = 0;
				for (let i of n) i()
			}
			ngOnDestroy() {
				this.handler?.destroy(), this.handler = null, this.internalCallbacks.length = 0
			}
		};
		t.\u0275prov = C({
			token: t,
			providedIn: "root",
			factory: () => new t
		});
		let e = t;
		return e
	})();

function Ma(e, t, r) {
	let n = r ? e.styles : null,
		i = r ? e.classes : null,
		o = 0;
	if (t !== null)
		for (let s = 0; s < t.length; s++) {
			let a = t[s];
			if (typeof a == "number") o = a;
			else if (o == 1) i = Rl(i, a);
			else if (o == 2) {
				let u = a,
					c = t[++s];
				n = Rl(n, u + ": " + c + ";")
			}
		}
	r ? e.styles = n : e.stylesWithoutHost = n, r ? e.classes = i : e.classesWithoutHost = i
}
var no = class extends Mo {
	constructor(t) {
		super(), this.ngModule = t
	}
	resolveComponentFactory(t) {
		let r = _t(t);
		return new Fn(r, this.ngModule)
	}
};

function od(e) {
	let t = [];
	for (let r in e) {
		if (!e.hasOwnProperty(r)) continue;
		let n = e[r];
		n !== void 0 && t.push({
			propName: Array.isArray(n) ? n[0] : n,
			templateName: r
		})
	}
	return t
}

function GD(e) {
	let t = e.toLowerCase();
	return t === "svg" ? Yd : t === "math" ? gv : null
}
var _a = class {
		constructor(t, r) {
			this.injector = t, this.parentInjector = r
		}
		get(t, r, n) {
			n = lo(n);
			let i = this.injector.get(t, Gs, n);
			return i !== Gs || r === Gs ? i : this.parentInjector.get(t, r, n)
		}
	},
	Fn = class extends to {
		get inputs() {
			let t = this.componentDef,
				r = t.inputTransforms,
				n = od(t.inputs);
			if (r !== null)
				for (let i of n) r.hasOwnProperty(i.propName) && (i.transform = r[i.propName]);
			return n
		}
		get outputs() {
			return od(this.componentDef.outputs)
		}
		constructor(t, r) {
			super(), this.componentDef = t, this.ngModule = r, this.componentType = t.type, this.selector = Wm(t.selectors), this.ngContentSelectors = t.ngContentSelectors ? t.ngContentSelectors : [], this.isBoundToModule = !!r
		}
		create(t, r, n, i) {
			let o = k(null);
			try {
				i = i || this.ngModule;
				let s = i instanceof ge ? i : i?.injector;
				s && this.componentDef.getStandaloneInjector !== null && (s = this.componentDef.getStandaloneInjector(s) || s);
				let a = s ? new _a(t, s) : t,
					u = a.get(yr, null);
				if (u === null) throw new I(407, !1);
				let c = a.get(VD, null),
					l = a.get(Ou, null),
					d = a.get(eo, null),
					f = {
						rendererFactory: u,
						sanitizer: c,
						inlineEffectRunner: null,
						afterRenderEventManager: l,
						changeDetectionScheduler: d
					},
					h = u.createRenderer(null, this.componentDef),
					m = this.componentDef.selectors[0][0] || "div",
					S = n ? Zy(h, n, this.componentDef.encapsulation, a) : Pf(h, m, GD(m)),
					E = 512;
				this.componentDef.signals ? E |= 4096 : this.componentDef.onPush || (E |= 16);
				let D = null;
				S !== null && (D = wu(S, a, !0));
				let ae = _u(0, null, null, 1, 0, null, null, null, null, null, null),
					re = wo(null, ae, null, E, null, null, f, h, a, null, D);
				au(re);
				let q, qe;
				try {
					let Ee = this.componentDef,
						yt, vs = null;
					Ee.findHostDirectiveDefs ? (yt = [], vs = new Map, Ee.findHostDirectiveDefs(Ee, yt, vs), yt.push(Ee)) : yt = [Ee];
					let Og = qD(re, S),
						Fg = WD(Og, S, Ee, yt, re, f, h);
					qe = ru(ae, Be), S && QD(h, Ee, S, n), r !== void 0 && KD(qe, this.ngContentSelectors, r), q = YD(Fg, Ee, yt, vs, re, [JD]), Tu(ae, re, null)
				} finally {
					uu()
				}
				return new Sa(this.componentType, q, Vn(qe, re), re, qe)
			} finally {
				k(o)
			}
		}
	},
	Sa = class extends wa {
		constructor(t, r, n, i, o) {
			super(), this.location = n, this._rootLView = i, this._tNode = o, this.previousInputValues = null, this.instance = r, this.hostView = this.changeDetectorRef = new Jt(i, void 0, !1), this.componentType = t
		}
		setInput(t, r) {
			let n = this._tNode.inputs,
				i;
			if (n !== null && (i = n[t])) {
				if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), r)) return;
				let o = this._rootLView;
				Su(o[x], o, i, t, r), this.previousInputValues.set(t, r);
				let s = At(this._tNode.index, o);
				xu(s)
			}
		}
		get injector() {
			return new Gt(this._tNode, this._rootLView)
		}
		destroy() {
			this.hostView.destroy()
		}
		onDestroy(t) {
			this.hostView.onDestroy(t)
		}
	};

function qD(e, t) {
	let r = e[x],
		n = Be;
	return e[n] = t, Co(r, n, 2, "#host", null)
}

function WD(e, t, r, n, i, o, s) {
	let a = i[x];
	ZD(n, e, t, s);
	let u = null;
	t !== null && (u = wu(t, i[Rn]));
	let c = o.rendererFactory.createRenderer(t, r),
		l = 16;
	r.signals ? l = 4096 : r.onPush && (l = 64);
	let d = wo(i, Qf(r), null, l, i[e.index], e, o, c, null, null, u);
	return a.firstCreatePass && va(a, e, n.length - 1), Eo(i, d), i[e.index] = d
}

function ZD(e, t, r, n) {
	for (let i of e) t.mergedAttrs = ar(t.mergedAttrs, i.hostAttrs);
	t.mergedAttrs !== null && (Ma(t, t.mergedAttrs, !0), r !== null && $f(n, r, t))
}

function YD(e, t, r, n, i, o) {
	let s = Ce(),
		a = i[x],
		u = Fe(s, i);
	Jf(a, i, s, r, null, n);
	for (let l = 0; l < r.length; l++) {
		let d = s.directiveStart + l,
			f = Qt(i, a, d, s);
		Kt(f, i)
	}
	Xf(a, i, s), u && Kt(u, i);
	let c = Qt(i, a, s.directiveStart + s.componentOffset, s);
	if (e[ue] = i[ue] = c, o !== null)
		for (let l of o) l(c, t);
	return Wf(a, s, i), c
}

function QD(e, t, r, n) {
	if (n) na(e, r, ["ng-version", "17.3.3"]);
	else {
		let {
			attrs: i,
			classes: o
		} = Zm(t.selectors[0]);
		i && na(e, r, i), o && o.length > 0 && Uf(e, r, o.join(" "))
	}
}

function KD(e, t, r) {
	let n = e.projection = [];
	for (let i = 0; i < t.length; i++) {
		let o = r[i];
		n.push(o != null ? Array.from(o) : null)
	}
}

function JD() {
	let e = Ce();
	hu(U()[x], e)
}
var Un = (() => {
	let t = class t {};
	t.__NG_ELEMENT_ID__ = XD;
	let e = t;
	return e
})();

function XD() {
	let e = Ce();
	return ph(e, U())
}
var ew = Un,
	hh = class extends ew {
		constructor(t, r, n) {
			super(), this._lContainer = t, this._hostTNode = r, this._hostLView = n
		}
		get element() {
			return Vn(this._hostTNode, this._hostLView)
		}
		get injector() {
			return new Gt(this._hostTNode, this._hostLView)
		}
		get parentInjector() {
			let t = pu(this._hostTNode, this._hostLView);
			if (hf(t)) {
				let r = Yi(t, this._hostLView),
					n = Zi(t),
					i = r[x].data[n + 8];
				return new Gt(i, r)
			} else return new Gt(null, this._hostLView)
		}
		clear() {
			for (; this.length > 0;) this.remove(this.length - 1)
		}
		get(t) {
			let r = sd(this._lContainer);
			return r !== null && r[t] || null
		}
		get length() {
			return this._lContainer.length - ce
		}
		createEmbeddedView(t, r, n) {
			let i, o;
			typeof n == "number" ? i = n : n != null && (i = n.index, o = n.injector);
			let s = vr(this._lContainer, t.ssrId),
				a = t.createEmbeddedViewImpl(r || {}, o, s);
			return this.insertImpl(a, i, gr(this._hostTNode, s)), a
		}
		createComponent(t, r, n, i, o) {
			let s = t && !lv(t),
				a;
			if (s) a = r;
			else {
				let m = r || {};
				a = m.index, n = m.injector, i = m.projectableNodes, o = m.environmentInjector || m.ngModuleRef
			}
			let u = s ? t : new Fn(_t(t)),
				c = n || this.parentInjector;
			if (!o && u.ngModule == null) {
				let S = (s ? c : this.parentInjector).get(ge, null);
				S && (o = S)
			}
			let l = _t(u.componentType ?? {}),
				d = vr(this._lContainer, l?.id ?? null),
				f = d?.firstChild ?? null,
				h = u.create(c, i, f, o);
			return this.insertImpl(h.hostView, a, gr(this._hostTNode, d)), h
		}
		insert(t, r) {
			return this.insertImpl(t, r, !0)
		}
		insertImpl(t, r, n) {
			let i = t._lView;
			if (Dv(i)) {
				let a = this.indexOf(t);
				if (a !== -1) this.detach(a);
				else {
					let u = i[oe],
						c = new hh(u, u[ze], u[oe]);
					c.detach(c.indexOf(t))
				}
			}
			let o = this._adjustIndex(r),
				s = this._lContainer;
			return Io(s, i, o, n), t.attachToViewContainerRef(), Md(qs(s), o, t), t
		}
		move(t, r) {
			return this.insert(t, r)
		}
		indexOf(t) {
			let r = sd(this._lContainer);
			return r !== null ? r.indexOf(t) : -1
		}
		remove(t) {
			let r = this._adjustIndex(t, -1),
				n = pr(this._lContainer, r);
			n && (zi(qs(this._lContainer), r), yo(n[x], n))
		}
		detach(t) {
			let r = this._adjustIndex(t, -1),
				n = pr(this._lContainer, r);
			return n && zi(qs(this._lContainer), r) != null ? new Jt(n) : null
		}
		_adjustIndex(t, r = 0) {
			return t ?? this.length + r
		}
	};

function sd(e) {
	return e[qi]
}

function qs(e) {
	return e[qi] || (e[qi] = [])
}

function ph(e, t) {
	let r, n = t[e.index];
	return dt(n) ? r = n : (r = eh(n, t, null, e), t[e.index] = r, Eo(t, r)), nw(r, t, e, n), new hh(r, e, t)
}

function tw(e, t) {
	let r = e[se],
		n = r.createComment(""),
		i = Fe(t, e),
		o = bu(r, i);
	return Ji(r, o, n, ky(r, i), !1), n
}
var nw = ow,
	rw = () => !1;

function iw(e, t, r) {
	return rw(e, t, r)
}

function ow(e, t, r, n) {
	if (e[Wt]) return;
	let i;
	r.type & 8 ? i = Ke(n) : i = tw(t, r), e[Wt] = i
}
var Ta = class e {
		constructor(t) {
			this.queryList = t, this.matches = null
		}
		clone() {
			return new e(this.queryList)
		}
		setDirty() {
			this.queryList.setDirty()
		}
	},
	xa = class e {
		constructor(t = []) {
			this.queries = t
		}
		createEmbeddedView(t) {
			let r = t.queries;
			if (r !== null) {
				let n = t.contentQueries !== null ? t.contentQueries[0] : r.length,
					i = [];
				for (let o = 0; o < n; o++) {
					let s = r.getByIndex(o),
						a = this.queries[s.indexInDeclarationView];
					i.push(a.clone())
				}
				return new e(i)
			}
			return null
		}
		insertView(t) {
			this.dirtyQueriesWithMatches(t)
		}
		detachView(t) {
			this.dirtyQueriesWithMatches(t)
		}
		finishViewCreation(t) {
			this.dirtyQueriesWithMatches(t)
		}
		dirtyQueriesWithMatches(t) {
			for (let r = 0; r < this.queries.length; r++) Fu(t, r).matches !== null && this.queries[r].setDirty()
		}
	},
	Aa = class {
		constructor(t, r, n = null) {
			this.flags = r, this.read = n, typeof t == "string" ? this.predicate = hw(t) : this.predicate = t
		}
	},
	Na = class e {
		constructor(t = []) {
			this.queries = t
		}
		elementStart(t, r) {
			for (let n = 0; n < this.queries.length; n++) this.queries[n].elementStart(t, r)
		}
		elementEnd(t) {
			for (let r = 0; r < this.queries.length; r++) this.queries[r].elementEnd(t)
		}
		embeddedTView(t) {
			let r = null;
			for (let n = 0; n < this.length; n++) {
				let i = r !== null ? r.length : 0,
					o = this.getByIndex(n).embeddedTView(t, i);
				o && (o.indexInDeclarationView = n, r !== null ? r.push(o) : r = [o])
			}
			return r !== null ? new e(r) : null
		}
		template(t, r) {
			for (let n = 0; n < this.queries.length; n++) this.queries[n].template(t, r)
		}
		getByIndex(t) {
			return this.queries[t]
		}
		get length() {
			return this.queries.length
		}
		track(t) {
			this.queries.push(t)
		}
	},
	Ra = class e {
		constructor(t, r = -1) {
			this.metadata = t, this.matches = null, this.indexInDeclarationView = -1, this.crossesNgTemplate = !1, this._appliesToNextNode = !0, this._declarationNodeIndex = r
		}
		elementStart(t, r) {
			this.isApplyingToNode(r) && this.matchTNode(t, r)
		}
		elementEnd(t) {
			this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1)
		}
		template(t, r) {
			this.elementStart(t, r)
		}
		embeddedTView(t, r) {
			return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, r), new e(this.metadata)) : null
		}
		isApplyingToNode(t) {
			if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
				let r = this._declarationNodeIndex,
					n = t.parent;
				for (; n !== null && n.type & 8 && n.index !== r;) n = n.parent;
				return r === (n !== null ? n.index : -1)
			}
			return this._appliesToNextNode
		}
		matchTNode(t, r) {
			let n = this.metadata.predicate;
			if (Array.isArray(n))
				for (let i = 0; i < n.length; i++) {
					let o = n[i];
					this.matchTNodeWithReadOption(t, r, sw(r, o)), this.matchTNodeWithReadOption(t, r, ji(r, t, o, !1, !1))
				} else n === mr ? r.type & 4 && this.matchTNodeWithReadOption(t, r, -1) : this.matchTNodeWithReadOption(t, r, ji(r, t, n, !1, !1))
		}
		matchTNodeWithReadOption(t, r, n) {
			if (n !== null) {
				let i = this.metadata.read;
				if (i !== null)
					if (i === Se || i === Un || i === mr && r.type & 4) this.addMatch(r.index, -2);
					else {
						let o = ji(r, t, i, !1, !1);
						o !== null && this.addMatch(r.index, o)
					}
				else this.addMatch(r.index, n)
			}
		}
		addMatch(t, r) {
			this.matches === null ? this.matches = [t, r] : this.matches.push(t, r)
		}
	};

function sw(e, t) {
	let r = e.localNames;
	if (r !== null) {
		for (let n = 0; n < r.length; n += 2)
			if (r[n] === t) return r[n + 1]
	}
	return null
}

function aw(e, t) {
	return e.type & 11 ? Vn(e, t) : e.type & 4 ? Au(e, t) : null
}

function uw(e, t, r, n) {
	return r === -1 ? aw(t, e) : r === -2 ? cw(e, t, n) : Qt(e, e[x], r, t)
}

function cw(e, t, r) {
	if (r === Se) return Vn(t, e);
	if (r === mr) return Au(t, e);
	if (r === Un) return ph(t, e)
}

function gh(e, t, r, n) {
	let i = t[ut].queries[n];
	if (i.matches === null) {
		let o = e.data,
			s = r.matches,
			a = [];
		for (let u = 0; s !== null && u < s.length; u += 2) {
			let c = s[u];
			if (c < 0) a.push(null);
			else {
				let l = o[c];
				a.push(uw(t, l, s[u + 1], r.metadata.read))
			}
		}
		i.matches = a
	}
	return i.matches
}

function Oa(e, t, r, n) {
	let i = e.queries.getByIndex(r),
		o = i.matches;
	if (o !== null) {
		let s = gh(e, t, i, r);
		for (let a = 0; a < o.length; a += 2) {
			let u = o[a];
			if (u > 0) n.push(s[a / 2]);
			else {
				let c = o[a + 1],
					l = t[-u];
				for (let d = ce; d < l.length; d++) {
					let f = l[d];
					f[Ir] === f[oe] && Oa(f[x], f, c, n)
				}
				if (l[On] !== null) {
					let d = l[On];
					for (let f = 0; f < d.length; f++) {
						let h = d[f];
						Oa(h[x], h, c, n)
					}
				}
			}
		}
	}
	return n
}

function lw(e, t) {
	return e[ut].queries[t].queryList
}

function dw(e, t, r) {
	let n = new pa((r & 4) === 4);
	return Ky(e, t, n, n.destroy), (t[ut] ??= new xa).queries.push(new Ta(n)) - 1
}

function fw(e, t, r, n) {
	let i = _e();
	if (i.firstCreatePass) {
		let o = Ce();
		pw(i, new Aa(t, r, n), o.index), gw(i, e), (r & 2) === 2 && (i.staticContentQueries = !0)
	}
	return dw(i, U(), r)
}

function hw(e) {
	return e.split(",").map(t => t.trim())
}

function pw(e, t, r) {
	e.queries === null && (e.queries = new Na), e.queries.track(new Ra(t, r))
}

function gw(e, t) {
	let r = e.contentQueries || (e.contentQueries = []),
		n = r.length ? r[r.length - 1] : -1;
	t !== n && r.push(e.queries.length - 1, t)
}

function Fu(e, t) {
	return e.queries.getByIndex(t)
}

function mw(e, t) {
	let r = e[x],
		n = Fu(r, t);
	return n.crossesNgTemplate ? Oa(r, e, t, []) : gh(r, e, n, t)
}

function vw(e) {
	return Object.getPrototypeOf(e.prototype).constructor
}

function tn(e) {
	let t = vw(e.type),
		r = !0,
		n = [e];
	for (; t;) {
		let i;
		if (St(e)) i = t.\u0275cmp || t.\u0275dir;
		else {
			if (t.\u0275cmp) throw new I(903, !1);
			i = t.\u0275dir
		}
		if (i) {
			if (r) {
				n.push(i);
				let s = e;
				s.inputs = Fi(e.inputs), s.inputTransforms = Fi(e.inputTransforms), s.declaredInputs = Fi(e.declaredInputs), s.outputs = Fi(e.outputs);
				let a = i.hostBindings;
				a && Ew(e, a);
				let u = i.viewQuery,
					c = i.contentQueries;
				if (u && ww(e, u), c && Cw(e, c), yw(e, i), hm(e.outputs, i.outputs), St(i) && i.data.animation) {
					let l = e.data;
					l.animation = (l.animation || []).concat(i.data.animation)
				}
			}
			let o = i.features;
			if (o)
				for (let s = 0; s < o.length; s++) {
					let a = o[s];
					a && a.ngInherit && a(e), a === tn && (r = !1)
				}
		}
		t = Object.getPrototypeOf(t)
	}
	Dw(n)
}

function yw(e, t) {
	for (let r in t.inputs) {
		if (!t.inputs.hasOwnProperty(r) || e.inputs.hasOwnProperty(r)) continue;
		let n = t.inputs[r];
		if (n !== void 0 && (e.inputs[r] = n, e.declaredInputs[r] = t.declaredInputs[r], t.inputTransforms !== null)) {
			let i = Array.isArray(n) ? n[0] : n;
			if (!t.inputTransforms.hasOwnProperty(i)) continue;
			e.inputTransforms ??= {}, e.inputTransforms[i] = t.inputTransforms[i]
		}
	}
}

function Dw(e) {
	let t = 0,
		r = null;
	for (let n = e.length - 1; n >= 0; n--) {
		let i = e[n];
		i.hostVars = t += i.hostVars, i.hostAttrs = ar(i.hostAttrs, r = ar(r, i.hostAttrs))
	}
}

function Fi(e) {
	return e === xn ? {} : e === Oe ? [] : e
}

function ww(e, t) {
	let r = e.viewQuery;
	r ? e.viewQuery = (n, i) => {
		t(n, i), r(n, i)
	} : e.viewQuery = t
}

function Cw(e, t) {
	let r = e.contentQueries;
	r ? e.contentQueries = (n, i, o) => {
		t(n, i, o), r(n, i, o)
	} : e.contentQueries = t
}

function Ew(e, t) {
	let r = e.hostBindings;
	r ? e.hostBindings = (n, i) => {
		t(n, i), r(n, i)
	} : e.hostBindings = t
}

function Pu(e) {
	let t = e.inputConfig,
		r = {};
	for (let n in t)
		if (t.hasOwnProperty(n)) {
			let i = t[n];
			Array.isArray(i) && i[3] && (r[n] = i[3])
		} e.inputTransforms = r
}
var Tt = class {},
	Dr = class {};
var Fa = class extends Tt {
		constructor(t, r, n) {
			super(), this._parent = r, this._bootstrapComponents = [], this.destroyCbs = [], this.componentFactoryResolver = new no(this);
			let i = Fd(t);
			this._bootstrapComponents = Ff(i.bootstrap), this._r3Injector = Ef(t, r, [{
				provide: Tt,
				useValue: this
			}, {
				provide: Mo,
				useValue: this.componentFactoryResolver
			}, ...n], De(t), new Set(["environment"])), this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(t)
		}
		get injector() {
			return this._r3Injector
		}
		destroy() {
			let t = this._r3Injector;
			!t.destroyed && t.destroy(), this.destroyCbs.forEach(r => r()), this.destroyCbs = null
		}
		onDestroy(t) {
			this.destroyCbs.push(t)
		}
	},
	Pa = class extends Dr {
		constructor(t) {
			super(), this.moduleType = t
		}
		create(t) {
			return new Fa(this.moduleType, t, [])
		}
	};
var ro = class extends Tt {
	constructor(t) {
		super(), this.componentFactoryResolver = new no(this), this.instance = null;
		let r = new ur([...t.providers, {
			provide: Tt,
			useValue: this
		}, {
			provide: Mo,
			useValue: this.componentFactoryResolver
		}], t.parent || eu(), t.debugName, new Set(["environment"]));
		this.injector = r, t.runEnvironmentInitializers && r.resolveInjectorInitializers()
	}
	destroy() {
		this.injector.destroy()
	}
	onDestroy(t) {
		this.injector.onDestroy(t)
	}
};

function _o(e, t, r = null) {
	return new ro({
		providers: e,
		parent: t,
		debugName: r,
		runEnvironmentInitializers: !0
	}).injector
}
var nn = (() => {
	let t = class t {
		constructor() {
			this.taskId = 0, this.pendingTasks = new Set, this.hasPendingTasks = new W(!1)
		}
		get _hasPendingTasks() {
			return this.hasPendingTasks.value
		}
		add() {
			this._hasPendingTasks || this.hasPendingTasks.next(!0);
			let n = this.taskId++;
			return this.pendingTasks.add(n), n
		}
		remove(n) {
			this.pendingTasks.delete(n), this.pendingTasks.size === 0 && this._hasPendingTasks && this.hasPendingTasks.next(!1)
		}
		ngOnDestroy() {
			this.pendingTasks.clear(), this._hasPendingTasks && this.hasPendingTasks.next(!1)
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();

function mh(e, t, r) {
	return e[t] = r
}

function bw(e, t) {
	return e[t]
}

function rn(e, t, r) {
	let n = e[t];
	return Object.is(n, r) ? !1 : (e[t] = r, !0)
}

function Iw(e) {
	return (e.flags & 32) === 32
}

function Mw(e, t, r, n, i, o, s, a, u) {
	let c = t.consts,
		l = Co(t, e, 4, s || null, Wi(c, a));
	Kf(t, r, l, Wi(c, u)), hu(t, l);
	let d = l.tView = _u(2, l, n, i, o, t.directiveRegistry, t.pipeRegistry, null, t.schemas, c, null);
	return t.queries !== null && (t.queries.template(t, l), d.queries = t.queries.embeddedTView(l)), l
}

function Me(e, t, r, n, i, o, s, a) {
	let u = U(),
		c = _e(),
		l = e + Be,
		d = c.firstCreatePass ? Mw(l, c, u, t, r, n, i, o, s) : c.data[l];
	Mr(d, !1);
	let f = _w(c, u, d, e);
	du() && Iu(c, u, f, d), Kt(f, u);
	let h = eh(f, u, f, d);
	return u[l] = h, Eo(u, h), iw(h, d, u), nu(d) && Zf(c, u, d), s != null && Yf(u, d, a), Me
}
var _w = Sw;

function Sw(e, t, r, n) {
	return fu(!0), t[se].createComment("")
}

function So(e, t, r, n) {
	let i = U(),
		o = _r();
	if (rn(i, o, t)) {
		let s = _e(),
			a = lf();
		hD(a, i, e, t, r, n)
	}
	return So
}

function Tw(e, t, r, n) {
	return rn(e, _r(), r) ? t + co(r) + n : Nt
}

function Pi(e, t) {
	return e << 17 | t << 2
}

function Xt(e) {
	return e >> 17 & 32767
}

function xw(e) {
	return (e & 2) == 2
}

function Aw(e, t) {
	return e & 131071 | t << 17
}

function ka(e) {
	return e | 2
}

function Pn(e) {
	return (e & 131068) >> 2
}

function Ws(e, t) {
	return e & -131069 | t << 2
}

function Nw(e) {
	return (e & 1) === 1
}

function La(e) {
	return e | 1
}

function Rw(e, t, r, n, i, o) {
	let s = o ? t.classBindings : t.styleBindings,
		a = Xt(s),
		u = Pn(s);
	e[n] = r;
	let c = !1,
		l;
	if (Array.isArray(r)) {
		let d = r;
		l = d[1], (l === null || br(d, l) > 0) && (c = !0)
	} else l = r;
	if (i)
		if (u !== 0) {
			let f = Xt(e[a + 1]);
			e[n + 1] = Pi(f, a), f !== 0 && (e[f + 1] = Ws(e[f + 1], n)), e[a + 1] = Aw(e[a + 1], n)
		} else e[n + 1] = Pi(a, 0), a !== 0 && (e[a + 1] = Ws(e[a + 1], n)), a = n;
	else e[n + 1] = Pi(u, 0), a === 0 ? a = n : e[u + 1] = Ws(e[u + 1], n), u = n;
	c && (e[n + 1] = ka(e[n + 1])), ad(e, l, n, !0), ad(e, l, n, !1), Ow(t, l, e, n, o), s = Pi(a, u), o ? t.classBindings = s : t.styleBindings = s
}

function Ow(e, t, r, n, i) {
	let o = i ? e.residualClasses : e.residualStyles;
	o != null && typeof t == "string" && br(o, t) >= 0 && (r[n + 1] = La(r[n + 1]))
}

function ad(e, t, r, n) {
	let i = e[r + 1],
		o = t === null,
		s = n ? Xt(i) : Pn(i),
		a = !1;
	for (; s !== 0 && (a === !1 || o);) {
		let u = e[s],
			c = e[s + 1];
		Fw(u, t) && (a = !0, e[s + 1] = n ? La(c) : ka(c)), s = n ? Xt(c) : Pn(c)
	}
	a && (e[r + 1] = n ? ka(i) : La(i))
}

function Fw(e, t) {
	return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? br(e, t) >= 0 : !1
}

function te(e, t, r) {
	let n = U(),
		i = _r();
	if (rn(n, i, t)) {
		let o = _e(),
			s = lf();
		tD(o, s, n, e, t, n[se], r, !1)
	}
	return te
}

function ud(e, t, r, n, i) {
	let o = t.inputs,
		s = i ? "class" : "style";
	Su(e, r, o[s], s, n)
}

function To(e, t) {
	return Pw(e, t, null, !0), To
}

function Pw(e, t, r, n) {
	let i = U(),
		o = _e(),
		s = Rv(2);
	if (o.firstUpdatePass && Lw(o, e, s, n), t !== Nt && rn(i, s, t)) {
		let a = o.data[en()];
		Bw(o, a, i, i[se], e, i[s + 1] = Hw(t, r), n, s)
	}
}

function kw(e, t) {
	return t >= e.expandoStartIndex
}

function Lw(e, t, r, n) {
	let i = e.data;
	if (i[r + 1] === null) {
		let o = i[en()],
			s = kw(e, r);
		zw(o, n) && t === null && !s && (t = !1), t = Vw(i, o, t, n), Rw(i, o, t, r, s, n)
	}
}

function Vw(e, t, r, n) {
	let i = kv(e),
		o = n ? t.residualClasses : t.residualStyles;
	if (i === null)(n ? t.classBindings : t.styleBindings) === 0 && (r = Zs(null, e, t, r, n), r = wr(r, t.attrs, n), o = null);
	else {
		let s = t.directiveStylingLast;
		if (s === -1 || e[s] !== i)
			if (r = Zs(i, e, t, r, n), o === null) {
				let u = jw(e, t, n);
				u !== void 0 && Array.isArray(u) && (u = Zs(null, e, t, u[1], n), u = wr(u, t.attrs, n), Uw(e, t, n, u))
			} else o = $w(e, t, n)
	}
	return o !== void 0 && (n ? t.residualClasses = o : t.residualStyles = o), r
}

function jw(e, t, r) {
	let n = r ? t.classBindings : t.styleBindings;
	if (Pn(n) !== 0) return e[Xt(n)]
}

function Uw(e, t, r, n) {
	let i = r ? t.classBindings : t.styleBindings;
	e[Xt(i)] = n
}

function $w(e, t, r) {
	let n, i = t.directiveEnd;
	for (let o = 1 + t.directiveStylingLast; o < i; o++) {
		let s = e[o].hostAttrs;
		n = wr(n, s, r)
	}
	return wr(n, t.attrs, r)
}

function Zs(e, t, r, n, i) {
	let o = null,
		s = r.directiveEnd,
		a = r.directiveStylingLast;
	for (a === -1 ? a = r.directiveStart : a++; a < s && (o = t[a], n = wr(n, o.hostAttrs, i), o !== e);) a++;
	return e !== null && (r.directiveStylingLast = a), n
}

function wr(e, t, r) {
	let n = r ? 1 : 2,
		i = -1;
	if (t !== null)
		for (let o = 0; o < t.length; o++) {
			let s = t[o];
			typeof s == "number" ? i = s : i === n && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), Pm(e, s, r ? !0 : t[++o]))
		}
	return e === void 0 ? null : e
}

function Bw(e, t, r, n, i, o, s, a) {
	if (!(t.type & 3)) return;
	let u = e.data,
		c = u[a + 1],
		l = Nw(c) ? cd(u, t, r, i, Pn(c), s) : void 0;
	if (!io(l)) {
		io(o) || xw(c) && (o = cd(u, null, r, i, a, s));
		let d = Qd(en(), r);
		Hy(n, s, d, i, o)
	}
}

function cd(e, t, r, n, i, o) {
	let s = t === null,
		a;
	for (; i > 0;) {
		let u = e[i],
			c = Array.isArray(u),
			l = c ? u[1] : u,
			d = l === null,
			f = r[i + 1];
		f === Nt && (f = d ? Oe : void 0);
		let h = d ? Ls(f, n) : l === n ? f : void 0;
		if (c && !io(h) && (h = Ls(u, n)), io(h) && (a = h, s)) return a;
		let m = e[i + 1];
		i = s ? Xt(m) : Pn(m)
	}
	if (t !== null) {
		let u = o ? t.residualClasses : t.residualStyles;
		u != null && (a = Ls(u, n))
	}
	return a
}

function io(e) {
	return e !== void 0
}

function Hw(e, t) {
	return e == null || e === "" || (typeof t == "string" ? e = e + t : typeof e == "object" && (e = De(Tr(e)))), e
}

function zw(e, t) {
	return (e.flags & (t ? 8 : 16)) !== 0
}
var Va = class {
	destroy(t) {}
	updateValue(t, r) {}
	swap(t, r) {
		let n = Math.min(t, r),
			i = Math.max(t, r),
			o = this.detach(i);
		if (i - n > 1) {
			let s = this.detach(n);
			this.attach(n, o), this.attach(i, s)
		} else this.attach(n, o)
	}
	move(t, r) {
		this.attach(r, this.detach(t))
	}
};

function Ys(e, t, r, n, i) {
	return e === r && Object.is(t, n) ? 1 : Object.is(i(e, t), i(r, n)) ? -1 : 0
}

function Gw(e, t, r) {
	let n, i, o = 0,
		s = e.length - 1;
	if (Array.isArray(t)) {
		let a = t.length - 1;
		for (; o <= s && o <= a;) {
			let u = e.at(o),
				c = t[o],
				l = Ys(o, u, o, c, r);
			if (l !== 0) {
				l < 0 && e.updateValue(o, c), o++;
				continue
			}
			let d = e.at(s),
				f = t[a],
				h = Ys(s, d, a, f, r);
			if (h !== 0) {
				h < 0 && e.updateValue(s, f), s--, a--;
				continue
			}
			let m = r(o, u),
				S = r(s, d),
				E = r(o, c);
			if (Object.is(E, S)) {
				let D = r(a, f);
				Object.is(D, m) ? (e.swap(o, s), e.updateValue(s, f), a--, s--) : e.move(s, o), e.updateValue(o, c), o++;
				continue
			}
			if (n ??= new oo, i ??= dd(e, o, s, r), ja(e, n, o, E)) e.updateValue(o, c), o++, s++;
			else if (i.has(E)) n.set(m, e.detach(o)), s--;
			else {
				let D = e.create(o, t[o]);
				e.attach(o, D), o++, s++
			}
		}
		for (; o <= a;) ld(e, n, r, o, t[o]), o++
	} else if (t != null) {
		let a = t[Symbol.iterator](),
			u = a.next();
		for (; !u.done && o <= s;) {
			let c = e.at(o),
				l = u.value,
				d = Ys(o, c, o, l, r);
			if (d !== 0) d < 0 && e.updateValue(o, l), o++, u = a.next();
			else {
				n ??= new oo, i ??= dd(e, o, s, r);
				let f = r(o, l);
				if (ja(e, n, o, f)) e.updateValue(o, l), o++, s++, u = a.next();
				else if (!i.has(f)) e.attach(o, e.create(o, l)), o++, s++, u = a.next();
				else {
					let h = r(o, c);
					n.set(h, e.detach(o)), s--
				}
			}
		}
		for (; !u.done;) ld(e, n, r, e.length, u.value), u = a.next()
	}
	for (; o <= s;) e.destroy(e.detach(s--));
	n?.forEach(a => {
		e.destroy(a)
	})
}

function ja(e, t, r, n) {
	return t !== void 0 && t.has(n) ? (e.attach(r, t.get(n)), t.delete(n), !0) : !1
}

function ld(e, t, r, n, i) {
	if (ja(e, t, n, r(n, i))) e.updateValue(n, i);
	else {
		let o = e.create(n, i);
		e.attach(n, o)
	}
}

function dd(e, t, r, n) {
	let i = new Set;
	for (let o = t; o <= r; o++) i.add(n(o, e.at(o)));
	return i
}
var oo = class {
	constructor() {
		this.kvMap = new Map, this._vMap = void 0
	}
	has(t) {
		return this.kvMap.has(t)
	}
	delete(t) {
		if (!this.has(t)) return !1;
		let r = this.kvMap.get(t);
		return this._vMap !== void 0 && this._vMap.has(r) ? (this.kvMap.set(t, this._vMap.get(r)), this._vMap.delete(r)) : this.kvMap.delete(t), !0
	}
	get(t) {
		return this.kvMap.get(t)
	}
	set(t, r) {
		if (this.kvMap.has(t)) {
			let n = this.kvMap.get(t);
			this._vMap === void 0 && (this._vMap = new Map);
			let i = this._vMap;
			for (; i.has(n);) n = i.get(n);
			i.set(n, r)
		} else this.kvMap.set(t, r)
	}
	forEach(t) {
		for (let [r, n] of this.kvMap)
			if (t(n, r), this._vMap !== void 0) {
				let i = this._vMap;
				for (; i.has(n);) n = i.get(n), t(n, r)
			}
	}
};

function Pe(e, t, r) {
	jn("NgControlFlow");
	let n = U(),
		i = _r(),
		o = Ha(n, Be + e),
		s = 0;
	if (rn(n, i, t)) {
		let a = k(null);
		try {
			if (sh(o, s), t !== -1) {
				let u = za(n[x], Be + t),
					c = vr(o, u.tView.ssrId),
					l = bo(n, u, r, {
						dehydratedView: c
					});
				Io(o, l, s, gr(u, c))
			}
		} finally {
			k(a)
		}
	} else {
		let a = oh(o, s);
		a !== void 0 && (a[ue] = r)
	}
}
var Ua = class {
	constructor(t, r, n) {
		this.lContainer = t, this.$implicit = r, this.$index = n
	}
	get $count() {
		return this.lContainer.length - ce
	}
};

function vh(e) {
	return e
}
var $a = class {
	constructor(t, r, n) {
		this.hasEmptyBlock = t, this.trackByFn = r, this.liveCollection = n
	}
};

function yh(e, t, r, n, i, o, s, a, u, c, l, d, f) {
	jn("NgControlFlow");
	let h = u !== void 0,
		m = U(),
		S = a ? s.bind(m[$e][ue]) : s,
		E = new $a(h, S);
	m[Be + e] = E, Me(e + 1, t, r, n, i, o), h && Me(e + 2, u, c, l, d, f)
}
var Ba = class extends Va {
	constructor(t, r, n) {
		super(), this.lContainer = t, this.hostLView = r, this.templateTNode = n, this.needsIndexUpdate = !1
	}
	get length() {
		return this.lContainer.length - ce
	}
	at(t) {
		return this.getLView(t)[ue].$implicit
	}
	attach(t, r) {
		let n = r[cr];
		this.needsIndexUpdate ||= t !== this.length, Io(this.lContainer, r, t, gr(this.templateTNode, n))
	}
	detach(t) {
		return this.needsIndexUpdate ||= t !== this.length - 1, qw(this.lContainer, t)
	}
	create(t, r) {
		let n = vr(this.lContainer, this.templateTNode.tView.ssrId);
		return bo(this.hostLView, this.templateTNode, new Ua(this.lContainer, r, t), {
			dehydratedView: n
		})
	}
	destroy(t) {
		yo(t[x], t)
	}
	updateValue(t, r) {
		this.getLView(t)[ue].$implicit = r
	}
	reset() {
		this.needsIndexUpdate = !1
	}
	updateIndexes() {
		if (this.needsIndexUpdate)
			for (let t = 0; t < this.length; t++) this.getLView(t)[ue].$index = t
	}
	getLView(t) {
		return Ww(this.lContainer, t)
	}
};

function Dh(e) {
	let t = k(null),
		r = en();
	try {
		let n = U(),
			i = n[x],
			o = n[r];
		if (o.liveCollection === void 0) {
			let a = r + 1,
				u = Ha(n, a),
				c = za(i, a);
			o.liveCollection = new Ba(u, n, c)
		} else o.liveCollection.reset();
		let s = o.liveCollection;
		if (Gw(s, e, o.trackByFn), s.updateIndexes(), o.hasEmptyBlock) {
			let a = _r(),
				u = s.length === 0;
			if (rn(n, a, u)) {
				let c = r + 2,
					l = Ha(n, c);
				if (u) {
					let d = za(i, c),
						f = vr(l, d.tView.ssrId),
						h = bo(n, d, void 0, {
							dehydratedView: f
						});
					Io(l, h, 0, gr(d, f))
				} else sh(l, 0)
			}
		}
	} finally {
		k(t)
	}
}

function Ha(e, t) {
	return e[t]
}

function qw(e, t) {
	return pr(e, t)
}

function Ww(e, t) {
	return oh(e, t)
}

function za(e, t) {
	return ru(e, t)
}

function Zw(e, t, r, n, i, o) {
	let s = t.consts,
		a = Wi(s, i),
		u = Co(t, e, 2, n, a);
	return Kf(t, r, u, Wi(s, o)), u.attrs !== null && Ma(u, u.attrs, !1), u.mergedAttrs !== null && Ma(u, u.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, u), u
}

function v(e, t, r, n) {
	let i = U(),
		o = _e(),
		s = Be + e,
		a = i[se],
		u = o.firstCreatePass ? Zw(s, o, i, t, r, n) : o.data[s],
		c = Yw(o, i, u, a, t, e);
	i[s] = c;
	let l = nu(u);
	return Mr(u, !0), $f(a, c, u), !Iw(u) && du() && Iu(o, i, c, u), bv() === 0 && Kt(c, i), Iv(), l && (Zf(o, i, u), Wf(o, u, i)), n !== null && Yf(i, u), v
}

function y() {
	let e = Ce();
	tf() ? Av() : (e = e.parent, Mr(e, !1));
	let t = e;
	Sv(t) && Tv(), Mv();
	let r = _e();
	return r.firstCreatePass && (hu(r, e), zd(e) && r.queries.elementEnd(e)), t.classesWithoutHost != null && zv(t) && ud(r, t, U(), t.classesWithoutHost, !0), t.stylesWithoutHost != null && Gv(t) && ud(r, t, U(), t.stylesWithoutHost, !1), y
}

function Y(e, t, r, n) {
	return v(e, t, r, n), y(), Y
}
var Yw = (e, t, r, n, i, o) => (fu(!0), Pf(n, i, Uv()));

function xo() {
	return U()
}
var so = "en-US";
var Qw = so;

function Kw(e) {
	typeof e == "string" && (Qw = e.toLowerCase().replace(/_/g, "-"))
}

function Te(e, t, r, n) {
	let i = U(),
		o = _e(),
		s = Ce();
	return Xw(o, i, i[se], s, e, t, n), Te
}

function Jw(e, t, r, n) {
	let i = e.cleanup;
	if (i != null)
		for (let o = 0; o < i.length - 1; o += 2) {
			let s = i[o];
			if (s === r && i[o + 1] === n) {
				let a = t[lr],
					u = i[o + 2];
				return a.length > u ? a[u] : null
			}
			typeof s == "string" && (o += 2)
		}
	return null
}

function Xw(e, t, r, n, i, o, s) {
	let a = nu(n),
		c = e.firstCreatePass && rh(e),
		l = t[ue],
		d = nh(t),
		f = !0;
	if (n.type & 3 || s) {
		let S = Fe(n, t),
			E = s ? s(S) : S,
			D = d.length,
			ae = s ? q => s(Ke(q[n.index])) : n.index,
			re = null;
		if (!s && a && (re = Jw(e, t, i, n.index)), re !== null) {
			let q = re.__ngLastListenerFn__ || re;
			q.__ngNextListenerFn__ = o, re.__ngLastListenerFn__ = o, f = !1
		} else {
			o = hd(n, t, l, o, !1);
			let q = r.listen(E, i, o);
			d.push(o, q), c && c.push(i, ae, D, D + 1)
		}
	} else o = hd(n, t, l, o, !1);
	let h = n.outputs,
		m;
	if (f && h !== null && (m = h[i])) {
		let S = m.length;
		if (S)
			for (let E = 0; E < S; E += 2) {
				let D = m[E],
					ae = m[E + 1],
					qe = t[D][ae].subscribe(o),
					Ee = d.length;
				d.push(o, qe), c && c.push(i, n.index, Ee, -(Ee + 1))
			}
	}
}

function fd(e, t, r, n) {
	let i = k(null);
	try {
		return Ze(6, t, r), r(n) !== !1
	} catch (o) {
		return ih(e, o), !1
	} finally {
		Ze(7, t, r), k(i)
	}
}

function hd(e, t, r, n, i) {
	return function o(s) {
		if (s === Function) return n;
		let a = e.componentOffset > -1 ? At(e.index, t) : t;
		xu(a);
		let u = fd(t, r, n, s),
			c = o.__ngNextListenerFn__;
		for (; c;) u = fd(t, r, c, s) && u, c = c.__ngNextListenerFn__;
		return i && u === !1 && s.preventDefault(), u
	}
}

function Rt(e = 1) {
	return Vv(e)
}

function wh(e, t, r, n) {
	fw(e, t, r, n)
}

function Ch(e) {
	let t = U(),
		r = _e(),
		n = rf();
	su(n + 1);
	let i = Fu(r, n);
	if (e.dirty && yv(t) === ((i.metadata.flags & 2) === 2)) {
		if (i.matches === null) e.reset([]);
		else {
			let o = mw(t, n);
			e.reset(o, iy), e.notifyOnChanges()
		}
		return !0
	}
	return !1
}

function Eh() {
	return lw(U(), rf())
}

function P(e, t = "") {
	let r = U(),
		n = _e(),
		i = e + Be,
		o = n.firstCreatePass ? Co(n, i, 1, t, null) : n.data[i],
		s = eC(n, r, o, t, e);
	r[i] = s, du() && Iu(n, r, s, o), Mr(o, !1)
}
var eC = (e, t, r, n, i) => (fu(!0), Iy(t[se], n));

function xr(e) {
	return pt("", e, ""), xr
}

function pt(e, t, r) {
	let n = U(),
		i = Tw(n, e, t, r);
	return i !== Nt && vD(n, en(), i), pt
}

function tC(e, t, r) {
	let n = _e();
	if (n.firstCreatePass) {
		let i = St(e);
		Ga(r, n.data, n.blueprint, i, !0), Ga(t, n.data, n.blueprint, i, !1)
	}
}

function Ga(e, t, r, n, i) {
	if (e = pe(e), Array.isArray(e))
		for (let o = 0; o < e.length; o++) Ga(e[o], t, r, n, i);
	else {
		let o = _e(),
			s = U(),
			a = Ce(),
			u = Nn(e) ? e : pe(e.provide),
			c = Ud(e),
			l = a.providerIndexes & 1048575,
			d = a.directiveStart,
			f = a.providerIndexes >> 20;
		if (Nn(e) || !e.multi) {
			let h = new Yt(c, i, $),
				m = Ks(u, t, i ? l : l + f, d);
			m === -1 ? (la(Qi(a, s), o, u), Qs(o, e, t.length), t.push(u), a.directiveStart++, a.directiveEnd++, i && (a.providerIndexes += 1048576), r.push(h), s.push(h)) : (r[m] = h, s[m] = h)
		} else {
			let h = Ks(u, t, l + f, d),
				m = Ks(u, t, l, l + f),
				S = h >= 0 && r[h],
				E = m >= 0 && r[m];
			if (i && !E || !i && !S) {
				la(Qi(a, s), o, u);
				let D = iC(i ? rC : nC, r.length, i, n, c);
				!i && E && (r[m].providerFactory = D), Qs(o, e, t.length, 0), t.push(u), a.directiveStart++, a.directiveEnd++, i && (a.providerIndexes += 1048576), r.push(D), s.push(D)
			} else {
				let D = bh(r[i ? m : h], c, !i && n);
				Qs(o, e, h > -1 ? h : m, D)
			}!i && n && E && r[m].componentProviders++
		}
	}
}

function Qs(e, t, r, n) {
	let i = Nn(t),
		o = nv(t);
	if (i || o) {
		let u = (o ? pe(t.useClass) : t).prototype.ngOnDestroy;
		if (u) {
			let c = e.destroyHooks || (e.destroyHooks = []);
			if (!i && t.multi) {
				let l = c.indexOf(r);
				l === -1 ? c.push(r, [n, u]) : c[l + 1].push(n, u)
			} else c.push(r, u)
		}
	}
}

function bh(e, t, r) {
	return r && e.componentProviders++, e.multi.push(t) - 1
}

function Ks(e, t, r, n) {
	for (let i = r; i < n; i++)
		if (t[i] === e) return i;
	return -1
}

function nC(e, t, r, n) {
	return qa(this.multi, [])
}

function rC(e, t, r, n) {
	let i = this.multi,
		o;
	if (this.providerFactory) {
		let s = this.providerFactory.componentProviders,
			a = Qt(r, r[x], this.providerFactory.index, n);
		o = a.slice(0, s), qa(i, o);
		for (let u = s; u < a.length; u++) o.push(a[u])
	} else o = [], qa(i, o);
	return o
}

function qa(e, t) {
	for (let r = 0; r < e.length; r++) {
		let n = e[r];
		t.push(n())
	}
	return t
}

function iC(e, t, r, n, i) {
	let o = new Yt(e, r, $);
	return o.multi = [], o.index = t, o.componentProviders = 0, bh(o, i, n && !r), o
}

function ku(e, t = []) {
	return r => {
		r.providersResolver = (n, i) => tC(n, i ? i(e) : e, t)
	}
}
var oC = (() => {
	let t = class t {
		constructor(n) {
			this._injector = n, this.cachedInjectors = new Map
		}
		getOrCreateStandaloneInjector(n) {
			if (!n.standalone) return null;
			if (!this.cachedInjectors.has(n)) {
				let i = Ld(!1, n.type),
					o = i.length > 0 ? _o([i], this._injector, `Standalone[${n.type.name}]`) : null;
				this.cachedInjectors.set(n, o)
			}
			return this.cachedInjectors.get(n)
		}
		ngOnDestroy() {
			try {
				for (let n of this.cachedInjectors.values()) n !== null && n.destroy()
			} finally {
				this.cachedInjectors.clear()
			}
		}
	};
	t.\u0275prov = C({
		token: t,
		providedIn: "environment",
		factory: () => new t(M(ge))
	});
	let e = t;
	return e
})();

function fe(e) {
	jn("NgStandalone"), e.getStandaloneInjector = t => t.get(oC).getOrCreateStandaloneInjector(e)
}

function on(e, t, r) {
	let n = nf() + e,
		i = U();
	return i[n] === Nt ? mh(i, n, r ? t.call(r) : t()) : bw(i, n)
}

function Ih(e, t, r, n) {
	return aC(U(), nf(), e, t, r, n)
}

function sC(e, t) {
	let r = e[t];
	return r === Nt ? void 0 : r
}

function aC(e, t, r, n, i, o) {
	let s = t + r;
	return rn(e, s, i) ? mh(e, s + 1, o ? n.call(o, i) : n(i)) : sC(e, s + 1)
}
var Ao = (() => {
	let t = class t {
		log(n) {
			console.log(n)
		}
		warn(n) {
			console.warn(n)
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "platform"
	});
	let e = t;
	return e
})();
var Mh = new w("");

function sn(e) {
	return !!e && typeof e.then == "function"
}

function _h(e) {
	return !!e && typeof e.subscribe == "function"
}
var No = new w(""),
	Sh = (() => {
		let t = class t {
			constructor() {
				this.initialized = !1, this.done = !1, this.donePromise = new Promise((n, i) => {
					this.resolve = n, this.reject = i
				}), this.appInits = p(No, {
					optional: !0
				}) ?? []
			}
			runInitializers() {
				if (this.initialized) return;
				let n = [];
				for (let o of this.appInits) {
					let s = o();
					if (sn(s)) n.push(s);
					else if (_h(s)) {
						let a = new Promise((u, c) => {
							s.subscribe({
								complete: u,
								error: c
							})
						});
						n.push(a)
					}
				}
				let i = () => {
					this.done = !0, this.resolve()
				};
				Promise.all(n).then(() => {
					i()
				}).catch(o => {
					this.reject(o)
				}), n.length === 0 && i(), this.initialized = !0
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Ar = new w("");

function uC() {
	al(() => {
		throw new I(600, !1)
	})
}

function cC(e) {
	return e.isBoundToModule
}

function lC(e, t, r) {
	try {
		let n = r();
		return sn(n) ? n.catch(i => {
			throw t.runOutsideAngular(() => e.handleError(i)), i
		}) : n
	} catch (n) {
		throw t.runOutsideAngular(() => e.handleError(n)), n
	}
}
var $n = (() => {
	let t = class t {
		constructor() {
			this._bootstrapListeners = [], this._runningTick = !1, this._destroyed = !1, this._destroyListeners = [], this._views = [], this.internalErrorHandler = p(bf), this.afterRenderEffectManager = p(Ou), this.externalTestViews = new Set, this.beforeRender = new X, this.afterTick = new X, this.componentTypes = [], this.components = [], this.isStable = p(nn).hasPendingTasks.pipe(A(n => !n)), this._injector = p(ge)
		}
		get destroyed() {
			return this._destroyed
		}
		get injector() {
			return this._injector
		}
		bootstrap(n, i) {
			let o = n instanceof to;
			if (!this._injector.get(Sh).done) {
				let h = !o && Od(n),
					m = !1;
				throw new I(405, m)
			}
			let a;
			o ? a = n : a = this._injector.get(Mo).resolveComponentFactory(n), this.componentTypes.push(a.componentType);
			let u = cC(a) ? void 0 : this._injector.get(Tt),
				c = i || a.selector,
				l = a.create(ft.NULL, [], c, u),
				d = l.location.nativeElement,
				f = l.injector.get(Mh, null);
			return f?.registerApplication(d), l.onDestroy(() => {
				this.detachView(l.hostView), Js(this.components, l), f?.unregisterApplication(d)
			}), this._loadComponent(l), l
		}
		tick() {
			this._tick(!0)
		}
		_tick(n) {
			if (this._runningTick) throw new I(101, !1);
			let i = k(null);
			try {
				this._runningTick = !0, this.detectChangesInAttachedViews(n)
			} catch (o) {
				this.internalErrorHandler(o)
			} finally {
				this.afterTick.next(), this._runningTick = !1, k(i)
			}
		}
		detectChangesInAttachedViews(n) {
			let i = 0,
				o = this.afterRenderEffectManager;
			for (;;) {
				if (i === uh) throw new I(103, !1);
				if (n) {
					let s = i === 0;
					this.beforeRender.next(s);
					for (let {
							_lView: a,
							notifyErrorHandler: u
						}
						of this._views) dC(a, s, u)
				}
				if (i++, o.executeInternalCallbacks(), ![...this.externalTestViews.keys(), ...this._views].some(({
						_lView: s
					}) => Wa(s)) && (o.execute(), ![...this.externalTestViews.keys(), ...this._views].some(({
						_lView: s
					}) => Wa(s)))) break
			}
		}
		attachView(n) {
			let i = n;
			this._views.push(i), i.attachToAppRef(this)
		}
		detachView(n) {
			let i = n;
			Js(this._views, i), i.detachFromAppRef()
		}
		_loadComponent(n) {
			this.attachView(n.hostView), this.tick(), this.components.push(n);
			let i = this._injector.get(Ar, []);
			[...this._bootstrapListeners, ...i].forEach(o => o(n))
		}
		ngOnDestroy() {
			if (!this._destroyed) try {
				this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy())
			} finally {
				this._destroyed = !0, this._views = [], this._bootstrapListeners = [], this._destroyListeners = []
			}
		}
		onDestroy(n) {
			return this._destroyListeners.push(n), () => Js(this._destroyListeners, n)
		}
		destroy() {
			if (this._destroyed) throw new I(406, !1);
			let n = this._injector;
			n.destroy && !n.destroyed && n.destroy()
		}
		get viewCount() {
			return this._views.length
		}
		warnIfDestroyed() {}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();

function Js(e, t) {
	let r = e.indexOf(t);
	r > -1 && e.splice(r, 1)
}

function dC(e, t, r) {
	!t && !Wa(e) || fC(e, r, t)
}

function Wa(e) {
	return ou(e)
}

function fC(e, t, r) {
	let n;
	r ? (n = 0, e[_] |= 1024) : e[_] & 64 ? n = 0 : n = 1, ch(e, t, n)
}
var Za = class {
		constructor(t, r) {
			this.ngModuleFactory = t, this.componentFactories = r
		}
	},
	Ro = (() => {
		let t = class t {
			compileModuleSync(n) {
				return new Pa(n)
			}
			compileModuleAsync(n) {
				return Promise.resolve(this.compileModuleSync(n))
			}
			compileModuleAndAllComponentsSync(n) {
				let i = this.compileModuleSync(n),
					o = Fd(n),
					s = Ff(o.declarations).reduce((a, u) => {
						let c = _t(u);
						return c && a.push(new Fn(c)), a
					}, []);
				return new Za(i, s)
			}
			compileModuleAndAllComponentsAsync(n) {
				return Promise.resolve(this.compileModuleAndAllComponentsSync(n))
			}
			clearCache() {}
			clearCacheFor(n) {}
			getModuleId(n) {}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})();
var hC = (() => {
	let t = class t {
		constructor() {
			this.zone = p(Z), this.applicationRef = p($n)
		}
		initialize() {
			this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({
				next: () => {
					this.zone.run(() => {
						this.applicationRef.tick()
					})
				}
			}))
		}
		ngOnDestroy() {
			this._onMicrotaskEmptySubscription?.unsubscribe()
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();

function pC(e) {
	return [{
		provide: Z,
		useFactory: e
	}, {
		provide: An,
		multi: !0,
		useFactory: () => {
			let t = p(hC, {
				optional: !0
			});
			return () => t.initialize()
		}
	}, {
		provide: An,
		multi: !0,
		useFactory: () => {
			let t = p(yC);
			return () => {
				t.initialize()
			}
		}
	}, {
		provide: bf,
		useFactory: gC
	}]
}

function gC() {
	let e = p(Z),
		t = p(Je);
	return r => e.runOutsideAngular(() => t.handleError(r))
}

function mC(e) {
	let t = pC(() => new Z(vC(e)));
	return kn([
		[], t
	])
}

function vC(e) {
	return {
		enableLongStackTrace: !1,
		shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1,
		shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1
	}
}
var yC = (() => {
	let t = class t {
		constructor() {
			this.subscription = new J, this.initialized = !1, this.zone = p(Z), this.pendingTasks = p(nn)
		}
		initialize() {
			if (this.initialized) return;
			this.initialized = !0;
			let n = null;
			!this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => {
				this.subscription.add(this.zone.onStable.subscribe(() => {
					Z.assertNotInAngularZone(), queueMicrotask(() => {
						n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null)
					})
				}))
			}), this.subscription.add(this.zone.onUnstable.subscribe(() => {
				Z.assertInAngularZone(), n ??= this.pendingTasks.add()
			}))
		}
		ngOnDestroy() {
			this.subscription.unsubscribe()
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();

function DC() {
	return typeof $localize < "u" && $localize.locale || so
}
var Lu = new w("", {
	providedIn: "root",
	factory: () => p(Lu, O.Optional | O.SkipSelf) || DC()
});
var Th = new w("");
var $i = null;

function wC(e = [], t) {
	return ft.create({
		name: t,
		providers: [{
			provide: fo,
			useValue: "platform"
		}, {
			provide: Th,
			useValue: new Set([() => $i = null])
		}, ...e]
	})
}

function CC(e = []) {
	if ($i) return $i;
	let t = wC(e);
	return $i = t, uC(), EC(t), t
}

function EC(e) {
	e.get(yu, null)?.forEach(r => r())
}
var an = (() => {
	let t = class t {};
	t.__NG_ELEMENT_ID__ = bC;
	let e = t;
	return e
})();

function bC(e) {
	return IC(Ce(), U(), (e & 16) === 16)
}

function IC(e, t, r) {
	if (po(e) && !r) {
		let n = At(e.index, t);
		return new Jt(n, n)
	} else if (e.type & 47) {
		let n = t[$e];
		return new Jt(n, t)
	}
	return null
}

function xh(e) {
	try {
		let {
			rootComponent: t,
			appProviders: r,
			platformProviders: n
		} = e, i = CC(n), o = [mC(), ...r || []], a = new ro({
			providers: o,
			parent: i,
			debugName: "",
			runEnvironmentInitializers: !1
		}).injector, u = a.get(Z);
		return u.run(() => {
			a.resolveInjectorInitializers();
			let c = a.get(Je, null),
				l;
			u.runOutsideAngular(() => {
				l = u.onError.subscribe({
					next: h => {
						c.handleError(h)
					}
				})
			});
			let d = () => a.destroy(),
				f = i.get(Th);
			return f.add(d), a.onDestroy(() => {
				l.unsubscribe(), f.delete(d)
			}), lC(c, u, () => {
				let h = a.get(Sh);
				return h.runInitializers(), h.donePromise.then(() => {
					let m = a.get(Lu, so);
					Kw(m || so);
					let S = a.get($n);
					return t !== void 0 && S.bootstrap(t), S
				})
			})
		})
	} catch (t) {
		return Promise.reject(t)
	}
}

function Bn(e) {
	return typeof e == "boolean" ? e : e != null && e !== "false"
}

function Ah(e) {
	let t = _t(e);
	if (!t) return null;
	let r = new Fn(t);
	return {
		get selector() {
			return r.selector
		},
		get type() {
			return r.componentType
		},
		get inputs() {
			return r.inputs
		},
		get outputs() {
			return r.outputs
		},
		get ngContentSelectors() {
			return r.ngContentSelectors
		},
		get isStandalone() {
			return t.standalone
		},
		get isSignal() {
			return t.signals
		}
	}
}
var Fh = null;

function mt() {
	return Fh
}

function Ph(e) {
	Fh ??= e
}
var Oo = class {};
var he = new w(""),
	Bu = (() => {
		let t = class t {
			historyGo(n) {
				throw new Error("")
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(MC),
			providedIn: "platform"
		});
		let e = t;
		return e
	})(),
	kh = new w(""),
	MC = (() => {
		let t = class t extends Bu {
			constructor() {
				super(), this._doc = p(he), this._location = window.location, this._history = window.history
			}
			getBaseHrefFromDOM() {
				return mt().getBaseHref(this._doc)
			}
			onPopState(n) {
				let i = mt().getGlobalEventTarget(this._doc, "window");
				return i.addEventListener("popstate", n, !1), () => i.removeEventListener("popstate", n)
			}
			onHashChange(n) {
				let i = mt().getGlobalEventTarget(this._doc, "window");
				return i.addEventListener("hashchange", n, !1), () => i.removeEventListener("hashchange", n)
			}
			get href() {
				return this._location.href
			}
			get protocol() {
				return this._location.protocol
			}
			get hostname() {
				return this._location.hostname
			}
			get port() {
				return this._location.port
			}
			get pathname() {
				return this._location.pathname
			}
			get search() {
				return this._location.search
			}
			get hash() {
				return this._location.hash
			}
			set pathname(n) {
				this._location.pathname = n
			}
			pushState(n, i, o) {
				this._history.pushState(n, i, o)
			}
			replaceState(n, i, o) {
				this._history.replaceState(n, i, o)
			}
			forward() {
				this._history.forward()
			}
			back() {
				this._history.back()
			}
			historyGo(n = 0) {
				this._history.go(n)
			}
			getState() {
				return this._history.state
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => new t,
			providedIn: "platform"
		});
		let e = t;
		return e
	})();

function Hu(e, t) {
	if (e.length == 0) return t;
	if (t.length == 0) return e;
	let r = 0;
	return e.endsWith("/") && r++, t.startsWith("/") && r++, r == 2 ? e + t.substring(1) : r == 1 ? e + t : e + "/" + t
}

function Nh(e) {
	let t = e.match(/#|\?|$/),
		r = t && t.index || e.length,
		n = r - (e[r - 1] === "/" ? 1 : 0);
	return e.slice(0, n) + e.slice(r)
}

function gt(e) {
	return e && e[0] !== "?" ? "?" + e : e
}
var vt = (() => {
		let t = class t {
			historyGo(n) {
				throw new Error("")
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(zu),
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Lh = new w(""),
	zu = (() => {
		let t = class t extends vt {
			constructor(n, i) {
				super(), this._platformLocation = n, this._removeListenerFns = [], this._baseHref = i ?? this._platformLocation.getBaseHrefFromDOM() ?? p(he).location?.origin ?? ""
			}
			ngOnDestroy() {
				for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
			}
			onPopState(n) {
				this._removeListenerFns.push(this._platformLocation.onPopState(n), this._platformLocation.onHashChange(n))
			}
			getBaseHref() {
				return this._baseHref
			}
			prepareExternalUrl(n) {
				return Hu(this._baseHref, n)
			}
			path(n = !1) {
				let i = this._platformLocation.pathname + gt(this._platformLocation.search),
					o = this._platformLocation.hash;
				return o && n ? `${i}${o}` : i
			}
			pushState(n, i, o, s) {
				let a = this.prepareExternalUrl(o + gt(s));
				this._platformLocation.pushState(n, i, a)
			}
			replaceState(n, i, o, s) {
				let a = this.prepareExternalUrl(o + gt(s));
				this._platformLocation.replaceState(n, i, a)
			}
			forward() {
				this._platformLocation.forward()
			}
			back() {
				this._platformLocation.back()
			}
			getState() {
				return this._platformLocation.getState()
			}
			historyGo(n = 0) {
				this._platformLocation.historyGo?.(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(Bu), M(Lh, 8))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Vh = (() => {
		let t = class t extends vt {
			constructor(n, i) {
				super(), this._platformLocation = n, this._baseHref = "", this._removeListenerFns = [], i != null && (this._baseHref = i)
			}
			ngOnDestroy() {
				for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
			}
			onPopState(n) {
				this._removeListenerFns.push(this._platformLocation.onPopState(n), this._platformLocation.onHashChange(n))
			}
			getBaseHref() {
				return this._baseHref
			}
			path(n = !1) {
				let i = this._platformLocation.hash ?? "#";
				return i.length > 0 ? i.substring(1) : i
			}
			prepareExternalUrl(n) {
				let i = Hu(this._baseHref, n);
				return i.length > 0 ? "#" + i : i
			}
			pushState(n, i, o, s) {
				let a = this.prepareExternalUrl(o + gt(s));
				a.length == 0 && (a = this._platformLocation.pathname), this._platformLocation.pushState(n, i, a)
			}
			replaceState(n, i, o, s) {
				let a = this.prepareExternalUrl(o + gt(s));
				a.length == 0 && (a = this._platformLocation.pathname), this._platformLocation.replaceState(n, i, a)
			}
			forward() {
				this._platformLocation.forward()
			}
			back() {
				this._platformLocation.back()
			}
			getState() {
				return this._platformLocation.getState()
			}
			historyGo(n = 0) {
				this._platformLocation.historyGo?.(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(Bu), M(Lh, 8))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	zn = (() => {
		let t = class t {
			constructor(n) {
				this._subject = new ie, this._urlChangeListeners = [], this._urlChangeSubscription = null, this._locationStrategy = n;
				let i = this._locationStrategy.getBaseHref();
				this._basePath = TC(Nh(Rh(i))), this._locationStrategy.onPopState(o => {
					this._subject.emit({
						url: this.path(!0),
						pop: !0,
						state: o.state,
						type: o.type
					})
				})
			}
			ngOnDestroy() {
				this._urlChangeSubscription?.unsubscribe(), this._urlChangeListeners = []
			}
			path(n = !1) {
				return this.normalize(this._locationStrategy.path(n))
			}
			getState() {
				return this._locationStrategy.getState()
			}
			isCurrentPathEqualTo(n, i = "") {
				return this.path() == this.normalize(n + gt(i))
			}
			normalize(n) {
				return t.stripTrailingSlash(SC(this._basePath, Rh(n)))
			}
			prepareExternalUrl(n) {
				return n && n[0] !== "/" && (n = "/" + n), this._locationStrategy.prepareExternalUrl(n)
			}
			go(n, i = "", o = null) {
				this._locationStrategy.pushState(o, "", n, i), this._notifyUrlChangeListeners(this.prepareExternalUrl(n + gt(i)), o)
			}
			replaceState(n, i = "", o = null) {
				this._locationStrategy.replaceState(o, "", n, i), this._notifyUrlChangeListeners(this.prepareExternalUrl(n + gt(i)), o)
			}
			forward() {
				this._locationStrategy.forward()
			}
			back() {
				this._locationStrategy.back()
			}
			historyGo(n = 0) {
				this._locationStrategy.historyGo?.(n)
			}
			onUrlChange(n) {
				return this._urlChangeListeners.push(n), this._urlChangeSubscription ??= this.subscribe(i => {
					this._notifyUrlChangeListeners(i.url, i.state)
				}), () => {
					let i = this._urlChangeListeners.indexOf(n);
					this._urlChangeListeners.splice(i, 1), this._urlChangeListeners.length === 0 && (this._urlChangeSubscription?.unsubscribe(), this._urlChangeSubscription = null)
				}
			}
			_notifyUrlChangeListeners(n = "", i) {
				this._urlChangeListeners.forEach(o => o(n, i))
			}
			subscribe(n, i, o) {
				return this._subject.subscribe({
					next: n,
					error: i,
					complete: o
				})
			}
		};
		t.normalizeQueryParams = gt, t.joinWithSlash = Hu, t.stripTrailingSlash = Nh, t.\u0275fac = function(i) {
			return new(i || t)(M(vt))
		}, t.\u0275prov = C({
			token: t,
			factory: () => _C(),
			providedIn: "root"
		});
		let e = t;
		return e
	})();

function _C() {
	return new zn(M(vt))
}

function SC(e, t) {
	if (!e || !t.startsWith(e)) return t;
	let r = t.substring(e.length);
	return r === "" || ["/", ";", "?", "#"].includes(r[0]) ? r : t
}

function Rh(e) {
	return e.replace(/\/index.html$/, "")
}

function TC(e) {
	if (new RegExp("^(https?:)?//").test(e)) {
		let [, r] = e.split(/\/\/[^\/]+/);
		return r
	}
	return e
}

function Fo(e, t) {
	t = encodeURIComponent(t);
	for (let r of e.split(";")) {
		let n = r.indexOf("="),
			[i, o] = n == -1 ? [r, ""] : [r.slice(0, n), r.slice(n + 1)];
		if (i.trim() === t) return decodeURIComponent(o)
	}
	return null
}
var Vu = /\s+/,
	Oh = [],
	jh = (() => {
		let t = class t {
			constructor(n, i) {
				this._ngEl = n, this._renderer = i, this.initialClasses = Oh, this.stateMap = new Map
			}
			set klass(n) {
				this.initialClasses = n != null ? n.trim().split(Vu) : Oh
			}
			set ngClass(n) {
				this.rawClass = typeof n == "string" ? n.trim().split(Vu) : n
			}
			ngDoCheck() {
				for (let i of this.initialClasses) this._updateState(i, !0);
				let n = this.rawClass;
				if (Array.isArray(n) || n instanceof Set)
					for (let i of n) this._updateState(i, !0);
				else if (n != null)
					for (let i of Object.keys(n)) this._updateState(i, !!n[i]);
				this._applyStateDiff()
			}
			_updateState(n, i) {
				let o = this.stateMap.get(n);
				o !== void 0 ? (o.enabled !== i && (o.changed = !0, o.enabled = i), o.touched = !0) : this.stateMap.set(n, {
					enabled: i,
					changed: !0,
					touched: !0
				})
			}
			_applyStateDiff() {
				for (let n of this.stateMap) {
					let i = n[0],
						o = n[1];
					o.changed ? (this._toggleClass(i, o.enabled), o.changed = !1) : o.touched || (o.enabled && this._toggleClass(i, !1), this.stateMap.delete(i)), o.touched = !1
				}
			}
			_toggleClass(n, i) {
				n = n.trim(), n.length > 0 && n.split(Vu).forEach(o => {
					i ? this._renderer.addClass(this._ngEl.nativeElement, o) : this._renderer.removeClass(this._ngEl.nativeElement, o)
				})
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(Se), $(ht))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "ngClass", ""]
			],
			inputs: {
				klass: [le.None, "class", "klass"],
				ngClass: "ngClass"
			},
			standalone: !0
		});
		let e = t;
		return e
	})();
var Gu = (() => {
		let t = class t {};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275mod = et({
			type: t
		}), t.\u0275inj = Xe({});
		let e = t;
		return e
	})(),
	qu = "browser",
	xC = "server";

function AC(e) {
	return e === qu
}

function Wu(e) {
	return e === xC
}
var Uh = (() => {
		let t = class t {};
		t.\u0275prov = C({
			token: t,
			providedIn: "root",
			factory: () => AC(p(tt)) ? new ju(p(he), window) : new Uu
		});
		let e = t;
		return e
	})(),
	ju = class {
		constructor(t, r) {
			this.document = t, this.window = r, this.offset = () => [0, 0]
		}
		setOffset(t) {
			Array.isArray(t) ? this.offset = () => t : this.offset = t
		}
		getScrollPosition() {
			return [this.window.scrollX, this.window.scrollY]
		}
		scrollToPosition(t) {
			this.window.scrollTo(t[0], t[1])
		}
		scrollToAnchor(t) {
			let r = NC(this.document, t);
			r && (this.scrollToElement(r), r.focus())
		}
		setHistoryScrollRestoration(t) {
			this.window.history.scrollRestoration = t
		}
		scrollToElement(t) {
			let r = t.getBoundingClientRect(),
				n = r.left + this.window.pageXOffset,
				i = r.top + this.window.pageYOffset,
				o = this.offset();
			this.window.scrollTo(n - o[0], i - o[1])
		}
	};

function NC(e, t) {
	let r = e.getElementById(t) || e.getElementsByName(t)[0];
	if (r) return r;
	if (typeof e.createTreeWalker == "function" && e.body && typeof e.body.attachShadow == "function") {
		let n = e.createTreeWalker(e.body, NodeFilter.SHOW_ELEMENT),
			i = n.currentNode;
		for (; i;) {
			let o = i.shadowRoot;
			if (o) {
				let s = o.getElementById(t) || o.querySelector(`[name="${t}"]`);
				if (s) return s
			}
			i = n.nextNode()
		}
	}
	return null
}
var Uu = class {
		setOffset(t) {}
		getScrollPosition() {
			return [0, 0]
		}
		scrollToPosition(t) {}
		scrollToAnchor(t) {}
		setHistoryScrollRestoration(t) {}
	},
	Hn = class {};
var Rr = class {},
	ko = class {},
	un = class e {
		constructor(t) {
			this.normalizedNames = new Map, this.lazyUpdate = null, t ? typeof t == "string" ? this.lazyInit = () => {
				this.headers = new Map, t.split(`
`).forEach(r => {
					let n = r.indexOf(":");
					if (n > 0) {
						let i = r.slice(0, n),
							o = i.toLowerCase(),
							s = r.slice(n + 1).trim();
						this.maybeSetNormalizedName(i, o), this.headers.has(o) ? this.headers.get(o).push(s) : this.headers.set(o, [s])
					}
				})
			} : typeof Headers < "u" && t instanceof Headers ? (this.headers = new Map, t.forEach((r, n) => {
				this.setHeaderEntries(n, r)
			})) : this.lazyInit = () => {
				this.headers = new Map, Object.entries(t).forEach(([r, n]) => {
					this.setHeaderEntries(r, n)
				})
			} : this.headers = new Map
		}
		has(t) {
			return this.init(), this.headers.has(t.toLowerCase())
		}
		get(t) {
			this.init();
			let r = this.headers.get(t.toLowerCase());
			return r && r.length > 0 ? r[0] : null
		}
		keys() {
			return this.init(), Array.from(this.normalizedNames.values())
		}
		getAll(t) {
			return this.init(), this.headers.get(t.toLowerCase()) || null
		}
		append(t, r) {
			return this.clone({
				name: t,
				value: r,
				op: "a"
			})
		}
		set(t, r) {
			return this.clone({
				name: t,
				value: r,
				op: "s"
			})
		}
		delete(t, r) {
			return this.clone({
				name: t,
				value: r,
				op: "d"
			})
		}
		maybeSetNormalizedName(t, r) {
			this.normalizedNames.has(r) || this.normalizedNames.set(r, t)
		}
		init() {
			this.lazyInit && (this.lazyInit instanceof e ? this.copyFrom(this.lazyInit) : this.lazyInit(), this.lazyInit = null, this.lazyUpdate && (this.lazyUpdate.forEach(t => this.applyUpdate(t)), this.lazyUpdate = null))
		}
		copyFrom(t) {
			t.init(), Array.from(t.headers.keys()).forEach(r => {
				this.headers.set(r, t.headers.get(r)), this.normalizedNames.set(r, t.normalizedNames.get(r))
			})
		}
		clone(t) {
			let r = new e;
			return r.lazyInit = this.lazyInit && this.lazyInit instanceof e ? this.lazyInit : this, r.lazyUpdate = (this.lazyUpdate || []).concat([t]), r
		}
		applyUpdate(t) {
			let r = t.name.toLowerCase();
			switch (t.op) {
				case "a":
				case "s":
					let n = t.value;
					if (typeof n == "string" && (n = [n]), n.length === 0) return;
					this.maybeSetNormalizedName(t.name, r);
					let i = (t.op === "a" ? this.headers.get(r) : void 0) || [];
					i.push(...n), this.headers.set(r, i);
					break;
				case "d":
					let o = t.value;
					if (!o) this.headers.delete(r), this.normalizedNames.delete(r);
					else {
						let s = this.headers.get(r);
						if (!s) return;
						s = s.filter(a => o.indexOf(a) === -1), s.length === 0 ? (this.headers.delete(r), this.normalizedNames.delete(r)) : this.headers.set(r, s)
					}
					break
			}
		}
		setHeaderEntries(t, r) {
			let n = (Array.isArray(r) ? r : [r]).map(o => o.toString()),
				i = t.toLowerCase();
			this.headers.set(i, n), this.maybeSetNormalizedName(t, i)
		}
		forEach(t) {
			this.init(), Array.from(this.normalizedNames.keys()).forEach(r => t(this.normalizedNames.get(r), this.headers.get(r)))
		}
	};
var Qu = class {
	encodeKey(t) {
		return $h(t)
	}
	encodeValue(t) {
		return $h(t)
	}
	decodeKey(t) {
		return decodeURIComponent(t)
	}
	decodeValue(t) {
		return decodeURIComponent(t)
	}
};

function FC(e, t) {
	let r = new Map;
	return e.length > 0 && e.replace(/^\?/, "").split("&").forEach(i => {
		let o = i.indexOf("="),
			[s, a] = o == -1 ? [t.decodeKey(i), ""] : [t.decodeKey(i.slice(0, o)), t.decodeValue(i.slice(o + 1))],
			u = r.get(s) || [];
		u.push(a), r.set(s, u)
	}), r
}
var PC = /%(\d[a-f0-9])/gi,
	kC = {
		40: "@",
		"3A": ":",
		24: "$",
		"2C": ",",
		"3B": ";",
		"3D": "=",
		"3F": "?",
		"2F": "/"
	};

function $h(e) {
	return encodeURIComponent(e).replace(PC, (t, r) => kC[r] ?? t)
}

function Po(e) {
	return `${e}`
}
var Ot = class e {
	constructor(t = {}) {
		if (this.updates = null, this.cloneFrom = null, this.encoder = t.encoder || new Qu, t.fromString) {
			if (t.fromObject) throw new Error("Cannot specify both fromString and fromObject.");
			this.map = FC(t.fromString, this.encoder)
		} else t.fromObject ? (this.map = new Map, Object.keys(t.fromObject).forEach(r => {
			let n = t.fromObject[r],
				i = Array.isArray(n) ? n.map(Po) : [Po(n)];
			this.map.set(r, i)
		})) : this.map = null
	}
	has(t) {
		return this.init(), this.map.has(t)
	}
	get(t) {
		this.init();
		let r = this.map.get(t);
		return r ? r[0] : null
	}
	getAll(t) {
		return this.init(), this.map.get(t) || null
	}
	keys() {
		return this.init(), Array.from(this.map.keys())
	}
	append(t, r) {
		return this.clone({
			param: t,
			value: r,
			op: "a"
		})
	}
	appendAll(t) {
		let r = [];
		return Object.keys(t).forEach(n => {
			let i = t[n];
			Array.isArray(i) ? i.forEach(o => {
				r.push({
					param: n,
					value: o,
					op: "a"
				})
			}) : r.push({
				param: n,
				value: i,
				op: "a"
			})
		}), this.clone(r)
	}
	set(t, r) {
		return this.clone({
			param: t,
			value: r,
			op: "s"
		})
	}
	delete(t, r) {
		return this.clone({
			param: t,
			value: r,
			op: "d"
		})
	}
	toString() {
		return this.init(), this.keys().map(t => {
			let r = this.encoder.encodeKey(t);
			return this.map.get(t).map(n => r + "=" + this.encoder.encodeValue(n)).join("&")
		}).filter(t => t !== "").join("&")
	}
	clone(t) {
		let r = new e({
			encoder: this.encoder
		});
		return r.cloneFrom = this.cloneFrom || this, r.updates = (this.updates || []).concat(t), r
	}
	init() {
		this.map === null && (this.map = new Map), this.cloneFrom !== null && (this.cloneFrom.init(), this.cloneFrom.keys().forEach(t => this.map.set(t, this.cloneFrom.map.get(t))), this.updates.forEach(t => {
			switch (t.op) {
				case "a":
				case "s":
					let r = (t.op === "a" ? this.map.get(t.param) : void 0) || [];
					r.push(Po(t.value)), this.map.set(t.param, r);
					break;
				case "d":
					if (t.value !== void 0) {
						let n = this.map.get(t.param) || [],
							i = n.indexOf(Po(t.value));
						i !== -1 && n.splice(i, 1), n.length > 0 ? this.map.set(t.param, n) : this.map.delete(t.param)
					} else {
						this.map.delete(t.param);
						break
					}
			}
		}), this.cloneFrom = this.updates = null)
	}
};
var Ku = class {
	constructor() {
		this.map = new Map
	}
	set(t, r) {
		return this.map.set(t, r), this
	}
	get(t) {
		return this.map.has(t) || this.map.set(t, t.defaultValue()), this.map.get(t)
	}
	delete(t) {
		return this.map.delete(t), this
	}
	has(t) {
		return this.map.has(t)
	}
	keys() {
		return this.map.keys()
	}
};

function LC(e) {
	switch (e) {
		case "DELETE":
		case "GET":
		case "HEAD":
		case "OPTIONS":
		case "JSONP":
			return !1;
		default:
			return !0
	}
}

function Bh(e) {
	return typeof ArrayBuffer < "u" && e instanceof ArrayBuffer
}

function Hh(e) {
	return typeof Blob < "u" && e instanceof Blob
}

function zh(e) {
	return typeof FormData < "u" && e instanceof FormData
}

function VC(e) {
	return typeof URLSearchParams < "u" && e instanceof URLSearchParams
}
var Nr = class e {
		constructor(t, r, n, i) {
			this.url = r, this.body = null, this.reportProgress = !1, this.withCredentials = !1, this.responseType = "json", this.method = t.toUpperCase();
			let o;
			if (LC(this.method) || i ? (this.body = n !== void 0 ? n : null, o = i) : o = n, o && (this.reportProgress = !!o.reportProgress, this.withCredentials = !!o.withCredentials, o.responseType && (this.responseType = o.responseType), o.headers && (this.headers = o.headers), o.context && (this.context = o.context), o.params && (this.params = o.params), this.transferCache = o.transferCache), this.headers ??= new un, this.context ??= new Ku, !this.params) this.params = new Ot, this.urlWithParams = r;
			else {
				let s = this.params.toString();
				if (s.length === 0) this.urlWithParams = r;
				else {
					let a = r.indexOf("?"),
						u = a === -1 ? "?" : a < r.length - 1 ? "&" : "";
					this.urlWithParams = r + u + s
				}
			}
		}
		serializeBody() {
			return this.body === null ? null : typeof this.body == "string" || Bh(this.body) || Hh(this.body) || zh(this.body) || VC(this.body) ? this.body : this.body instanceof Ot ? this.body.toString() : typeof this.body == "object" || typeof this.body == "boolean" || Array.isArray(this.body) ? JSON.stringify(this.body) : this.body.toString()
		}
		detectContentTypeHeader() {
			return this.body === null || zh(this.body) ? null : Hh(this.body) ? this.body.type || null : Bh(this.body) ? null : typeof this.body == "string" ? "text/plain" : this.body instanceof Ot ? "application/x-www-form-urlencoded;charset=UTF-8" : typeof this.body == "object" || typeof this.body == "number" || typeof this.body == "boolean" ? "application/json" : null
		}
		clone(t = {}) {
			let r = t.method || this.method,
				n = t.url || this.url,
				i = t.responseType || this.responseType,
				o = t.transferCache ?? this.transferCache,
				s = t.body !== void 0 ? t.body : this.body,
				a = t.withCredentials ?? this.withCredentials,
				u = t.reportProgress ?? this.reportProgress,
				c = t.headers || this.headers,
				l = t.params || this.params,
				d = t.context ?? this.context;
			return t.setHeaders !== void 0 && (c = Object.keys(t.setHeaders).reduce((f, h) => f.set(h, t.setHeaders[h]), c)), t.setParams && (l = Object.keys(t.setParams).reduce((f, h) => f.set(h, t.setParams[h]), l)), new e(r, n, s, {
				params: l,
				headers: c,
				context: d,
				reportProgress: u,
				responseType: i,
				withCredentials: a,
				transferCache: o
			})
		}
	},
	Gn = function(e) {
		return e[e.Sent = 0] = "Sent", e[e.UploadProgress = 1] = "UploadProgress", e[e.ResponseHeader = 2] = "ResponseHeader", e[e.DownloadProgress = 3] = "DownloadProgress", e[e.Response = 4] = "Response", e[e.User = 5] = "User", e
	}(Gn || {}),
	Or = class {
		constructor(t, r = jo.Ok, n = "OK") {
			this.headers = t.headers || new un, this.status = t.status !== void 0 ? t.status : r, this.statusText = t.statusText || n, this.url = t.url || null, this.ok = this.status >= 200 && this.status < 300
		}
	},
	Ju = class e extends Or {
		constructor(t = {}) {
			super(t), this.type = Gn.ResponseHeader
		}
		clone(t = {}) {
			return new e({
				headers: t.headers || this.headers,
				status: t.status !== void 0 ? t.status : this.status,
				statusText: t.statusText || this.statusText,
				url: t.url || this.url || void 0
			})
		}
	},
	Lo = class e extends Or {
		constructor(t = {}) {
			super(t), this.type = Gn.Response, this.body = t.body !== void 0 ? t.body : null
		}
		clone(t = {}) {
			return new e({
				body: t.body !== void 0 ? t.body : this.body,
				headers: t.headers || this.headers,
				status: t.status !== void 0 ? t.status : this.status,
				statusText: t.statusText || this.statusText,
				url: t.url || this.url || void 0
			})
		}
	},
	Vo = class extends Or {
		constructor(t) {
			super(t, 0, "Unknown Error"), this.name = "HttpErrorResponse", this.ok = !1, this.status >= 200 && this.status < 300 ? this.message = `Http failure during parsing for ${t.url||"(unknown url)"}` : this.message = `Http failure response for ${t.url||"(unknown url)"}: ${t.status} ${t.statusText}`, this.error = t.error || null
		}
	},
	jo = function(e) {
		return e[e.Continue = 100] = "Continue", e[e.SwitchingProtocols = 101] = "SwitchingProtocols", e[e.Processing = 102] = "Processing", e[e.EarlyHints = 103] = "EarlyHints", e[e.Ok = 200] = "Ok", e[e.Created = 201] = "Created", e[e.Accepted = 202] = "Accepted", e[e.NonAuthoritativeInformation = 203] = "NonAuthoritativeInformation", e[e.NoContent = 204] = "NoContent", e[e.ResetContent = 205] = "ResetContent", e[e.PartialContent = 206] = "PartialContent", e[e.MultiStatus = 207] = "MultiStatus", e[e.AlreadyReported = 208] = "AlreadyReported", e[e.ImUsed = 226] = "ImUsed", e[e.MultipleChoices = 300] = "MultipleChoices", e[e.MovedPermanently = 301] = "MovedPermanently", e[e.Found = 302] = "Found", e[e.SeeOther = 303] = "SeeOther", e[e.NotModified = 304] = "NotModified", e[e.UseProxy = 305] = "UseProxy", e[e.Unused = 306] = "Unused", e[e.TemporaryRedirect = 307] = "TemporaryRedirect", e[e.PermanentRedirect = 308] = "PermanentRedirect", e[e.BadRequest = 400] = "BadRequest", e[e.Unauthorized = 401] = "Unauthorized", e[e.PaymentRequired = 402] = "PaymentRequired", e[e.Forbidden = 403] = "Forbidden", e[e.NotFound = 404] = "NotFound", e[e.MethodNotAllowed = 405] = "MethodNotAllowed", e[e.NotAcceptable = 406] = "NotAcceptable", e[e.ProxyAuthenticationRequired = 407] = "ProxyAuthenticationRequired", e[e.RequestTimeout = 408] = "RequestTimeout", e[e.Conflict = 409] = "Conflict", e[e.Gone = 410] = "Gone", e[e.LengthRequired = 411] = "LengthRequired", e[e.PreconditionFailed = 412] = "PreconditionFailed", e[e.PayloadTooLarge = 413] = "PayloadTooLarge", e[e.UriTooLong = 414] = "UriTooLong", e[e.UnsupportedMediaType = 415] = "UnsupportedMediaType", e[e.RangeNotSatisfiable = 416] = "RangeNotSatisfiable", e[e.ExpectationFailed = 417] = "ExpectationFailed", e[e.ImATeapot = 418] = "ImATeapot", e[e.MisdirectedRequest = 421] = "MisdirectedRequest", e[e.UnprocessableEntity = 422] = "UnprocessableEntity", e[e.Locked = 423] = "Locked", e[e.FailedDependency = 424] = "FailedDependency", e[e.TooEarly = 425] = "TooEarly", e[e.UpgradeRequired = 426] = "UpgradeRequired", e[e.PreconditionRequired = 428] = "PreconditionRequired", e[e.TooManyRequests = 429] = "TooManyRequests", e[e.RequestHeaderFieldsTooLarge = 431] = "RequestHeaderFieldsTooLarge", e[e.UnavailableForLegalReasons = 451] = "UnavailableForLegalReasons", e[e.InternalServerError = 500] = "InternalServerError", e[e.NotImplemented = 501] = "NotImplemented", e[e.BadGateway = 502] = "BadGateway", e[e.ServiceUnavailable = 503] = "ServiceUnavailable", e[e.GatewayTimeout = 504] = "GatewayTimeout", e[e.HttpVersionNotSupported = 505] = "HttpVersionNotSupported", e[e.VariantAlsoNegotiates = 506] = "VariantAlsoNegotiates", e[e.InsufficientStorage = 507] = "InsufficientStorage", e[e.LoopDetected = 508] = "LoopDetected", e[e.NotExtended = 510] = "NotExtended", e[e.NetworkAuthenticationRequired = 511] = "NetworkAuthenticationRequired", e
	}(jo || {});

function Yu(e, t) {
	return {
		body: t,
		headers: e.headers,
		context: e.context,
		observe: e.observe,
		params: e.params,
		reportProgress: e.reportProgress,
		responseType: e.responseType,
		withCredentials: e.withCredentials,
		transferCache: e.transferCache
	}
}
var jC = (() => {
	let t = class t {
		constructor(n) {
			this.handler = n
		}
		request(n, i, o = {}) {
			let s;
			if (n instanceof Nr) s = n;
			else {
				let c;
				o.headers instanceof un ? c = o.headers : c = new un(o.headers);
				let l;
				o.params && (o.params instanceof Ot ? l = o.params : l = new Ot({
					fromObject: o.params
				})), s = new Nr(n, i, o.body !== void 0 ? o.body : null, {
					headers: c,
					context: o.context,
					params: l,
					reportProgress: o.reportProgress,
					responseType: o.responseType || "json",
					withCredentials: o.withCredentials,
					transferCache: o.transferCache
				})
			}
			let a = b(s).pipe(st(c => this.handler.handle(c)));
			if (n instanceof Nr || o.observe === "events") return a;
			let u = a.pipe(ve(c => c instanceof Lo));
			switch (o.observe || "body") {
				case "body":
					switch (s.responseType) {
						case "arraybuffer":
							return u.pipe(A(c => {
								if (c.body !== null && !(c.body instanceof ArrayBuffer)) throw new Error("Response is not an ArrayBuffer.");
								return c.body
							}));
						case "blob":
							return u.pipe(A(c => {
								if (c.body !== null && !(c.body instanceof Blob)) throw new Error("Response is not a Blob.");
								return c.body
							}));
						case "text":
							return u.pipe(A(c => {
								if (c.body !== null && typeof c.body != "string") throw new Error("Response is not a string.");
								return c.body
							}));
						case "json":
						default:
							return u.pipe(A(c => c.body))
					}
				case "response":
					return u;
				default:
					throw new Error(`Unreachable: unhandled observe type ${o.observe}}`)
			}
		}
		delete(n, i = {}) {
			return this.request("DELETE", n, i)
		}
		get(n, i = {}) {
			return this.request("GET", n, i)
		}
		head(n, i = {}) {
			return this.request("HEAD", n, i)
		}
		jsonp(n, i) {
			return this.request("JSONP", n, {
				params: new Ot().append(i, "JSONP_CALLBACK"),
				observe: "body",
				responseType: "json"
			})
		}
		options(n, i = {}) {
			return this.request("OPTIONS", n, i)
		}
		patch(n, i, o = {}) {
			return this.request("PATCH", n, Yu(o, i))
		}
		post(n, i, o = {}) {
			return this.request("POST", n, Yu(o, i))
		}
		put(n, i, o = {}) {
			return this.request("PUT", n, Yu(o, i))
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)(M(Rr))
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac
	});
	let e = t;
	return e
})();

function Zh(e, t) {
	return t(e)
}

function UC(e, t) {
	return (r, n) => t.intercept(r, {
		handle: i => e(i, n)
	})
}

function $C(e, t, r) {
	return (n, i) => He(r, () => t(n, o => e(o, i)))
}
var BC = new w(""),
	Xu = new w(""),
	HC = new w(""),
	zC = new w("");

function GC() {
	let e = null;
	return (t, r) => {
		e === null && (e = (p(BC, {
			optional: !0
		}) ?? []).reduceRight(UC, Zh));
		let n = p(nn),
			i = n.add();
		return e(t, r).pipe(bt(() => n.remove(i)))
	}
}
var Gh = (() => {
	let t = class t extends Rr {
		constructor(n, i) {
			super(), this.backend = n, this.injector = i, this.chain = null, this.pendingTasks = p(nn);
			let o = p(zC, {
				optional: !0
			});
			this.backend = o ?? n
		}
		handle(n) {
			if (this.chain === null) {
				let o = Array.from(new Set([...this.injector.get(Xu), ...this.injector.get(HC, [])]));
				this.chain = o.reduceRight((s, a) => $C(s, a, this.injector), Zh)
			}
			let i = this.pendingTasks.add();
			return this.chain(n, o => this.backend.handle(o)).pipe(bt(() => this.pendingTasks.remove(i)))
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)(M(ko), M(ge))
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac
	});
	let e = t;
	return e
})();
var qC = /^\)\]\}',?\n/;

function WC(e) {
	return "responseURL" in e && e.responseURL ? e.responseURL : /^X-Request-URL:/m.test(e.getAllResponseHeaders()) ? e.getResponseHeader("X-Request-URL") : null
}
var qh = (() => {
		let t = class t {
			constructor(n) {
				this.xhrFactory = n
			}
			handle(n) {
				if (n.method === "JSONP") throw new I(-2800, !1);
				let i = this.xhrFactory;
				return (i.\u0275loadImpl ? G(i.\u0275loadImpl()) : b(null)).pipe(ye(() => new V(s => {
					let a = i.build();
					if (a.open(n.method, n.urlWithParams), n.withCredentials && (a.withCredentials = !0), n.headers.forEach((E, D) => a.setRequestHeader(E, D.join(","))), n.headers.has("Accept") || a.setRequestHeader("Accept", "application/json, text/plain, */*"), !n.headers.has("Content-Type")) {
						let E = n.detectContentTypeHeader();
						E !== null && a.setRequestHeader("Content-Type", E)
					}
					if (n.responseType) {
						let E = n.responseType.toLowerCase();
						a.responseType = E !== "json" ? E : "text"
					}
					let u = n.serializeBody(),
						c = null,
						l = () => {
							if (c !== null) return c;
							let E = a.statusText || "OK",
								D = new un(a.getAllResponseHeaders()),
								ae = WC(a) || n.url;
							return c = new Ju({
								headers: D,
								status: a.status,
								statusText: E,
								url: ae
							}), c
						},
						d = () => {
							let {
								headers: E,
								status: D,
								statusText: ae,
								url: re
							} = l(), q = null;
							D !== jo.NoContent && (q = typeof a.response > "u" ? a.responseText : a.response), D === 0 && (D = q ? jo.Ok : 0);
							let qe = D >= 200 && D < 300;
							if (n.responseType === "json" && typeof q == "string") {
								let Ee = q;
								q = q.replace(qC, "");
								try {
									q = q !== "" ? JSON.parse(q) : null
								} catch (yt) {
									q = Ee, qe && (qe = !1, q = {
										error: yt,
										text: q
									})
								}
							}
							qe ? (s.next(new Lo({
								body: q,
								headers: E,
								status: D,
								statusText: ae,
								url: re || void 0
							})), s.complete()) : s.error(new Vo({
								error: q,
								headers: E,
								status: D,
								statusText: ae,
								url: re || void 0
							}))
						},
						f = E => {
							let {
								url: D
							} = l(), ae = new Vo({
								error: E,
								status: a.status || 0,
								statusText: a.statusText || "Unknown Error",
								url: D || void 0
							});
							s.error(ae)
						},
						h = !1,
						m = E => {
							h || (s.next(l()), h = !0);
							let D = {
								type: Gn.DownloadProgress,
								loaded: E.loaded
							};
							E.lengthComputable && (D.total = E.total), n.responseType === "text" && a.responseText && (D.partialText = a.responseText), s.next(D)
						},
						S = E => {
							let D = {
								type: Gn.UploadProgress,
								loaded: E.loaded
							};
							E.lengthComputable && (D.total = E.total), s.next(D)
						};
					return a.addEventListener("load", d), a.addEventListener("error", f), a.addEventListener("timeout", f), a.addEventListener("abort", f), n.reportProgress && (a.addEventListener("progress", m), u !== null && a.upload && a.upload.addEventListener("progress", S)), a.send(u), s.next({
						type: Gn.Sent
					}), () => {
						a.removeEventListener("error", f), a.removeEventListener("abort", f), a.removeEventListener("load", d), a.removeEventListener("timeout", f), n.reportProgress && (a.removeEventListener("progress", m), u !== null && a.upload && a.upload.removeEventListener("progress", S)), a.readyState !== a.DONE && a.abort()
					}
				})))
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(Hn))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	Yh = new w(""),
	ZC = "XSRF-TOKEN",
	YC = new w("", {
		providedIn: "root",
		factory: () => ZC
	}),
	QC = "X-XSRF-TOKEN",
	KC = new w("", {
		providedIn: "root",
		factory: () => QC
	}),
	Uo = class {},
	JC = (() => {
		let t = class t {
			constructor(n, i, o) {
				this.doc = n, this.platform = i, this.cookieName = o, this.lastCookieString = "", this.lastToken = null, this.parseCount = 0
			}
			getToken() {
				if (this.platform === "server") return null;
				let n = this.doc.cookie || "";
				return n !== this.lastCookieString && (this.parseCount++, this.lastToken = Fo(n, this.cookieName), this.lastCookieString = n), this.lastToken
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(he), M(tt), M(YC))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})();

function XC(e, t) {
	let r = e.url.toLowerCase();
	if (!p(Yh) || e.method === "GET" || e.method === "HEAD" || r.startsWith("http://") || r.startsWith("https://")) return t(e);
	let n = p(Uo).getToken(),
		i = p(KC);
	return n != null && !e.headers.has(i) && (e = e.clone({
		headers: e.headers.set(i, n)
	})), t(e)
}
var Qh = function(e) {
	return e[e.Interceptors = 0] = "Interceptors", e[e.LegacyInterceptors = 1] = "LegacyInterceptors", e[e.CustomXsrfConfiguration = 2] = "CustomXsrfConfiguration", e[e.NoXsrfProtection = 3] = "NoXsrfProtection", e[e.JsonpSupport = 4] = "JsonpSupport", e[e.RequestsMadeViaParent = 5] = "RequestsMadeViaParent", e[e.Fetch = 6] = "Fetch", e
}(Qh || {});

function e0(e, t) {
	return {
		\u0275kind: e,
		\u0275providers: t
	}
}

function t0(...e) {
	let t = [jC, qh, Gh, {
		provide: Rr,
		useExisting: Gh
	}, {
		provide: ko,
		useExisting: qh
	}, {
		provide: Xu,
		useValue: XC,
		multi: !0
	}, {
		provide: Yh,
		useValue: !0
	}, {
		provide: Uo,
		useClass: JC
	}];
	for (let r of e) t.push(...r.\u0275providers);
	return kn(t)
}
var Wh = new w("");

function n0() {
	return e0(Qh.LegacyInterceptors, [{
		provide: Wh,
		useFactory: GC
	}, {
		provide: Xu,
		useExisting: Wh,
		multi: !0
	}])
}
var Kh = (() => {
	let t = class t {};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275mod = et({
		type: t
	}), t.\u0275inj = Xe({
		providers: [t0(n0())]
	});
	let e = t;
	return e
})();
var nc = class extends Oo {
		constructor() {
			super(...arguments), this.supportsDOMEvents = !0
		}
	},
	rc = class e extends nc {
		static makeCurrent() {
			Ph(new e)
		}
		onAndCancel(t, r, n) {
			return t.addEventListener(r, n), () => {
				t.removeEventListener(r, n)
			}
		}
		dispatchEvent(t, r) {
			t.dispatchEvent(r)
		}
		remove(t) {
			t.parentNode && t.parentNode.removeChild(t)
		}
		createElement(t, r) {
			return r = r || this.getDefaultDocument(), r.createElement(t)
		}
		createHtmlDocument() {
			return document.implementation.createHTMLDocument("fakeTitle")
		}
		getDefaultDocument() {
			return document
		}
		isElementNode(t) {
			return t.nodeType === Node.ELEMENT_NODE
		}
		isShadowRoot(t) {
			return t instanceof DocumentFragment
		}
		getGlobalEventTarget(t, r) {
			return r === "window" ? window : r === "document" ? t : r === "body" ? t.body : null
		}
		getBaseHref(t) {
			let r = r0();
			return r == null ? null : i0(r)
		}
		resetBaseElement() {
			Fr = null
		}
		getUserAgent() {
			return window.navigator.userAgent
		}
		getCookie(t) {
			return Fo(document.cookie, t)
		}
	},
	Fr = null;

function r0() {
	return Fr = Fr || document.querySelector("base"), Fr ? Fr.getAttribute("href") : null
}

function i0(e) {
	return new URL(e, document.baseURI).pathname
}
var o0 = (() => {
		let t = class t {
			build() {
				return new XMLHttpRequest
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	ic = new w(""),
	tp = (() => {
		let t = class t {
			constructor(n, i) {
				this._zone = i, this._eventNameToPlugin = new Map, n.forEach(o => {
					o.manager = this
				}), this._plugins = n.slice().reverse()
			}
			addEventListener(n, i, o) {
				return this._findPluginFor(i).addEventListener(n, i, o)
			}
			getZone() {
				return this._zone
			}
			_findPluginFor(n) {
				let i = this._eventNameToPlugin.get(n);
				if (i) return i;
				if (i = this._plugins.find(s => s.supports(n)), !i) throw new I(5101, !1);
				return this._eventNameToPlugin.set(n, i), i
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(ic), M(Z))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	$o = class {
		constructor(t) {
			this._doc = t
		}
	},
	ec = "ng-app-id",
	np = (() => {
		let t = class t {
			constructor(n, i, o, s = {}) {
				this.doc = n, this.appId = i, this.nonce = o, this.platformId = s, this.styleRef = new Map, this.hostNodes = new Set, this.styleNodesInDOM = this.collectServerRenderedStyles(), this.platformIsServer = Wu(s), this.resetHostNodes()
			}
			addStyles(n) {
				for (let i of n) this.changeUsageCount(i, 1) === 1 && this.onStyleAdded(i)
			}
			removeStyles(n) {
				for (let i of n) this.changeUsageCount(i, -1) <= 0 && this.onStyleRemoved(i)
			}
			ngOnDestroy() {
				let n = this.styleNodesInDOM;
				n && (n.forEach(i => i.remove()), n.clear());
				for (let i of this.getAllStyles()) this.onStyleRemoved(i);
				this.resetHostNodes()
			}
			addHost(n) {
				this.hostNodes.add(n);
				for (let i of this.getAllStyles()) this.addStyleToHost(n, i)
			}
			removeHost(n) {
				this.hostNodes.delete(n)
			}
			getAllStyles() {
				return this.styleRef.keys()
			}
			onStyleAdded(n) {
				for (let i of this.hostNodes) this.addStyleToHost(i, n)
			}
			onStyleRemoved(n) {
				let i = this.styleRef;
				i.get(n)?.elements?.forEach(o => o.remove()), i.delete(n)
			}
			collectServerRenderedStyles() {
				let n = this.doc.head?.querySelectorAll(`style[${ec}="${this.appId}"]`);
				if (n?.length) {
					let i = new Map;
					return n.forEach(o => {
						o.textContent != null && i.set(o.textContent, o)
					}), i
				}
				return null
			}
			changeUsageCount(n, i) {
				let o = this.styleRef;
				if (o.has(n)) {
					let s = o.get(n);
					return s.usage += i, s.usage
				}
				return o.set(n, {
					usage: i,
					elements: []
				}), i
			}
			getStyleElement(n, i) {
				let o = this.styleNodesInDOM,
					s = o?.get(i);
				if (s?.parentNode === n) return o.delete(i), s.removeAttribute(ec), s;
				{
					let a = this.doc.createElement("style");
					return this.nonce && a.setAttribute("nonce", this.nonce), a.textContent = i, this.platformIsServer && a.setAttribute(ec, this.appId), n.appendChild(a), a
				}
			}
			addStyleToHost(n, i) {
				let o = this.getStyleElement(n, i),
					s = this.styleRef,
					a = s.get(i)?.elements;
				a ? a.push(o) : s.set(i, {
					elements: [o],
					usage: 1
				})
			}
			resetHostNodes() {
				let n = this.hostNodes;
				n.clear(), n.add(this.doc.head)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(he), M(vu), M(Du, 8), M(tt))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	tc = {
		svg: "http://www.w3.org/2000/svg",
		xhtml: "http://www.w3.org/1999/xhtml",
		xlink: "http://www.w3.org/1999/xlink",
		xml: "http://www.w3.org/XML/1998/namespace",
		xmlns: "http://www.w3.org/2000/xmlns/",
		math: "http://www.w3.org/1998/MathML/"
	},
	sc = /%COMP%/g,
	rp = "%COMP%",
	s0 = `_nghost-${rp}`,
	a0 = `_ngcontent-${rp}`,
	u0 = !0,
	c0 = new w("", {
		providedIn: "root",
		factory: () => u0
	});

function l0(e) {
	return a0.replace(sc, e)
}

function d0(e) {
	return s0.replace(sc, e)
}

function ip(e, t) {
	return t.map(r => r.replace(sc, e))
}
var Jh = (() => {
		let t = class t {
			constructor(n, i, o, s, a, u, c, l = null) {
				this.eventManager = n, this.sharedStylesHost = i, this.appId = o, this.removeStylesOnCompDestroy = s, this.doc = a, this.platformId = u, this.ngZone = c, this.nonce = l, this.rendererByCompId = new Map, this.platformIsServer = Wu(u), this.defaultRenderer = new Pr(n, a, c, this.platformIsServer)
			}
			createRenderer(n, i) {
				if (!n || !i) return this.defaultRenderer;
				this.platformIsServer && i.encapsulation === Qe.ShadowDom && (i = z(g({}, i), {
					encapsulation: Qe.Emulated
				}));
				let o = this.getOrCreateRenderer(n, i);
				return o instanceof Bo ? o.applyToHost(n) : o instanceof kr && o.applyStyles(), o
			}
			getOrCreateRenderer(n, i) {
				let o = this.rendererByCompId,
					s = o.get(i.id);
				if (!s) {
					let a = this.doc,
						u = this.ngZone,
						c = this.eventManager,
						l = this.sharedStylesHost,
						d = this.removeStylesOnCompDestroy,
						f = this.platformIsServer;
					switch (i.encapsulation) {
						case Qe.Emulated:
							s = new Bo(c, l, i, this.appId, d, a, u, f);
							break;
						case Qe.ShadowDom:
							return new oc(c, l, n, i, a, u, this.nonce, f);
						default:
							s = new kr(c, l, i, d, a, u, f);
							break
					}
					o.set(i.id, s)
				}
				return s
			}
			ngOnDestroy() {
				this.rendererByCompId.clear()
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(tp), M(np), M(vu), M(c0), M(he), M(tt), M(Z), M(Du))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	Pr = class {
		constructor(t, r, n, i) {
			this.eventManager = t, this.doc = r, this.ngZone = n, this.platformIsServer = i, this.data = Object.create(null), this.throwOnSyntheticProps = !0, this.destroyNode = null
		}
		destroy() {}
		createElement(t, r) {
			return r ? this.doc.createElementNS(tc[r] || r, t) : this.doc.createElement(t)
		}
		createComment(t) {
			return this.doc.createComment(t)
		}
		createText(t) {
			return this.doc.createTextNode(t)
		}
		appendChild(t, r) {
			(Xh(t) ? t.content : t).appendChild(r)
		}
		insertBefore(t, r, n) {
			t && (Xh(t) ? t.content : t).insertBefore(r, n)
		}
		removeChild(t, r) {
			t && t.removeChild(r)
		}
		selectRootElement(t, r) {
			let n = typeof t == "string" ? this.doc.querySelector(t) : t;
			if (!n) throw new I(-5104, !1);
			return r || (n.textContent = ""), n
		}
		parentNode(t) {
			return t.parentNode
		}
		nextSibling(t) {
			return t.nextSibling
		}
		setAttribute(t, r, n, i) {
			if (i) {
				r = i + ":" + r;
				let o = tc[i];
				o ? t.setAttributeNS(o, r, n) : t.setAttribute(r, n)
			} else t.setAttribute(r, n)
		}
		removeAttribute(t, r, n) {
			if (n) {
				let i = tc[n];
				i ? t.removeAttributeNS(i, r) : t.removeAttribute(`${n}:${r}`)
			} else t.removeAttribute(r)
		}
		addClass(t, r) {
			t.classList.add(r)
		}
		removeClass(t, r) {
			t.classList.remove(r)
		}
		setStyle(t, r, n, i) {
			i & (ct.DashCase | ct.Important) ? t.style.setProperty(r, n, i & ct.Important ? "important" : "") : t.style[r] = n
		}
		removeStyle(t, r, n) {
			n & ct.DashCase ? t.style.removeProperty(r) : t.style[r] = ""
		}
		setProperty(t, r, n) {
			t != null && (t[r] = n)
		}
		setValue(t, r) {
			t.nodeValue = r
		}
		listen(t, r, n) {
			if (typeof t == "string" && (t = mt().getGlobalEventTarget(this.doc, t), !t)) throw new Error(`Unsupported event target ${t} for event ${r}`);
			return this.eventManager.addEventListener(t, r, this.decoratePreventDefault(n))
		}
		decoratePreventDefault(t) {
			return r => {
				if (r === "__ngUnwrap__") return t;
				(this.platformIsServer ? this.ngZone.runGuarded(() => t(r)) : t(r)) === !1 && r.preventDefault()
			}
		}
	};

function Xh(e) {
	return e.tagName === "TEMPLATE" && e.content !== void 0
}
var oc = class extends Pr {
		constructor(t, r, n, i, o, s, a, u) {
			super(t, o, s, u), this.sharedStylesHost = r, this.hostEl = n, this.shadowRoot = n.attachShadow({
				mode: "open"
			}), this.sharedStylesHost.addHost(this.shadowRoot);
			let c = ip(i.id, i.styles);
			for (let l of c) {
				let d = document.createElement("style");
				a && d.setAttribute("nonce", a), d.textContent = l, this.shadowRoot.appendChild(d)
			}
		}
		nodeOrShadowRoot(t) {
			return t === this.hostEl ? this.shadowRoot : t
		}
		appendChild(t, r) {
			return super.appendChild(this.nodeOrShadowRoot(t), r)
		}
		insertBefore(t, r, n) {
			return super.insertBefore(this.nodeOrShadowRoot(t), r, n)
		}
		removeChild(t, r) {
			return super.removeChild(this.nodeOrShadowRoot(t), r)
		}
		parentNode(t) {
			return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(t)))
		}
		destroy() {
			this.sharedStylesHost.removeHost(this.shadowRoot)
		}
	},
	kr = class extends Pr {
		constructor(t, r, n, i, o, s, a, u) {
			super(t, o, s, a), this.sharedStylesHost = r, this.removeStylesOnCompDestroy = i, this.styles = u ? ip(u, n.styles) : n.styles
		}
		applyStyles() {
			this.sharedStylesHost.addStyles(this.styles)
		}
		destroy() {
			this.removeStylesOnCompDestroy && this.sharedStylesHost.removeStyles(this.styles)
		}
	},
	Bo = class extends kr {
		constructor(t, r, n, i, o, s, a, u) {
			let c = i + "-" + n.id;
			super(t, r, n, o, s, a, u, c), this.contentAttr = l0(c), this.hostAttr = d0(c)
		}
		applyToHost(t) {
			this.applyStyles(), this.setAttribute(t, this.hostAttr, "")
		}
		createElement(t, r) {
			let n = super.createElement(t, r);
			return super.setAttribute(n, this.contentAttr, ""), n
		}
	},
	f0 = (() => {
		let t = class t extends $o {
			constructor(n) {
				super(n)
			}
			supports(n) {
				return !0
			}
			addEventListener(n, i, o) {
				return n.addEventListener(i, o, !1), () => this.removeEventListener(n, i, o)
			}
			removeEventListener(n, i, o) {
				return n.removeEventListener(i, o)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(he))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})(),
	ep = ["alt", "control", "meta", "shift"],
	h0 = {
		"\b": "Backspace",
		"	": "Tab",
		"\x7F": "Delete",
		"\x1B": "Escape",
		Del: "Delete",
		Esc: "Escape",
		Left: "ArrowLeft",
		Right: "ArrowRight",
		Up: "ArrowUp",
		Down: "ArrowDown",
		Menu: "ContextMenu",
		Scroll: "ScrollLock",
		Win: "OS"
	},
	p0 = {
		alt: e => e.altKey,
		control: e => e.ctrlKey,
		meta: e => e.metaKey,
		shift: e => e.shiftKey
	},
	g0 = (() => {
		let t = class t extends $o {
			constructor(n) {
				super(n)
			}
			supports(n) {
				return t.parseEventName(n) != null
			}
			addEventListener(n, i, o) {
				let s = t.parseEventName(i),
					a = t.eventCallback(s.fullKey, o, this.manager.getZone());
				return this.manager.getZone().runOutsideAngular(() => mt().onAndCancel(n, s.domEventName, a))
			}
			static parseEventName(n) {
				let i = n.toLowerCase().split("."),
					o = i.shift();
				if (i.length === 0 || !(o === "keydown" || o === "keyup")) return null;
				let s = t._normalizeKey(i.pop()),
					a = "",
					u = i.indexOf("code");
				if (u > -1 && (i.splice(u, 1), a = "code."), ep.forEach(l => {
						let d = i.indexOf(l);
						d > -1 && (i.splice(d, 1), a += l + ".")
					}), a += s, i.length != 0 || s.length === 0) return null;
				let c = {};
				return c.domEventName = o, c.fullKey = a, c
			}
			static matchEventFullKeyCode(n, i) {
				let o = h0[n.key] || n.key,
					s = "";
				return i.indexOf("code.") > -1 && (o = n.code, s = "code."), o == null || !o ? !1 : (o = o.toLowerCase(), o === " " ? o = "space" : o === "." && (o = "dot"), ep.forEach(a => {
					if (a !== o) {
						let u = p0[a];
						u(n) && (s += a + ".")
					}
				}), s += o, s === i)
			}
			static eventCallback(n, i, o) {
				return s => {
					t.matchEventFullKeyCode(s, n) && o.runGuarded(() => i(s))
				}
			}
			static _normalizeKey(n) {
				return n === "esc" ? "escape" : n
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(he))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})();

function op(e, t) {
	return xh(g({
		rootComponent: e
	}, m0(t)))
}

function m0(e) {
	return {
		appProviders: [...C0, ...e?.providers ?? []],
		platformProviders: w0
	}
}

function v0() {
	rc.makeCurrent()
}

function y0() {
	return new Je
}

function D0() {
	return xf(document), document
}
var w0 = [{
	provide: tt,
	useValue: qu
}, {
	provide: yu,
	useValue: v0,
	multi: !0
}, {
	provide: he,
	useFactory: D0,
	deps: []
}];
var C0 = [{
		provide: fo,
		useValue: "root"
	}, {
		provide: Je,
		useFactory: y0,
		deps: []
	}, {
		provide: ic,
		useClass: f0,
		multi: !0,
		deps: [he, Z, tt]
	}, {
		provide: ic,
		useClass: g0,
		multi: !0,
		deps: [he]
	}, Jh, np, tp, {
		provide: yr,
		useExisting: Jh
	}, {
		provide: Hn,
		useClass: o0,
		deps: []
	},
	[]
];
var sp = (() => {
	let t = class t {
		constructor(n) {
			this._doc = n
		}
		getTitle() {
			return this._doc.title
		}
		setTitle(n) {
			this._doc.title = n || ""
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)(M(he))
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();
var N = "primary",
	Jr = Symbol("RouteTitle"),
	dc = class {
		constructor(t) {
			this.params = t || {}
		}
		has(t) {
			return Object.prototype.hasOwnProperty.call(this.params, t)
		}
		get(t) {
			if (this.has(t)) {
				let r = this.params[t];
				return Array.isArray(r) ? r[0] : r
			}
			return null
		}
		getAll(t) {
			if (this.has(t)) {
				let r = this.params[t];
				return Array.isArray(r) ? r : [r]
			}
			return []
		}
		get keys() {
			return Object.keys(this.params)
		}
	};

function Qn(e) {
	return new dc(e)
}

function b0(e, t, r) {
	let n = r.path.split("/");
	if (n.length > e.length || r.pathMatch === "full" && (t.hasChildren() || n.length < e.length)) return null;
	let i = {};
	for (let o = 0; o < n.length; o++) {
		let s = n[o],
			a = e[o];
		if (s.startsWith(":")) i[s.substring(1)] = a;
		else if (s !== a.path) return null
	}
	return {
		consumed: e.slice(0, n.length),
		posParams: i
	}
}

function I0(e, t) {
	if (e.length !== t.length) return !1;
	for (let r = 0; r < e.length; ++r)
		if (!nt(e[r], t[r])) return !1;
	return !0
}

function nt(e, t) {
	let r = e ? fc(e) : void 0,
		n = t ? fc(t) : void 0;
	if (!r || !n || r.length != n.length) return !1;
	let i;
	for (let o = 0; o < r.length; o++)
		if (i = r[o], !gp(e[i], t[i])) return !1;
	return !0
}

function fc(e) {
	return [...Object.keys(e), ...Object.getOwnPropertySymbols(e)]
}

function gp(e, t) {
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		let r = [...e].sort(),
			n = [...t].sort();
		return r.every((i, o) => n[o] === i)
	} else return e === t
}

function mp(e) {
	return e.length > 0 ? e[e.length - 1] : null
}

function Vt(e) {
	return Ns(e) ? e : sn(e) ? G(Promise.resolve(e)) : b(e)
}
var M0 = {
		exact: yp,
		subset: Dp
	},
	vp = {
		exact: _0,
		subset: S0,
		ignored: () => !0
	};

function ap(e, t, r) {
	return M0[r.paths](e.root, t.root, r.matrixParams) && vp[r.queryParams](e.queryParams, t.queryParams) && !(r.fragment === "exact" && e.fragment !== t.fragment)
}

function _0(e, t) {
	return nt(e, t)
}

function yp(e, t, r) {
	if (!ln(e.segments, t.segments) || !Go(e.segments, t.segments, r) || e.numberOfChildren !== t.numberOfChildren) return !1;
	for (let n in t.children)
		if (!e.children[n] || !yp(e.children[n], t.children[n], r)) return !1;
	return !0
}

function S0(e, t) {
	return Object.keys(t).length <= Object.keys(e).length && Object.keys(t).every(r => gp(e[r], t[r]))
}

function Dp(e, t, r) {
	return wp(e, t, t.segments, r)
}

function wp(e, t, r, n) {
	if (e.segments.length > r.length) {
		let i = e.segments.slice(0, r.length);
		return !(!ln(i, r) || t.hasChildren() || !Go(i, r, n))
	} else if (e.segments.length === r.length) {
		if (!ln(e.segments, r) || !Go(e.segments, r, n)) return !1;
		for (let i in t.children)
			if (!e.children[i] || !Dp(e.children[i], t.children[i], n)) return !1;
		return !0
	} else {
		let i = r.slice(0, e.segments.length),
			o = r.slice(e.segments.length);
		return !ln(e.segments, i) || !Go(e.segments, i, n) || !e.children[N] ? !1 : wp(e.children[N], t, o, n)
	}
}

function Go(e, t, r) {
	return t.every((n, i) => vp[r](e[i].parameters, n.parameters))
}
var Ft = class {
		constructor(t = new B([], {}), r = {}, n = null) {
			this.root = t, this.queryParams = r, this.fragment = n
		}
		get queryParamMap() {
			return this._queryParamMap ??= Qn(this.queryParams), this._queryParamMap
		}
		toString() {
			return A0.serialize(this)
		}
	},
	B = class {
		constructor(t, r) {
			this.segments = t, this.children = r, this.parent = null, Object.values(r).forEach(n => n.parent = this)
		}
		hasChildren() {
			return this.numberOfChildren > 0
		}
		get numberOfChildren() {
			return Object.keys(this.children).length
		}
		toString() {
			return qo(this)
		}
	},
	cn = class {
		constructor(t, r) {
			this.path = t, this.parameters = r
		}
		get parameterMap() {
			return this._parameterMap ??= Qn(this.parameters), this._parameterMap
		}
		toString() {
			return Ep(this)
		}
	};

function T0(e, t) {
	return ln(e, t) && e.every((r, n) => nt(r.parameters, t[n].parameters))
}

function ln(e, t) {
	return e.length !== t.length ? !1 : e.every((r, n) => r.path === t[n].path)
}

function x0(e, t) {
	let r = [];
	return Object.entries(e.children).forEach(([n, i]) => {
		n === N && (r = r.concat(t(i, n)))
	}), Object.entries(e.children).forEach(([n, i]) => {
		n !== N && (r = r.concat(t(i, n)))
	}), r
}
var Xr = (() => {
		let t = class t {};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => new Hr,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Hr = class {
		parse(t) {
			let r = new pc(t);
			return new Ft(r.parseRootSegment(), r.parseQueryParams(), r.parseFragment())
		}
		serialize(t) {
			let r = `/${Lr(t.root,!0)}`,
				n = O0(t.queryParams),
				i = typeof t.fragment == "string" ? `#${N0(t.fragment)}` : "";
			return `${r}${n}${i}`
		}
	},
	A0 = new Hr;

function qo(e) {
	return e.segments.map(t => Ep(t)).join("/")
}

function Lr(e, t) {
	if (!e.hasChildren()) return qo(e);
	if (t) {
		let r = e.children[N] ? Lr(e.children[N], !1) : "",
			n = [];
		return Object.entries(e.children).forEach(([i, o]) => {
			i !== N && n.push(`${i}:${Lr(o,!1)}`)
		}), n.length > 0 ? `${r}(${n.join("//")})` : r
	} else {
		let r = x0(e, (n, i) => i === N ? [Lr(e.children[N], !1)] : [`${i}:${Lr(n,!1)}`]);
		return Object.keys(e.children).length === 1 && e.children[N] != null ? `${qo(e)}/${r[0]}` : `${qo(e)}/(${r.join("//")})`
	}
}

function Cp(e) {
	return encodeURIComponent(e).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",")
}

function Ho(e) {
	return Cp(e).replace(/%3B/gi, ";")
}

function N0(e) {
	return encodeURI(e)
}

function hc(e) {
	return Cp(e).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&")
}

function Wo(e) {
	return decodeURIComponent(e)
}

function up(e) {
	return Wo(e.replace(/\+/g, "%20"))
}

function Ep(e) {
	return `${hc(e.path)}${R0(e.parameters)}`
}

function R0(e) {
	return Object.entries(e).map(([t, r]) => `;${hc(t)}=${hc(r)}`).join("")
}

function O0(e) {
	let t = Object.entries(e).map(([r, n]) => Array.isArray(n) ? n.map(i => `${Ho(r)}=${Ho(i)}`).join("&") : `${Ho(r)}=${Ho(n)}`).filter(r => r);
	return t.length ? `?${t.join("&")}` : ""
}
var F0 = /^[^\/()?;#]+/;

function ac(e) {
	let t = e.match(F0);
	return t ? t[0] : ""
}
var P0 = /^[^\/()?;=#]+/;

function k0(e) {
	let t = e.match(P0);
	return t ? t[0] : ""
}
var L0 = /^[^=?&#]+/;

function V0(e) {
	let t = e.match(L0);
	return t ? t[0] : ""
}
var j0 = /^[^&#]+/;

function U0(e) {
	let t = e.match(j0);
	return t ? t[0] : ""
}
var pc = class {
	constructor(t) {
		this.url = t, this.remaining = t
	}
	parseRootSegment() {
		return this.consumeOptional("/"), this.remaining === "" || this.peekStartsWith("?") || this.peekStartsWith("#") ? new B([], {}) : new B([], this.parseChildren())
	}
	parseQueryParams() {
		let t = {};
		if (this.consumeOptional("?"))
			do this.parseQueryParam(t); while (this.consumeOptional("&"));
		return t
	}
	parseFragment() {
		return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null
	}
	parseChildren() {
		if (this.remaining === "") return {};
		this.consumeOptional("/");
		let t = [];
		for (this.peekStartsWith("(") || t.push(this.parseSegment()); this.peekStartsWith("/") && !this.peekStartsWith("//") && !this.peekStartsWith("/(");) this.capture("/"), t.push(this.parseSegment());
		let r = {};
		this.peekStartsWith("/(") && (this.capture("/"), r = this.parseParens(!0));
		let n = {};
		return this.peekStartsWith("(") && (n = this.parseParens(!1)), (t.length > 0 || Object.keys(r).length > 0) && (n[N] = new B(t, r)), n
	}
	parseSegment() {
		let t = ac(this.remaining);
		if (t === "" && this.peekStartsWith(";")) throw new I(4009, !1);
		return this.capture(t), new cn(Wo(t), this.parseMatrixParams())
	}
	parseMatrixParams() {
		let t = {};
		for (; this.consumeOptional(";");) this.parseParam(t);
		return t
	}
	parseParam(t) {
		let r = k0(this.remaining);
		if (!r) return;
		this.capture(r);
		let n = "";
		if (this.consumeOptional("=")) {
			let i = ac(this.remaining);
			i && (n = i, this.capture(n))
		}
		t[Wo(r)] = Wo(n)
	}
	parseQueryParam(t) {
		let r = V0(this.remaining);
		if (!r) return;
		this.capture(r);
		let n = "";
		if (this.consumeOptional("=")) {
			let s = U0(this.remaining);
			s && (n = s, this.capture(n))
		}
		let i = up(r),
			o = up(n);
		if (t.hasOwnProperty(i)) {
			let s = t[i];
			Array.isArray(s) || (s = [s], t[i] = s), s.push(o)
		} else t[i] = o
	}
	parseParens(t) {
		let r = {};
		for (this.capture("("); !this.consumeOptional(")") && this.remaining.length > 0;) {
			let n = ac(this.remaining),
				i = this.remaining[n.length];
			if (i !== "/" && i !== ")" && i !== ";") throw new I(4010, !1);
			let o;
			n.indexOf(":") > -1 ? (o = n.slice(0, n.indexOf(":")), this.capture(o), this.capture(":")) : t && (o = N);
			let s = this.parseChildren();
			r[o] = Object.keys(s).length === 1 ? s[N] : new B([], s), this.consumeOptional("//")
		}
		return r
	}
	peekStartsWith(t) {
		return this.remaining.startsWith(t)
	}
	consumeOptional(t) {
		return this.peekStartsWith(t) ? (this.remaining = this.remaining.substring(t.length), !0) : !1
	}
	capture(t) {
		if (!this.consumeOptional(t)) throw new I(4011, !1)
	}
};

function bp(e) {
	return e.segments.length > 0 ? new B([], {
		[N]: e
	}) : e
}

function Ip(e) {
	let t = {};
	for (let [n, i] of Object.entries(e.children)) {
		let o = Ip(i);
		if (n === N && o.segments.length === 0 && o.hasChildren())
			for (let [s, a] of Object.entries(o.children)) t[s] = a;
		else(o.segments.length > 0 || o.hasChildren()) && (t[n] = o)
	}
	let r = new B(e.segments, t);
	return $0(r)
}

function $0(e) {
	if (e.numberOfChildren === 1 && e.children[N]) {
		let t = e.children[N];
		return new B(e.segments.concat(t.segments), t.children)
	}
	return e
}

function Kn(e) {
	return e instanceof Ft
}

function B0(e, t, r = null, n = null) {
	let i = Mp(e);
	return _p(i, t, r, n)
}

function Mp(e) {
	let t;

	function r(o) {
		let s = {};
		for (let u of o.children) {
			let c = r(u);
			s[u.outlet] = c
		}
		let a = new B(o.url, s);
		return o === e && (t = a), a
	}
	let n = r(e.root),
		i = bp(n);
	return t ?? i
}

function _p(e, t, r, n) {
	let i = e;
	for (; i.parent;) i = i.parent;
	if (t.length === 0) return uc(i, i, i, r, n);
	let o = H0(t);
	if (o.toRoot()) return uc(i, i, new B([], {}), r, n);
	let s = z0(o, i, e),
		a = s.processChildren ? Ur(s.segmentGroup, s.index, o.commands) : Tp(s.segmentGroup, s.index, o.commands);
	return uc(i, s.segmentGroup, a, r, n)
}

function Zo(e) {
	return typeof e == "object" && e != null && !e.outlets && !e.segmentPath
}

function zr(e) {
	return typeof e == "object" && e != null && e.outlets
}

function uc(e, t, r, n, i) {
	let o = {};
	n && Object.entries(n).forEach(([u, c]) => {
		o[u] = Array.isArray(c) ? c.map(l => `${l}`) : `${c}`
	});
	let s;
	e === t ? s = r : s = Sp(e, t, r);
	let a = bp(Ip(s));
	return new Ft(a, o, i)
}

function Sp(e, t, r) {
	let n = {};
	return Object.entries(e.children).forEach(([i, o]) => {
		o === t ? n[i] = r : n[i] = Sp(o, t, r)
	}), new B(e.segments, n)
}
var Yo = class {
	constructor(t, r, n) {
		if (this.isAbsolute = t, this.numberOfDoubleDots = r, this.commands = n, t && n.length > 0 && Zo(n[0])) throw new I(4003, !1);
		let i = n.find(zr);
		if (i && i !== mp(n)) throw new I(4004, !1)
	}
	toRoot() {
		return this.isAbsolute && this.commands.length === 1 && this.commands[0] == "/"
	}
};

function H0(e) {
	if (typeof e[0] == "string" && e.length === 1 && e[0] === "/") return new Yo(!0, 0, e);
	let t = 0,
		r = !1,
		n = e.reduce((i, o, s) => {
			if (typeof o == "object" && o != null) {
				if (o.outlets) {
					let a = {};
					return Object.entries(o.outlets).forEach(([u, c]) => {
						a[u] = typeof c == "string" ? c.split("/") : c
					}), [...i, {
						outlets: a
					}]
				}
				if (o.segmentPath) return [...i, o.segmentPath]
			}
			return typeof o != "string" ? [...i, o] : s === 0 ? (o.split("/").forEach((a, u) => {
				u == 0 && a === "." || (u == 0 && a === "" ? r = !0 : a === ".." ? t++ : a != "" && i.push(a))
			}), i) : [...i, o]
		}, []);
	return new Yo(r, t, n)
}
var Zn = class {
	constructor(t, r, n) {
		this.segmentGroup = t, this.processChildren = r, this.index = n
	}
};

function z0(e, t, r) {
	if (e.isAbsolute) return new Zn(t, !0, 0);
	if (!r) return new Zn(t, !1, NaN);
	if (r.parent === null) return new Zn(r, !0, 0);
	let n = Zo(e.commands[0]) ? 0 : 1,
		i = r.segments.length - 1 + n;
	return G0(r, i, e.numberOfDoubleDots)
}

function G0(e, t, r) {
	let n = e,
		i = t,
		o = r;
	for (; o > i;) {
		if (o -= i, n = n.parent, !n) throw new I(4005, !1);
		i = n.segments.length
	}
	return new Zn(n, !1, i - o)
}

function q0(e) {
	return zr(e[0]) ? e[0].outlets : {
		[N]: e
	}
}

function Tp(e, t, r) {
	if (e ??= new B([], {}), e.segments.length === 0 && e.hasChildren()) return Ur(e, t, r);
	let n = W0(e, t, r),
		i = r.slice(n.commandIndex);
	if (n.match && n.pathIndex < e.segments.length) {
		let o = new B(e.segments.slice(0, n.pathIndex), {});
		return o.children[N] = new B(e.segments.slice(n.pathIndex), e.children), Ur(o, 0, i)
	} else return n.match && i.length === 0 ? new B(e.segments, {}) : n.match && !e.hasChildren() ? gc(e, t, r) : n.match ? Ur(e, 0, i) : gc(e, t, r)
}

function Ur(e, t, r) {
	if (r.length === 0) return new B(e.segments, {});
	{
		let n = q0(r),
			i = {};
		if (Object.keys(n).some(o => o !== N) && e.children[N] && e.numberOfChildren === 1 && e.children[N].segments.length === 0) {
			let o = Ur(e.children[N], t, r);
			return new B(e.segments, o.children)
		}
		return Object.entries(n).forEach(([o, s]) => {
			typeof s == "string" && (s = [s]), s !== null && (i[o] = Tp(e.children[o], t, s))
		}), Object.entries(e.children).forEach(([o, s]) => {
			n[o] === void 0 && (i[o] = s)
		}), new B(e.segments, i)
	}
}

function W0(e, t, r) {
	let n = 0,
		i = t,
		o = {
			match: !1,
			pathIndex: 0,
			commandIndex: 0
		};
	for (; i < e.segments.length;) {
		if (n >= r.length) return o;
		let s = e.segments[i],
			a = r[n];
		if (zr(a)) break;
		let u = `${a}`,
			c = n < r.length - 1 ? r[n + 1] : null;
		if (i > 0 && u === void 0) break;
		if (u && c && typeof c == "object" && c.outlets === void 0) {
			if (!lp(u, c, s)) return o;
			n += 2
		} else {
			if (!lp(u, {}, s)) return o;
			n++
		}
		i++
	}
	return {
		match: !0,
		pathIndex: i,
		commandIndex: n
	}
}

function gc(e, t, r) {
	let n = e.segments.slice(0, t),
		i = 0;
	for (; i < r.length;) {
		let o = r[i];
		if (zr(o)) {
			let u = Z0(o.outlets);
			return new B(n, u)
		}
		if (i === 0 && Zo(r[0])) {
			let u = e.segments[t];
			n.push(new cn(u.path, cp(r[0]))), i++;
			continue
		}
		let s = zr(o) ? o.outlets[N] : `${o}`,
			a = i < r.length - 1 ? r[i + 1] : null;
		s && a && Zo(a) ? (n.push(new cn(s, cp(a))), i += 2) : (n.push(new cn(s, {})), i++)
	}
	return new B(n, {})
}

function Z0(e) {
	let t = {};
	return Object.entries(e).forEach(([r, n]) => {
		typeof n == "string" && (n = [n]), n !== null && (t[r] = gc(new B([], {}), 0, n))
	}), t
}

function cp(e) {
	let t = {};
	return Object.entries(e).forEach(([r, n]) => t[r] = `${n}`), t
}

function lp(e, t, r) {
	return e == r.path && nt(t, r.parameters)
}
var $r = "imperative",
	ne = function(e) {
		return e[e.NavigationStart = 0] = "NavigationStart", e[e.NavigationEnd = 1] = "NavigationEnd", e[e.NavigationCancel = 2] = "NavigationCancel", e[e.NavigationError = 3] = "NavigationError", e[e.RoutesRecognized = 4] = "RoutesRecognized", e[e.ResolveStart = 5] = "ResolveStart", e[e.ResolveEnd = 6] = "ResolveEnd", e[e.GuardsCheckStart = 7] = "GuardsCheckStart", e[e.GuardsCheckEnd = 8] = "GuardsCheckEnd", e[e.RouteConfigLoadStart = 9] = "RouteConfigLoadStart", e[e.RouteConfigLoadEnd = 10] = "RouteConfigLoadEnd", e[e.ChildActivationStart = 11] = "ChildActivationStart", e[e.ChildActivationEnd = 12] = "ChildActivationEnd", e[e.ActivationStart = 13] = "ActivationStart", e[e.ActivationEnd = 14] = "ActivationEnd", e[e.Scroll = 15] = "Scroll", e[e.NavigationSkipped = 16] = "NavigationSkipped", e
	}(ne || {}),
	ke = class {
		constructor(t, r) {
			this.id = t, this.url = r
		}
	},
	Jn = class extends ke {
		constructor(t, r, n = "imperative", i = null) {
			super(t, r), this.type = ne.NavigationStart, this.navigationTrigger = n, this.restoredState = i
		}
		toString() {
			return `NavigationStart(id: ${this.id}, url: '${this.url}')`
		}
	},
	Ge = class extends ke {
		constructor(t, r, n) {
			super(t, r), this.urlAfterRedirects = n, this.type = ne.NavigationEnd
		}
		toString() {
			return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`
		}
	},
	Ne = function(e) {
		return e[e.Redirect = 0] = "Redirect", e[e.SupersededByNewNavigation = 1] = "SupersededByNewNavigation", e[e.NoDataFromResolver = 2] = "NoDataFromResolver", e[e.GuardRejected = 3] = "GuardRejected", e
	}(Ne || {}),
	Qo = function(e) {
		return e[e.IgnoredSameUrlNavigation = 0] = "IgnoredSameUrlNavigation", e[e.IgnoredByUrlHandlingStrategy = 1] = "IgnoredByUrlHandlingStrategy", e
	}(Qo || {}),
	Pt = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.reason = n, this.code = i, this.type = ne.NavigationCancel
		}
		toString() {
			return `NavigationCancel(id: ${this.id}, url: '${this.url}')`
		}
	},
	kt = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.reason = n, this.code = i, this.type = ne.NavigationSkipped
		}
	},
	Gr = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.error = n, this.target = i, this.type = ne.NavigationError
		}
		toString() {
			return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`
		}
	},
	Ko = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.urlAfterRedirects = n, this.state = i, this.type = ne.RoutesRecognized
		}
		toString() {
			return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
		}
	},
	mc = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.urlAfterRedirects = n, this.state = i, this.type = ne.GuardsCheckStart
		}
		toString() {
			return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
		}
	},
	vc = class extends ke {
		constructor(t, r, n, i, o) {
			super(t, r), this.urlAfterRedirects = n, this.state = i, this.shouldActivate = o, this.type = ne.GuardsCheckEnd
		}
		toString() {
			return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`
		}
	},
	yc = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.urlAfterRedirects = n, this.state = i, this.type = ne.ResolveStart
		}
		toString() {
			return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
		}
	},
	Dc = class extends ke {
		constructor(t, r, n, i) {
			super(t, r), this.urlAfterRedirects = n, this.state = i, this.type = ne.ResolveEnd
		}
		toString() {
			return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
		}
	},
	wc = class {
		constructor(t) {
			this.route = t, this.type = ne.RouteConfigLoadStart
		}
		toString() {
			return `RouteConfigLoadStart(path: ${this.route.path})`
		}
	},
	Cc = class {
		constructor(t) {
			this.route = t, this.type = ne.RouteConfigLoadEnd
		}
		toString() {
			return `RouteConfigLoadEnd(path: ${this.route.path})`
		}
	},
	Ec = class {
		constructor(t) {
			this.snapshot = t, this.type = ne.ChildActivationStart
		}
		toString() {
			return `ChildActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
		}
	},
	bc = class {
		constructor(t) {
			this.snapshot = t, this.type = ne.ChildActivationEnd
		}
		toString() {
			return `ChildActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
		}
	},
	Ic = class {
		constructor(t) {
			this.snapshot = t, this.type = ne.ActivationStart
		}
		toString() {
			return `ActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
		}
	},
	Mc = class {
		constructor(t) {
			this.snapshot = t, this.type = ne.ActivationEnd
		}
		toString() {
			return `ActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
		}
	},
	Jo = class {
		constructor(t, r, n) {
			this.routerEvent = t, this.position = r, this.anchor = n, this.type = ne.Scroll
		}
		toString() {
			let t = this.position ? `${this.position[0]}, ${this.position[1]}` : null;
			return `Scroll(anchor: '${this.anchor}', position: '${t}')`
		}
	},
	qr = class {},
	Wr = class {
		constructor(t) {
			this.url = t
		}
	};
var _c = class {
		constructor() {
			this.outlet = null, this.route = null, this.injector = null, this.children = new ei, this.attachRef = null
		}
	},
	ei = (() => {
		let t = class t {
			constructor() {
				this.contexts = new Map
			}
			onChildOutletCreated(n, i) {
				let o = this.getOrCreateContext(n);
				o.outlet = i, this.contexts.set(n, o)
			}
			onChildOutletDestroyed(n) {
				let i = this.getContext(n);
				i && (i.outlet = null, i.attachRef = null)
			}
			onOutletDeactivated() {
				let n = this.contexts;
				return this.contexts = new Map, n
			}
			onOutletReAttached(n) {
				this.contexts = n
			}
			getOrCreateContext(n) {
				let i = this.getContext(n);
				return i || (i = new _c, this.contexts.set(n, i)), i
			}
			getContext(n) {
				return this.contexts.get(n) || null
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Xo = class {
		constructor(t) {
			this._root = t
		}
		get root() {
			return this._root.value
		}
		parent(t) {
			let r = this.pathFromRoot(t);
			return r.length > 1 ? r[r.length - 2] : null
		}
		children(t) {
			let r = Sc(t, this._root);
			return r ? r.children.map(n => n.value) : []
		}
		firstChild(t) {
			let r = Sc(t, this._root);
			return r && r.children.length > 0 ? r.children[0].value : null
		}
		siblings(t) {
			let r = Tc(t, this._root);
			return r.length < 2 ? [] : r[r.length - 2].children.map(i => i.value).filter(i => i !== t)
		}
		pathFromRoot(t) {
			return Tc(t, this._root).map(r => r.value)
		}
	};

function Sc(e, t) {
	if (e === t.value) return t;
	for (let r of t.children) {
		let n = Sc(e, r);
		if (n) return n
	}
	return null
}

function Tc(e, t) {
	if (e === t.value) return [t];
	for (let r of t.children) {
		let n = Tc(e, r);
		if (n.length) return n.unshift(t), n
	}
	return []
}
var Ae = class {
	constructor(t, r) {
		this.value = t, this.children = r
	}
	toString() {
		return `TreeNode(${this.value})`
	}
};

function Wn(e) {
	let t = {};
	return e && e.children.forEach(r => t[r.value.outlet] = r), t
}
var es = class extends Xo {
	constructor(t, r) {
		super(t), this.snapshot = r, Vc(this, t)
	}
	toString() {
		return this.snapshot.toString()
	}
};

function xp(e) {
	let t = Y0(e),
		r = new W([new cn("", {})]),
		n = new W({}),
		i = new W({}),
		o = new W({}),
		s = new W(""),
		a = new Lt(r, n, o, s, i, N, e, t.root);
	return a.snapshot = t.root, new es(new Ae(a, []), t)
}

function Y0(e) {
	let t = {},
		r = {},
		n = {},
		i = "",
		o = new Zr([], t, n, i, r, N, e, null, {});
	return new ts("", new Ae(o, []))
}
var Lt = class {
	constructor(t, r, n, i, o, s, a, u) {
		this.urlSubject = t, this.paramsSubject = r, this.queryParamsSubject = n, this.fragmentSubject = i, this.dataSubject = o, this.outlet = s, this.component = a, this._futureSnapshot = u, this.title = this.dataSubject?.pipe(A(c => c[Jr])) ?? b(void 0), this.url = t, this.params = r, this.queryParams = n, this.fragment = i, this.data = o
	}
	get routeConfig() {
		return this._futureSnapshot.routeConfig
	}
	get root() {
		return this._routerState.root
	}
	get parent() {
		return this._routerState.parent(this)
	}
	get firstChild() {
		return this._routerState.firstChild(this)
	}
	get children() {
		return this._routerState.children(this)
	}
	get pathFromRoot() {
		return this._routerState.pathFromRoot(this)
	}
	get paramMap() {
		return this._paramMap ??= this.params.pipe(A(t => Qn(t))), this._paramMap
	}
	get queryParamMap() {
		return this._queryParamMap ??= this.queryParams.pipe(A(t => Qn(t))), this._queryParamMap
	}
	toString() {
		return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`
	}
};

function Lc(e, t, r = "emptyOnly") {
	let n, {
		routeConfig: i
	} = e;
	return t !== null && (r === "always" || i?.path === "" || !t.component && !t.routeConfig?.loadComponent) ? n = {
		params: g(g({}, t.params), e.params),
		data: g(g({}, t.data), e.data),
		resolve: g(g(g(g({}, e.data), t.data), i?.data), e._resolvedData)
	} : n = {
		params: g({}, e.params),
		data: g({}, e.data),
		resolve: g(g({}, e.data), e._resolvedData ?? {})
	}, i && Np(i) && (n.resolve[Jr] = i.title), n
}
var Zr = class {
		get title() {
			return this.data?.[Jr]
		}
		constructor(t, r, n, i, o, s, a, u, c) {
			this.url = t, this.params = r, this.queryParams = n, this.fragment = i, this.data = o, this.outlet = s, this.component = a, this.routeConfig = u, this._resolve = c
		}
		get root() {
			return this._routerState.root
		}
		get parent() {
			return this._routerState.parent(this)
		}
		get firstChild() {
			return this._routerState.firstChild(this)
		}
		get children() {
			return this._routerState.children(this)
		}
		get pathFromRoot() {
			return this._routerState.pathFromRoot(this)
		}
		get paramMap() {
			return this._paramMap ??= Qn(this.params), this._paramMap
		}
		get queryParamMap() {
			return this._queryParamMap ??= Qn(this.queryParams), this._queryParamMap
		}
		toString() {
			let t = this.url.map(n => n.toString()).join("/"),
				r = this.routeConfig ? this.routeConfig.path : "";
			return `Route(url:'${t}', path:'${r}')`
		}
	},
	ts = class extends Xo {
		constructor(t, r) {
			super(r), this.url = t, Vc(this, r)
		}
		toString() {
			return Ap(this._root)
		}
	};

function Vc(e, t) {
	t.value._routerState = e, t.children.forEach(r => Vc(e, r))
}

function Ap(e) {
	let t = e.children.length > 0 ? ` { ${e.children.map(Ap).join(", ")} } ` : "";
	return `${e.value}${t}`
}

function cc(e) {
	if (e.snapshot) {
		let t = e.snapshot,
			r = e._futureSnapshot;
		e.snapshot = r, nt(t.queryParams, r.queryParams) || e.queryParamsSubject.next(r.queryParams), t.fragment !== r.fragment && e.fragmentSubject.next(r.fragment), nt(t.params, r.params) || e.paramsSubject.next(r.params), I0(t.url, r.url) || e.urlSubject.next(r.url), nt(t.data, r.data) || e.dataSubject.next(r.data)
	} else e.snapshot = e._futureSnapshot, e.dataSubject.next(e._futureSnapshot.data)
}

function xc(e, t) {
	let r = nt(e.params, t.params) && T0(e.url, t.url),
		n = !e.parent != !t.parent;
	return r && !n && (!e.parent || xc(e.parent, t.parent))
}

function Np(e) {
	return typeof e.title == "string" || e.title === null
}
var jc = (() => {
		let t = class t {
			constructor() {
				this.activated = null, this._activatedRoute = null, this.name = N, this.activateEvents = new ie, this.deactivateEvents = new ie, this.attachEvents = new ie, this.detachEvents = new ie, this.parentContexts = p(ei), this.location = p(Un), this.changeDetector = p(an), this.environmentInjector = p(ge), this.inputBinder = p(ss, {
					optional: !0
				}), this.supportsBindingToComponentInputs = !0
			}
			get activatedComponentRef() {
				return this.activated
			}
			ngOnChanges(n) {
				if (n.name) {
					let {
						firstChange: i,
						previousValue: o
					} = n.name;
					if (i) return;
					this.isTrackedInParentContexts(o) && (this.deactivate(), this.parentContexts.onChildOutletDestroyed(o)), this.initializeOutletWithName()
				}
			}
			ngOnDestroy() {
				this.isTrackedInParentContexts(this.name) && this.parentContexts.onChildOutletDestroyed(this.name), this.inputBinder?.unsubscribeFromRouteData(this)
			}
			isTrackedInParentContexts(n) {
				return this.parentContexts.getContext(n)?.outlet === this
			}
			ngOnInit() {
				this.initializeOutletWithName()
			}
			initializeOutletWithName() {
				if (this.parentContexts.onChildOutletCreated(this.name, this), this.activated) return;
				let n = this.parentContexts.getContext(this.name);
				n?.route && (n.attachRef ? this.attach(n.attachRef, n.route) : this.activateWith(n.route, n.injector))
			}
			get isActivated() {
				return !!this.activated
			}
			get component() {
				if (!this.activated) throw new I(4012, !1);
				return this.activated.instance
			}
			get activatedRoute() {
				if (!this.activated) throw new I(4012, !1);
				return this._activatedRoute
			}
			get activatedRouteData() {
				return this._activatedRoute ? this._activatedRoute.snapshot.data : {}
			}
			detach() {
				if (!this.activated) throw new I(4012, !1);
				this.location.detach();
				let n = this.activated;
				return this.activated = null, this._activatedRoute = null, this.detachEvents.emit(n.instance), n
			}
			attach(n, i) {
				this.activated = n, this._activatedRoute = i, this.location.insert(n.hostView), this.inputBinder?.bindActivatedRouteToOutletComponent(this), this.attachEvents.emit(n.instance)
			}
			deactivate() {
				if (this.activated) {
					let n = this.component;
					this.activated.destroy(), this.activated = null, this._activatedRoute = null, this.deactivateEvents.emit(n)
				}
			}
			activateWith(n, i) {
				if (this.isActivated) throw new I(4013, !1);
				this._activatedRoute = n;
				let o = this.location,
					a = n.snapshot.component,
					u = this.parentContexts.getOrCreateContext(this.name).children,
					c = new Ac(n, u, o.injector);
				this.activated = o.createComponent(a, {
					index: o.length,
					injector: c,
					environmentInjector: i ?? this.environmentInjector
				}), this.changeDetector.markForCheck(), this.inputBinder?.bindActivatedRouteToOutletComponent(this), this.activateEvents.emit(this.activated.instance)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["router-outlet"]
			],
			inputs: {
				name: "name"
			},
			outputs: {
				activateEvents: "activate",
				deactivateEvents: "deactivate",
				attachEvents: "attach",
				detachEvents: "detach"
			},
			exportAs: ["outlet"],
			standalone: !0,
			features: [xt]
		});
		let e = t;
		return e
	})(),
	Ac = class {
		constructor(t, r, n) {
			this.route = t, this.childContexts = r, this.parent = n, this.__ngOutletInjector = !0
		}
		get(t, r) {
			return t === Lt ? this.route : t === ei ? this.childContexts : this.parent.get(t, r)
		}
	},
	ss = new w(""),
	dp = (() => {
		let t = class t {
			constructor() {
				this.outletDataSubscriptions = new Map
			}
			bindActivatedRouteToOutletComponent(n) {
				this.unsubscribeFromRouteData(n), this.subscribeToRouteData(n)
			}
			unsubscribeFromRouteData(n) {
				this.outletDataSubscriptions.get(n)?.unsubscribe(), this.outletDataSubscriptions.delete(n)
			}
			subscribeToRouteData(n) {
				let {
					activatedRoute: i
				} = n, o = ir([i.queryParams, i.params, i.data]).pipe(ye(([s, a, u], c) => (u = g(g(g({}, s), a), u), c === 0 ? b(u) : Promise.resolve(u)))).subscribe(s => {
					if (!n.isActivated || !n.activatedComponentRef || n.activatedRoute !== i || i.component === null) {
						this.unsubscribeFromRouteData(n);
						return
					}
					let a = Ah(i.component);
					if (!a) {
						this.unsubscribeFromRouteData(n);
						return
					}
					for (let {
							templateName: u
						}
						of a.inputs) n.activatedComponentRef.setInput(u, s[u])
				});
				this.outletDataSubscriptions.set(n, o)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})();

function Q0(e, t, r) {
	let n = Yr(e, t._root, r ? r._root : void 0);
	return new es(n, t)
}

function Yr(e, t, r) {
	if (r && e.shouldReuseRoute(t.value, r.value.snapshot)) {
		let n = r.value;
		n._futureSnapshot = t.value;
		let i = K0(e, t, r);
		return new Ae(n, i)
	} else {
		if (e.shouldAttach(t.value)) {
			let o = e.retrieve(t.value);
			if (o !== null) {
				let s = o.route;
				return s.value._futureSnapshot = t.value, s.children = t.children.map(a => Yr(e, a)), s
			}
		}
		let n = J0(t.value),
			i = t.children.map(o => Yr(e, o));
		return new Ae(n, i)
	}
}

function K0(e, t, r) {
	return t.children.map(n => {
		for (let i of r.children)
			if (e.shouldReuseRoute(n.value, i.value.snapshot)) return Yr(e, n, i);
		return Yr(e, n)
	})
}

function J0(e) {
	return new Lt(new W(e.url), new W(e.params), new W(e.queryParams), new W(e.fragment), new W(e.data), e.outlet, e.component, e)
}
var Rp = "ngNavigationCancelingError";

function Op(e, t) {
	let {
		redirectTo: r,
		navigationBehaviorOptions: n
	} = Kn(t) ? {
		redirectTo: t,
		navigationBehaviorOptions: void 0
	} : t, i = Fp(!1, Ne.Redirect);
	return i.url = r, i.navigationBehaviorOptions = n, i
}

function Fp(e, t) {
	let r = new Error(`NavigationCancelingError: ${e||""}`);
	return r[Rp] = !0, r.cancellationCode = t, r
}

function X0(e) {
	return Pp(e) && Kn(e.url)
}

function Pp(e) {
	return !!e && e[Rp]
}
var eE = (() => {
	let t = class t {};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["ng-component"]
		],
		standalone: !0,
		features: [fe],
		decls: 1,
		vars: 0,
		template: function(i, o) {
			i & 1 && Y(0, "router-outlet")
		},
		dependencies: [jc],
		encapsulation: 2
	});
	let e = t;
	return e
})();

function tE(e, t) {
	return e.providers && !e._injector && (e._injector = _o(e.providers, t, `Route: ${e.path}`)), e._injector ?? t
}

function Uc(e) {
	let t = e.children && e.children.map(Uc),
		r = t ? z(g({}, e), {
			children: t
		}) : g({}, e);
	return !r.component && !r.loadComponent && (t || r.loadChildren) && r.outlet && r.outlet !== N && (r.component = eE), r
}

function rt(e) {
	return e.outlet || N
}

function nE(e, t) {
	let r = e.filter(n => rt(n) === t);
	return r.push(...e.filter(n => rt(n) !== t)), r
}

function ti(e) {
	if (!e) return null;
	if (e.routeConfig?._injector) return e.routeConfig._injector;
	for (let t = e.parent; t; t = t.parent) {
		let r = t.routeConfig;
		if (r?._loadedInjector) return r._loadedInjector;
		if (r?._injector) return r._injector
	}
	return null
}
var rE = (e, t, r, n) => A(i => (new Nc(t, i.targetRouterState, i.currentRouterState, r, n).activate(e), i)),
	Nc = class {
		constructor(t, r, n, i, o) {
			this.routeReuseStrategy = t, this.futureState = r, this.currState = n, this.forwardEvent = i, this.inputBindingEnabled = o
		}
		activate(t) {
			let r = this.futureState._root,
				n = this.currState ? this.currState._root : null;
			this.deactivateChildRoutes(r, n, t), cc(this.futureState.root), this.activateChildRoutes(r, n, t)
		}
		deactivateChildRoutes(t, r, n) {
			let i = Wn(r);
			t.children.forEach(o => {
				let s = o.value.outlet;
				this.deactivateRoutes(o, i[s], n), delete i[s]
			}), Object.values(i).forEach(o => {
				this.deactivateRouteAndItsChildren(o, n)
			})
		}
		deactivateRoutes(t, r, n) {
			let i = t.value,
				o = r ? r.value : null;
			if (i === o)
				if (i.component) {
					let s = n.getContext(i.outlet);
					s && this.deactivateChildRoutes(t, r, s.children)
				} else this.deactivateChildRoutes(t, r, n);
			else o && this.deactivateRouteAndItsChildren(r, n)
		}
		deactivateRouteAndItsChildren(t, r) {
			t.value.component && this.routeReuseStrategy.shouldDetach(t.value.snapshot) ? this.detachAndStoreRouteSubtree(t, r) : this.deactivateRouteAndOutlet(t, r)
		}
		detachAndStoreRouteSubtree(t, r) {
			let n = r.getContext(t.value.outlet),
				i = n && t.value.component ? n.children : r,
				o = Wn(t);
			for (let s of Object.values(o)) this.deactivateRouteAndItsChildren(s, i);
			if (n && n.outlet) {
				let s = n.outlet.detach(),
					a = n.children.onOutletDeactivated();
				this.routeReuseStrategy.store(t.value.snapshot, {
					componentRef: s,
					route: t,
					contexts: a
				})
			}
		}
		deactivateRouteAndOutlet(t, r) {
			let n = r.getContext(t.value.outlet),
				i = n && t.value.component ? n.children : r,
				o = Wn(t);
			for (let s of Object.values(o)) this.deactivateRouteAndItsChildren(s, i);
			n && (n.outlet && (n.outlet.deactivate(), n.children.onOutletDeactivated()), n.attachRef = null, n.route = null)
		}
		activateChildRoutes(t, r, n) {
			let i = Wn(r);
			t.children.forEach(o => {
				this.activateRoutes(o, i[o.value.outlet], n), this.forwardEvent(new Mc(o.value.snapshot))
			}), t.children.length && this.forwardEvent(new bc(t.value.snapshot))
		}
		activateRoutes(t, r, n) {
			let i = t.value,
				o = r ? r.value : null;
			if (cc(i), i === o)
				if (i.component) {
					let s = n.getOrCreateContext(i.outlet);
					this.activateChildRoutes(t, r, s.children)
				} else this.activateChildRoutes(t, r, n);
			else if (i.component) {
				let s = n.getOrCreateContext(i.outlet);
				if (this.routeReuseStrategy.shouldAttach(i.snapshot)) {
					let a = this.routeReuseStrategy.retrieve(i.snapshot);
					this.routeReuseStrategy.store(i.snapshot, null), s.children.onOutletReAttached(a.contexts), s.attachRef = a.componentRef, s.route = a.route.value, s.outlet && s.outlet.attach(a.componentRef, a.route.value), cc(a.route.value), this.activateChildRoutes(t, null, s.children)
				} else {
					let a = ti(i.snapshot);
					s.attachRef = null, s.route = i, s.injector = a, s.outlet && s.outlet.activateWith(i, s.injector), this.activateChildRoutes(t, null, s.children)
				}
			} else this.activateChildRoutes(t, null, n)
		}
	},
	ns = class {
		constructor(t) {
			this.path = t, this.route = this.path[this.path.length - 1]
		}
	},
	Yn = class {
		constructor(t, r) {
			this.component = t, this.route = r
		}
	};

function iE(e, t, r) {
	let n = e._root,
		i = t ? t._root : null;
	return Vr(n, i, r, [n.value])
}

function oE(e) {
	let t = e.routeConfig ? e.routeConfig.canActivateChild : null;
	return !t || t.length === 0 ? null : {
		node: e,
		guards: t
	}
}

function er(e, t) {
	let r = Symbol(),
		n = t.get(e, r);
	return n === r ? typeof e == "function" && !vd(e) ? e : t.get(e) : n
}

function Vr(e, t, r, n, i = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	let o = Wn(t);
	return e.children.forEach(s => {
		sE(s, o[s.value.outlet], r, n.concat([s.value]), i), delete o[s.value.outlet]
	}), Object.entries(o).forEach(([s, a]) => Br(a, r.getContext(s), i)), i
}

function sE(e, t, r, n, i = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	let o = e.value,
		s = t ? t.value : null,
		a = r ? r.getContext(e.value.outlet) : null;
	if (s && o.routeConfig === s.routeConfig) {
		let u = aE(s, o, o.routeConfig.runGuardsAndResolvers);
		u ? i.canActivateChecks.push(new ns(n)) : (o.data = s.data, o._resolvedData = s._resolvedData), o.component ? Vr(e, t, a ? a.children : null, n, i) : Vr(e, t, r, n, i), u && a && a.outlet && a.outlet.isActivated && i.canDeactivateChecks.push(new Yn(a.outlet.component, s))
	} else s && Br(t, a, i), i.canActivateChecks.push(new ns(n)), o.component ? Vr(e, null, a ? a.children : null, n, i) : Vr(e, null, r, n, i);
	return i
}

function aE(e, t, r) {
	if (typeof r == "function") return r(e, t);
	switch (r) {
		case "pathParamsChange":
			return !ln(e.url, t.url);
		case "pathParamsOrQueryParamsChange":
			return !ln(e.url, t.url) || !nt(e.queryParams, t.queryParams);
		case "always":
			return !0;
		case "paramsOrQueryParamsChange":
			return !xc(e, t) || !nt(e.queryParams, t.queryParams);
		case "paramsChange":
		default:
			return !xc(e, t)
	}
}

function Br(e, t, r) {
	let n = Wn(e),
		i = e.value;
	Object.entries(n).forEach(([o, s]) => {
		i.component ? t ? Br(s, t.children.getContext(o), r) : Br(s, null, r) : Br(s, t, r)
	}), i.component ? t && t.outlet && t.outlet.isActivated ? r.canDeactivateChecks.push(new Yn(t.outlet.component, i)) : r.canDeactivateChecks.push(new Yn(null, i)) : r.canDeactivateChecks.push(new Yn(null, i))
}

function ni(e) {
	return typeof e == "function"
}

function uE(e) {
	return typeof e == "boolean"
}

function cE(e) {
	return e && ni(e.canLoad)
}

function lE(e) {
	return e && ni(e.canActivate)
}

function dE(e) {
	return e && ni(e.canActivateChild)
}

function fE(e) {
	return e && ni(e.canDeactivate)
}

function hE(e) {
	return e && ni(e.canMatch)
}

function kp(e) {
	return e instanceof ot || e?.name === "EmptyError"
}
var zo = Symbol("INITIAL_VALUE");

function Xn() {
	return ye(e => ir(e.map(t => t.pipe(at(1), ks(zo)))).pipe(A(t => {
		for (let r of t)
			if (r !== !0) {
				if (r === zo) return zo;
				if (r === !1 || r instanceof Ft) return r
			} return !0
	}), ve(t => t !== zo), at(1)))
}

function pE(e, t) {
	return K(r => {
		let {
			targetSnapshot: n,
			currentSnapshot: i,
			guards: {
				canActivateChecks: o,
				canDeactivateChecks: s
			}
		} = r;
		return s.length === 0 && o.length === 0 ? b(z(g({}, r), {
			guardsResult: !0
		})) : gE(s, n, i, e).pipe(K(a => a && uE(a) ? mE(n, o, e, t) : b(a)), A(a => z(g({}, r), {
			guardsResult: a
		})))
	})
}

function gE(e, t, r, n) {
	return G(e).pipe(K(i => CE(i.component, i.route, r, t, n)), We(i => i !== !0, !0))
}

function mE(e, t, r, n) {
	return G(t).pipe(st(i => Dn(yE(i.route.parent, n), vE(i.route, n), wE(e, i.path, r), DE(e, i.route, r))), We(i => i !== !0, !0))
}

function vE(e, t) {
	return e !== null && t && t(new Ic(e)), b(!0)
}

function yE(e, t) {
	return e !== null && t && t(new Ec(e)), b(!0)
}

function DE(e, t, r) {
	let n = t.routeConfig ? t.routeConfig.canActivate : null;
	if (!n || n.length === 0) return b(!0);
	let i = n.map(o => Ai(() => {
		let s = ti(t) ?? r,
			a = er(o, s),
			u = lE(a) ? a.canActivate(t, e) : He(s, () => a(t, e));
		return Vt(u).pipe(We())
	}));
	return b(i).pipe(Xn())
}

function wE(e, t, r) {
	let n = t[t.length - 1],
		o = t.slice(0, t.length - 1).reverse().map(s => oE(s)).filter(s => s !== null).map(s => Ai(() => {
			let a = s.guards.map(u => {
				let c = ti(s.node) ?? r,
					l = er(u, c),
					d = dE(l) ? l.canActivateChild(n, e) : He(c, () => l(n, e));
				return Vt(d).pipe(We())
			});
			return b(a).pipe(Xn())
		}));
	return b(o).pipe(Xn())
}

function CE(e, t, r, n, i) {
	let o = t && t.routeConfig ? t.routeConfig.canDeactivate : null;
	if (!o || o.length === 0) return b(!0);
	let s = o.map(a => {
		let u = ti(t) ?? i,
			c = er(a, u),
			l = fE(c) ? c.canDeactivate(e, t, r, n) : He(u, () => c(e, t, r, n));
		return Vt(l).pipe(We())
	});
	return b(s).pipe(Xn())
}

function EE(e, t, r, n) {
	let i = t.canLoad;
	if (i === void 0 || i.length === 0) return b(!0);
	let o = i.map(s => {
		let a = er(s, e),
			u = cE(a) ? a.canLoad(t, r) : He(e, () => a(t, r));
		return Vt(u)
	});
	return b(o).pipe(Xn(), Lp(n))
}

function Lp(e) {
	return Ss(ee(t => {
		if (Kn(t)) throw Op(e, t)
	}), A(t => t === !0))
}

function bE(e, t, r, n) {
	let i = t.canMatch;
	if (!i || i.length === 0) return b(!0);
	let o = i.map(s => {
		let a = er(s, e),
			u = hE(a) ? a.canMatch(t, r) : He(e, () => a(t, r));
		return Vt(u)
	});
	return b(o).pipe(Xn(), Lp(n))
}
var Qr = class {
		constructor(t) {
			this.segmentGroup = t || null
		}
	},
	rs = class extends Error {
		constructor(t) {
			super(), this.urlTree = t
		}
	};

function qn(e) {
	return yn(new Qr(e))
}

function IE(e) {
	return yn(new I(4e3, !1))
}

function ME(e) {
	return yn(Fp(!1, Ne.GuardRejected))
}
var Rc = class {
		constructor(t, r) {
			this.urlSerializer = t, this.urlTree = r
		}
		lineralizeSegments(t, r) {
			let n = [],
				i = r.root;
			for (;;) {
				if (n = n.concat(i.segments), i.numberOfChildren === 0) return b(n);
				if (i.numberOfChildren > 1 || !i.children[N]) return IE(t.redirectTo);
				i = i.children[N]
			}
		}
		applyRedirectCommands(t, r, n) {
			let i = this.applyRedirectCreateUrlTree(r, this.urlSerializer.parse(r), t, n);
			if (r.startsWith("/")) throw new rs(i);
			return i
		}
		applyRedirectCreateUrlTree(t, r, n, i) {
			let o = this.createSegmentGroup(t, r.root, n, i);
			return new Ft(o, this.createQueryParams(r.queryParams, this.urlTree.queryParams), r.fragment)
		}
		createQueryParams(t, r) {
			let n = {};
			return Object.entries(t).forEach(([i, o]) => {
				if (typeof o == "string" && o.startsWith(":")) {
					let a = o.substring(1);
					n[i] = r[a]
				} else n[i] = o
			}), n
		}
		createSegmentGroup(t, r, n, i) {
			let o = this.createSegments(t, r.segments, n, i),
				s = {};
			return Object.entries(r.children).forEach(([a, u]) => {
				s[a] = this.createSegmentGroup(t, u, n, i)
			}), new B(o, s)
		}
		createSegments(t, r, n, i) {
			return r.map(o => o.path.startsWith(":") ? this.findPosParam(t, o, i) : this.findOrReturn(o, n))
		}
		findPosParam(t, r, n) {
			let i = n[r.path.substring(1)];
			if (!i) throw new I(4001, !1);
			return i
		}
		findOrReturn(t, r) {
			let n = 0;
			for (let i of r) {
				if (i.path === t.path) return r.splice(n), i;
				n++
			}
			return t
		}
	},
	Oc = {
		matched: !1,
		consumedSegments: [],
		remainingSegments: [],
		parameters: {},
		positionalParamSegments: {}
	};

function _E(e, t, r, n, i) {
	let o = $c(e, t, r);
	return o.matched ? (n = tE(t, n), bE(n, t, r, i).pipe(A(s => s === !0 ? o : g({}, Oc)))) : b(o)
}

function $c(e, t, r) {
	if (t.path === "**") return SE(r);
	if (t.path === "") return t.pathMatch === "full" && (e.hasChildren() || r.length > 0) ? g({}, Oc) : {
		matched: !0,
		consumedSegments: [],
		remainingSegments: r,
		parameters: {},
		positionalParamSegments: {}
	};
	let i = (t.matcher || b0)(r, e, t);
	if (!i) return g({}, Oc);
	let o = {};
	Object.entries(i.posParams ?? {}).forEach(([a, u]) => {
		o[a] = u.path
	});
	let s = i.consumed.length > 0 ? g(g({}, o), i.consumed[i.consumed.length - 1].parameters) : o;
	return {
		matched: !0,
		consumedSegments: i.consumed,
		remainingSegments: r.slice(i.consumed.length),
		parameters: s,
		positionalParamSegments: i.posParams ?? {}
	}
}

function SE(e) {
	return {
		matched: !0,
		parameters: e.length > 0 ? mp(e).parameters : {},
		consumedSegments: e,
		remainingSegments: [],
		positionalParamSegments: {}
	}
}

function fp(e, t, r, n) {
	return r.length > 0 && AE(e, r, n) ? {
		segmentGroup: new B(t, xE(n, new B(r, e.children))),
		slicedSegments: []
	} : r.length === 0 && NE(e, r, n) ? {
		segmentGroup: new B(e.segments, TE(e, r, n, e.children)),
		slicedSegments: r
	} : {
		segmentGroup: new B(e.segments, e.children),
		slicedSegments: r
	}
}

function TE(e, t, r, n) {
	let i = {};
	for (let o of r)
		if (as(e, t, o) && !n[rt(o)]) {
			let s = new B([], {});
			i[rt(o)] = s
		} return g(g({}, n), i)
}

function xE(e, t) {
	let r = {};
	r[N] = t;
	for (let n of e)
		if (n.path === "" && rt(n) !== N) {
			let i = new B([], {});
			r[rt(n)] = i
		} return r
}

function AE(e, t, r) {
	return r.some(n => as(e, t, n) && rt(n) !== N)
}

function NE(e, t, r) {
	return r.some(n => as(e, t, n))
}

function as(e, t, r) {
	return (e.hasChildren() || t.length > 0) && r.pathMatch === "full" ? !1 : r.path === ""
}

function RE(e, t, r, n) {
	return rt(e) !== n && (n === N || !as(t, r, e)) ? !1 : $c(t, e, r).matched
}

function OE(e, t, r) {
	return t.length === 0 && !e.children[r]
}
var Fc = class {};

function FE(e, t, r, n, i, o, s = "emptyOnly") {
	return new Pc(e, t, r, n, i, s, o).recognize()
}
var PE = 31,
	Pc = class {
		constructor(t, r, n, i, o, s, a) {
			this.injector = t, this.configLoader = r, this.rootComponentType = n, this.config = i, this.urlTree = o, this.paramsInheritanceStrategy = s, this.urlSerializer = a, this.applyRedirects = new Rc(this.urlSerializer, this.urlTree), this.absoluteRedirectCount = 0, this.allowRedirects = !0
		}
		noMatchError(t) {
			return new I(4002, `'${t.segmentGroup}'`)
		}
		recognize() {
			let t = fp(this.urlTree.root, [], [], this.config).segmentGroup;
			return this.match(t).pipe(A(r => {
				let n = new Zr([], Object.freeze({}), Object.freeze(g({}, this.urlTree.queryParams)), this.urlTree.fragment, {}, N, this.rootComponentType, null, {}),
					i = new Ae(n, r),
					o = new ts("", i),
					s = B0(n, [], this.urlTree.queryParams, this.urlTree.fragment);
				return s.queryParams = this.urlTree.queryParams, o.url = this.urlSerializer.serialize(s), this.inheritParamsAndData(o._root, null), {
					state: o,
					tree: s
				}
			}))
		}
		match(t) {
			return this.processSegmentGroup(this.injector, this.config, t, N).pipe(Ct(n => {
				if (n instanceof rs) return this.urlTree = n.urlTree, this.match(n.urlTree.root);
				throw n instanceof Qr ? this.noMatchError(n) : n
			}))
		}
		inheritParamsAndData(t, r) {
			let n = t.value,
				i = Lc(n, r, this.paramsInheritanceStrategy);
			n.params = Object.freeze(i.params), n.data = Object.freeze(i.data), t.children.forEach(o => this.inheritParamsAndData(o, n))
		}
		processSegmentGroup(t, r, n, i) {
			return n.segments.length === 0 && n.hasChildren() ? this.processChildren(t, r, n) : this.processSegment(t, r, n, n.segments, i, !0).pipe(A(o => o instanceof Ae ? [o] : []))
		}
		processChildren(t, r, n) {
			let i = [];
			for (let o of Object.keys(n.children)) o === "primary" ? i.unshift(o) : i.push(o);
			return G(i).pipe(st(o => {
				let s = n.children[o],
					a = nE(r, o);
				return this.processSegmentGroup(t, a, s, o)
			}), Ps((o, s) => (o.push(...s), o)), Et(null), Fs(), K(o => {
				if (o === null) return qn(n);
				let s = Vp(o);
				return kE(s), b(s)
			}))
		}
		processSegment(t, r, n, i, o, s) {
			return G(r).pipe(st(a => this.processSegmentAgainstRoute(a._injector ?? t, r, a, n, i, o, s).pipe(Ct(u => {
				if (u instanceof Qr) return b(null);
				throw u
			}))), We(a => !!a), Ct(a => {
				if (kp(a)) return OE(n, i, o) ? b(new Fc) : qn(n);
				throw a
			}))
		}
		processSegmentAgainstRoute(t, r, n, i, o, s, a) {
			return RE(n, i, o, s) ? n.redirectTo === void 0 ? this.matchSegmentAgainstRoute(t, i, n, o, s) : this.allowRedirects && a ? this.expandSegmentAgainstRouteUsingRedirect(t, i, r, n, o, s) : qn(i) : qn(i)
		}
		expandSegmentAgainstRouteUsingRedirect(t, r, n, i, o, s) {
			let {
				matched: a,
				consumedSegments: u,
				positionalParamSegments: c,
				remainingSegments: l
			} = $c(r, i, o);
			if (!a) return qn(r);
			i.redirectTo.startsWith("/") && (this.absoluteRedirectCount++, this.absoluteRedirectCount > PE && (this.allowRedirects = !1));
			let d = this.applyRedirects.applyRedirectCommands(u, i.redirectTo, c);
			return this.applyRedirects.lineralizeSegments(i, d).pipe(K(f => this.processSegment(t, n, r, f.concat(l), s, !1)))
		}
		matchSegmentAgainstRoute(t, r, n, i, o) {
			let s = _E(r, n, i, t, this.urlSerializer);
			return n.path === "**" && (r.children = {}), s.pipe(ye(a => a.matched ? (t = n._injector ?? t, this.getChildConfig(t, n, i).pipe(ye(({
				routes: u
			}) => {
				let c = n._loadedInjector ?? t,
					{
						consumedSegments: l,
						remainingSegments: d,
						parameters: f
					} = a,
					h = new Zr(l, f, Object.freeze(g({}, this.urlTree.queryParams)), this.urlTree.fragment, VE(n), rt(n), n.component ?? n._loadedComponent ?? null, n, jE(n)),
					{
						segmentGroup: m,
						slicedSegments: S
					} = fp(r, l, d, u);
				if (S.length === 0 && m.hasChildren()) return this.processChildren(c, u, m).pipe(A(D => D === null ? null : new Ae(h, D)));
				if (u.length === 0 && S.length === 0) return b(new Ae(h, []));
				let E = rt(n) === o;
				return this.processSegment(c, u, m, S, E ? N : o, !0).pipe(A(D => new Ae(h, D instanceof Ae ? [D] : [])))
			}))) : qn(r)))
		}
		getChildConfig(t, r, n) {
			return r.children ? b({
				routes: r.children,
				injector: t
			}) : r.loadChildren ? r._loadedRoutes !== void 0 ? b({
				routes: r._loadedRoutes,
				injector: r._loadedInjector
			}) : EE(t, r, n, this.urlSerializer).pipe(K(i => i ? this.configLoader.loadChildren(t, r).pipe(ee(o => {
				r._loadedRoutes = o.routes, r._loadedInjector = o.injector
			})) : ME(r))) : b({
				routes: [],
				injector: t
			})
		}
	};

function kE(e) {
	e.sort((t, r) => t.value.outlet === N ? -1 : r.value.outlet === N ? 1 : t.value.outlet.localeCompare(r.value.outlet))
}

function LE(e) {
	let t = e.value.routeConfig;
	return t && t.path === ""
}

function Vp(e) {
	let t = [],
		r = new Set;
	for (let n of e) {
		if (!LE(n)) {
			t.push(n);
			continue
		}
		let i = t.find(o => n.value.routeConfig === o.value.routeConfig);
		i !== void 0 ? (i.children.push(...n.children), r.add(i)) : t.push(n)
	}
	for (let n of r) {
		let i = Vp(n.children);
		t.push(new Ae(n.value, i))
	}
	return t.filter(n => !r.has(n))
}

function VE(e) {
	return e.data || {}
}

function jE(e) {
	return e.resolve || {}
}

function UE(e, t, r, n, i, o) {
	return K(s => FE(e, t, r, n, s.extractedUrl, i, o).pipe(A(({
		state: a,
		tree: u
	}) => z(g({}, s), {
		targetSnapshot: a,
		urlAfterRedirects: u
	}))))
}

function $E(e, t) {
	return K(r => {
		let {
			targetSnapshot: n,
			guards: {
				canActivateChecks: i
			}
		} = r;
		if (!i.length) return b(r);
		let o = new Set(i.map(u => u.route)),
			s = new Set;
		for (let u of o)
			if (!s.has(u))
				for (let c of jp(u)) s.add(c);
		let a = 0;
		return G(s).pipe(st(u => o.has(u) ? BE(u, n, e, t) : (u.data = Lc(u, u.parent, e).resolve, b(void 0))), ee(() => a++), wn(1), K(u => a === s.size ? b(r) : Ie))
	})
}

function jp(e) {
	let t = e.children.map(r => jp(r)).flat();
	return [e, ...t]
}

function BE(e, t, r, n) {
	let i = e.routeConfig,
		o = e._resolve;
	return i?.title !== void 0 && !Np(i) && (o[Jr] = i.title), HE(o, e, t, n).pipe(A(s => (e._resolvedData = s, e.data = Lc(e, e.parent, r).resolve, null)))
}

function HE(e, t, r, n) {
	let i = fc(e);
	if (i.length === 0) return b({});
	let o = {};
	return G(i).pipe(K(s => zE(e[s], t, r, n).pipe(We(), ee(a => {
		o[s] = a
	}))), wn(1), Os(o), Ct(s => kp(s) ? Ie : yn(s)))
}

function zE(e, t, r, n) {
	let i = ti(t) ?? n,
		o = er(e, i),
		s = o.resolve ? o.resolve(t, r) : He(i, () => o(t, r));
	return Vt(s)
}

function lc(e) {
	return ye(t => {
		let r = e(t);
		return r ? G(r).pipe(A(() => t)) : b(t)
	})
}
var Up = (() => {
		let t = class t {
			buildTitle(n) {
				let i, o = n.root;
				for (; o !== void 0;) i = this.getResolvedTitleForRoute(o) ?? i, o = o.children.find(s => s.outlet === N);
				return i
			}
			getResolvedTitleForRoute(n) {
				return n.data[Jr]
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(GE),
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	GE = (() => {
		let t = class t extends Up {
			constructor(n) {
				super(), this.title = n
			}
			updateTitle(n) {
				let i = this.buildTitle(n);
				i !== void 0 && this.title.setTitle(i)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(sp))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	ri = new w("", {
		providedIn: "root",
		factory: () => ({})
	}),
	Kr = new w(""),
	Bc = (() => {
		let t = class t {
			constructor() {
				this.componentLoaders = new WeakMap, this.childrenLoaders = new WeakMap, this.compiler = p(Ro)
			}
			loadComponent(n) {
				if (this.componentLoaders.get(n)) return this.componentLoaders.get(n);
				if (n._loadedComponent) return b(n._loadedComponent);
				this.onLoadStartListener && this.onLoadStartListener(n);
				let i = Vt(n.loadComponent()).pipe(A($p), ee(s => {
						this.onLoadEndListener && this.onLoadEndListener(n), n._loadedComponent = s
					}), bt(() => {
						this.componentLoaders.delete(n)
					})),
					o = new vn(i, () => new X).pipe(mn());
				return this.componentLoaders.set(n, o), o
			}
			loadChildren(n, i) {
				if (this.childrenLoaders.get(i)) return this.childrenLoaders.get(i);
				if (i._loadedRoutes) return b({
					routes: i._loadedRoutes,
					injector: i._loadedInjector
				});
				this.onLoadStartListener && this.onLoadStartListener(i);
				let s = qE(i, this.compiler, n, this.onLoadEndListener).pipe(bt(() => {
						this.childrenLoaders.delete(i)
					})),
					a = new vn(s, () => new X).pipe(mn());
				return this.childrenLoaders.set(i, a), a
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})();

function qE(e, t, r, n) {
	return Vt(e.loadChildren()).pipe(A($p), K(i => i instanceof Dr || Array.isArray(i) ? b(i) : G(t.compileModuleAsync(i))), A(i => {
		n && n(e);
		let o, s, a = !1;
		return Array.isArray(i) ? (s = i, a = !0) : (o = i.create(r).injector, s = o.get(Kr, [], {
			optional: !0,
			self: !0
		}).flat()), {
			routes: s.map(Uc),
			injector: o
		}
	}))
}

function WE(e) {
	return e && typeof e == "object" && "default" in e
}

function $p(e) {
	return WE(e) ? e.default : e
}
var Hc = (() => {
		let t = class t {};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(ZE),
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	ZE = (() => {
		let t = class t {
			shouldProcessUrl(n) {
				return !0
			}
			extract(n) {
				return n
			}
			merge(n, i) {
				return n
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Bp = new w(""),
	Hp = new w("");

function YE(e, t, r) {
	let n = e.get(Hp),
		i = e.get(he);
	return e.get(Z).runOutsideAngular(() => {
		if (!i.startViewTransition || n.skipNextTransition) return n.skipNextTransition = !1, Promise.resolve();
		let o, s = new Promise(c => {
				o = c
			}),
			a = i.startViewTransition(() => (o(), QE(e))),
			{
				onViewTransitionCreated: u
			} = n;
		return u && He(e, () => u({
			transition: a,
			from: t,
			to: r
		})), s
	})
}

function QE(e) {
	return new Promise(t => {
		Ru(t, {
			injector: e
		})
	})
}
var zc = (() => {
	let t = class t {
		get hasRequestedNavigation() {
			return this.navigationId !== 0
		}
		constructor() {
			this.currentNavigation = null, this.currentTransition = null, this.lastSuccessfulNavigation = null, this.events = new X, this.transitionAbortSubject = new X, this.configLoader = p(Bc), this.environmentInjector = p(ge), this.urlSerializer = p(Xr), this.rootContexts = p(ei), this.location = p(zn), this.inputBindingEnabled = p(ss, {
				optional: !0
			}) !== null, this.titleStrategy = p(Up), this.options = p(ri, {
				optional: !0
			}) || {}, this.paramsInheritanceStrategy = this.options.paramsInheritanceStrategy || "emptyOnly", this.urlHandlingStrategy = p(Hc), this.createViewTransition = p(Bp, {
				optional: !0
			}), this.navigationId = 0, this.afterPreactivation = () => b(void 0), this.rootComponentType = null;
			let n = o => this.events.next(new wc(o)),
				i = o => this.events.next(new Cc(o));
			this.configLoader.onLoadEndListener = i, this.configLoader.onLoadStartListener = n
		}
		complete() {
			this.transitions?.complete()
		}
		handleNavigationRequest(n) {
			let i = ++this.navigationId;
			this.transitions?.next(z(g(g({}, this.transitions.value), n), {
				id: i
			}))
		}
		setupNavigations(n, i, o) {
			return this.transitions = new W({
				id: 0,
				currentUrlTree: i,
				currentRawUrl: i,
				extractedUrl: this.urlHandlingStrategy.extract(i),
				urlAfterRedirects: this.urlHandlingStrategy.extract(i),
				rawUrl: i,
				extras: {},
				resolve: null,
				reject: null,
				promise: Promise.resolve(!0),
				source: $r,
				restoredState: null,
				currentSnapshot: o.snapshot,
				targetSnapshot: null,
				currentRouterState: o,
				targetRouterState: null,
				guards: {
					canActivateChecks: [],
					canDeactivateChecks: []
				},
				guardsResult: null
			}), this.transitions.pipe(ve(s => s.id !== 0), A(s => z(g({}, s), {
				extractedUrl: this.urlHandlingStrategy.extract(s.rawUrl)
			})), ye(s => {
				let a = !1,
					u = !1;
				return b(s).pipe(ye(c => {
					if (this.navigationId > s.id) return this.cancelNavigationTransition(s, "", Ne.SupersededByNewNavigation), Ie;
					this.currentTransition = s, this.currentNavigation = {
						id: c.id,
						initialUrl: c.rawUrl,
						extractedUrl: c.extractedUrl,
						trigger: c.source,
						extras: c.extras,
						previousNavigation: this.lastSuccessfulNavigation ? z(g({}, this.lastSuccessfulNavigation), {
							previousNavigation: null
						}) : null
					};
					let l = !n.navigated || this.isUpdatingInternalState() || this.isUpdatedBrowserUrl(),
						d = c.extras.onSameUrlNavigation ?? n.onSameUrlNavigation;
					if (!l && d !== "reload") {
						let f = "";
						return this.events.next(new kt(c.id, this.urlSerializer.serialize(c.rawUrl), f, Qo.IgnoredSameUrlNavigation)), c.resolve(null), Ie
					}
					if (this.urlHandlingStrategy.shouldProcessUrl(c.rawUrl)) return b(c).pipe(ye(f => {
						let h = this.transitions?.getValue();
						return this.events.next(new Jn(f.id, this.urlSerializer.serialize(f.extractedUrl), f.source, f.restoredState)), h !== this.transitions?.getValue() ? Ie : Promise.resolve(f)
					}), UE(this.environmentInjector, this.configLoader, this.rootComponentType, n.config, this.urlSerializer, this.paramsInheritanceStrategy), ee(f => {
						s.targetSnapshot = f.targetSnapshot, s.urlAfterRedirects = f.urlAfterRedirects, this.currentNavigation = z(g({}, this.currentNavigation), {
							finalUrl: f.urlAfterRedirects
						});
						let h = new Ko(f.id, this.urlSerializer.serialize(f.extractedUrl), this.urlSerializer.serialize(f.urlAfterRedirects), f.targetSnapshot);
						this.events.next(h)
					}));
					if (l && this.urlHandlingStrategy.shouldProcessUrl(c.currentRawUrl)) {
						let {
							id: f,
							extractedUrl: h,
							source: m,
							restoredState: S,
							extras: E
						} = c, D = new Jn(f, this.urlSerializer.serialize(h), m, S);
						this.events.next(D);
						let ae = xp(this.rootComponentType).snapshot;
						return this.currentTransition = s = z(g({}, c), {
							targetSnapshot: ae,
							urlAfterRedirects: h,
							extras: z(g({}, E), {
								skipLocationChange: !1,
								replaceUrl: !1
							})
						}), this.currentNavigation.finalUrl = h, b(s)
					} else {
						let f = "";
						return this.events.next(new kt(c.id, this.urlSerializer.serialize(c.extractedUrl), f, Qo.IgnoredByUrlHandlingStrategy)), c.resolve(null), Ie
					}
				}), ee(c => {
					let l = new mc(c.id, this.urlSerializer.serialize(c.extractedUrl), this.urlSerializer.serialize(c.urlAfterRedirects), c.targetSnapshot);
					this.events.next(l)
				}), A(c => (this.currentTransition = s = z(g({}, c), {
					guards: iE(c.targetSnapshot, c.currentSnapshot, this.rootContexts)
				}), s)), pE(this.environmentInjector, c => this.events.next(c)), ee(c => {
					if (s.guardsResult = c.guardsResult, Kn(c.guardsResult)) throw Op(this.urlSerializer, c.guardsResult);
					let l = new vc(c.id, this.urlSerializer.serialize(c.extractedUrl), this.urlSerializer.serialize(c.urlAfterRedirects), c.targetSnapshot, !!c.guardsResult);
					this.events.next(l)
				}), ve(c => c.guardsResult ? !0 : (this.cancelNavigationTransition(c, "", Ne.GuardRejected), !1)), lc(c => {
					if (c.guards.canActivateChecks.length) return b(c).pipe(ee(l => {
						let d = new yc(l.id, this.urlSerializer.serialize(l.extractedUrl), this.urlSerializer.serialize(l.urlAfterRedirects), l.targetSnapshot);
						this.events.next(d)
					}), ye(l => {
						let d = !1;
						return b(l).pipe($E(this.paramsInheritanceStrategy, this.environmentInjector), ee({
							next: () => d = !0,
							complete: () => {
								d || this.cancelNavigationTransition(l, "", Ne.NoDataFromResolver)
							}
						}))
					}), ee(l => {
						let d = new Dc(l.id, this.urlSerializer.serialize(l.extractedUrl), this.urlSerializer.serialize(l.urlAfterRedirects), l.targetSnapshot);
						this.events.next(d)
					}))
				}), lc(c => {
					let l = d => {
						let f = [];
						d.routeConfig?.loadComponent && !d.routeConfig._loadedComponent && f.push(this.configLoader.loadComponent(d.routeConfig).pipe(ee(h => {
							d.component = h
						}), A(() => {})));
						for (let h of d.children) f.push(...l(h));
						return f
					};
					return ir(l(c.targetSnapshot.root)).pipe(Et(null), at(1))
				}), lc(() => this.afterPreactivation()), ye(() => {
					let {
						currentSnapshot: c,
						targetSnapshot: l
					} = s, d = this.createViewTransition?.(this.environmentInjector, c.root, l.root);
					return d ? G(d).pipe(A(() => s)) : b(s)
				}), A(c => {
					let l = Q0(n.routeReuseStrategy, c.targetSnapshot, c.currentRouterState);
					return this.currentTransition = s = z(g({}, c), {
						targetRouterState: l
					}), this.currentNavigation.targetRouterState = l, s
				}), ee(() => {
					this.events.next(new qr)
				}), rE(this.rootContexts, n.routeReuseStrategy, c => this.events.next(c), this.inputBindingEnabled), at(1), ee({
					next: c => {
						a = !0, this.lastSuccessfulNavigation = this.currentNavigation, this.events.next(new Ge(c.id, this.urlSerializer.serialize(c.extractedUrl), this.urlSerializer.serialize(c.urlAfterRedirects))), this.titleStrategy?.updateTitle(c.targetRouterState.snapshot), c.resolve(!0)
					},
					complete: () => {
						a = !0
					}
				}), Cn(this.transitionAbortSubject.pipe(ee(c => {
					throw c
				}))), bt(() => {
					!a && !u && this.cancelNavigationTransition(s, "", Ne.SupersededByNewNavigation), this.currentTransition?.id === s.id && (this.currentNavigation = null, this.currentTransition = null)
				}), Ct(c => {
					if (u = !0, Pp(c)) this.events.next(new Pt(s.id, this.urlSerializer.serialize(s.extractedUrl), c.message, c.cancellationCode)), X0(c) ? this.events.next(new Wr(c.url)) : s.resolve(!1);
					else {
						this.events.next(new Gr(s.id, this.urlSerializer.serialize(s.extractedUrl), c, s.targetSnapshot ?? void 0));
						try {
							s.resolve(n.errorHandler(c))
						} catch (l) {
							this.options.resolveNavigationPromiseOnError ? s.resolve(!1) : s.reject(l)
						}
					}
					return Ie
				}))
			}))
		}
		cancelNavigationTransition(n, i, o) {
			let s = new Pt(n.id, this.urlSerializer.serialize(n.extractedUrl), i, o);
			this.events.next(s), n.resolve(!1)
		}
		isUpdatingInternalState() {
			return this.currentTransition?.extractedUrl.toString() !== this.currentTransition?.currentUrlTree.toString()
		}
		isUpdatedBrowserUrl() {
			return this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(!0))).toString() !== this.currentTransition?.extractedUrl.toString() && !this.currentTransition?.extras.skipLocationChange
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();

function KE(e) {
	return e !== $r
}
var JE = (() => {
		let t = class t {};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(XE),
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	kc = class {
		shouldDetach(t) {
			return !1
		}
		store(t, r) {}
		shouldAttach(t) {
			return !1
		}
		retrieve(t) {
			return null
		}
		shouldReuseRoute(t, r) {
			return t.routeConfig === r.routeConfig
		}
	},
	XE = (() => {
		let t = class t extends kc {};
		t.\u0275fac = (() => {
			let n;
			return function(o) {
				return (n || (n = Sr(t)))(o || t)
			}
		})(), t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	zp = (() => {
		let t = class t {};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: () => p(eb),
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	eb = (() => {
		let t = class t extends zp {
			constructor() {
				super(...arguments), this.location = p(zn), this.urlSerializer = p(Xr), this.options = p(ri, {
					optional: !0
				}) || {}, this.canceledNavigationResolution = this.options.canceledNavigationResolution || "replace", this.urlHandlingStrategy = p(Hc), this.urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred", this.currentUrlTree = new Ft, this.rawUrlTree = this.currentUrlTree, this.currentPageId = 0, this.lastSuccessfulId = -1, this.routerState = xp(null), this.stateMemento = this.createStateMemento()
			}
			getCurrentUrlTree() {
				return this.currentUrlTree
			}
			getRawUrlTree() {
				return this.rawUrlTree
			}
			restoredState() {
				return this.location.getState()
			}
			get browserPageId() {
				return this.canceledNavigationResolution !== "computed" ? this.currentPageId : this.restoredState()?.\u0275routerPageId ?? this.currentPageId
			}
			getRouterState() {
				return this.routerState
			}
			createStateMemento() {
				return {
					rawUrlTree: this.rawUrlTree,
					currentUrlTree: this.currentUrlTree,
					routerState: this.routerState
				}
			}
			registerNonRouterCurrentEntryChangeListener(n) {
				return this.location.subscribe(i => {
					i.type === "popstate" && n(i.url, i.state)
				})
			}
			handleRouterEvent(n, i) {
				if (n instanceof Jn) this.stateMemento = this.createStateMemento();
				else if (n instanceof kt) this.rawUrlTree = i.initialUrl;
				else if (n instanceof Ko) {
					if (this.urlUpdateStrategy === "eager" && !i.extras.skipLocationChange) {
						let o = this.urlHandlingStrategy.merge(i.finalUrl, i.initialUrl);
						this.setBrowserUrl(o, i)
					}
				} else n instanceof qr ? (this.currentUrlTree = i.finalUrl, this.rawUrlTree = this.urlHandlingStrategy.merge(i.finalUrl, i.initialUrl), this.routerState = i.targetRouterState, this.urlUpdateStrategy === "deferred" && (i.extras.skipLocationChange || this.setBrowserUrl(this.rawUrlTree, i))) : n instanceof Pt && (n.code === Ne.GuardRejected || n.code === Ne.NoDataFromResolver) ? this.restoreHistory(i) : n instanceof Gr ? this.restoreHistory(i, !0) : n instanceof Ge && (this.lastSuccessfulId = n.id, this.currentPageId = this.browserPageId)
			}
			setBrowserUrl(n, i) {
				let o = this.urlSerializer.serialize(n);
				if (this.location.isCurrentPathEqualTo(o) || i.extras.replaceUrl) {
					let s = this.browserPageId,
						a = g(g({}, i.extras.state), this.generateNgRouterState(i.id, s));
					this.location.replaceState(o, "", a)
				} else {
					let s = g(g({}, i.extras.state), this.generateNgRouterState(i.id, this.browserPageId + 1));
					this.location.go(o, "", s)
				}
			}
			restoreHistory(n, i = !1) {
				if (this.canceledNavigationResolution === "computed") {
					let o = this.browserPageId,
						s = this.currentPageId - o;
					s !== 0 ? this.location.historyGo(s) : this.currentUrlTree === n.finalUrl && s === 0 && (this.resetState(n), this.resetUrlToCurrentUrlTree())
				} else this.canceledNavigationResolution === "replace" && (i && this.resetState(n), this.resetUrlToCurrentUrlTree())
			}
			resetState(n) {
				this.routerState = this.stateMemento.routerState, this.currentUrlTree = this.stateMemento.currentUrlTree, this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, n.finalUrl ?? this.rawUrlTree)
			}
			resetUrlToCurrentUrlTree() {
				this.location.replaceState(this.urlSerializer.serialize(this.rawUrlTree), "", this.generateNgRouterState(this.lastSuccessfulId, this.currentPageId))
			}
			generateNgRouterState(n, i) {
				return this.canceledNavigationResolution === "computed" ? {
					navigationId: n,
					\u0275routerPageId: i
				} : {
					navigationId: n
				}
			}
		};
		t.\u0275fac = (() => {
			let n;
			return function(o) {
				return (n || (n = Sr(t)))(o || t)
			}
		})(), t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	jr = function(e) {
		return e[e.COMPLETE = 0] = "COMPLETE", e[e.FAILED = 1] = "FAILED", e[e.REDIRECTING = 2] = "REDIRECTING", e
	}(jr || {});

function Gp(e, t) {
	e.events.pipe(ve(r => r instanceof Ge || r instanceof Pt || r instanceof Gr || r instanceof kt), A(r => r instanceof Ge || r instanceof kt ? jr.COMPLETE : (r instanceof Pt ? r.code === Ne.Redirect || r.code === Ne.SupersededByNewNavigation : !1) ? jr.REDIRECTING : jr.FAILED), ve(r => r !== jr.REDIRECTING), at(1)).subscribe(() => {
		t()
	})
}

function tb(e) {
	throw e
}
var nb = {
		paths: "exact",
		fragment: "ignored",
		matrixParams: "ignored",
		queryParams: "exact"
	},
	rb = {
		paths: "subset",
		fragment: "ignored",
		matrixParams: "ignored",
		queryParams: "subset"
	},
	it = (() => {
		let t = class t {
			get currentUrlTree() {
				return this.stateManager.getCurrentUrlTree()
			}
			get rawUrlTree() {
				return this.stateManager.getRawUrlTree()
			}
			get events() {
				return this._events
			}
			get routerState() {
				return this.stateManager.getRouterState()
			}
			constructor() {
				this.disposed = !1, this.isNgZoneEnabled = !1, this.console = p(Ao), this.stateManager = p(zp), this.options = p(ri, {
					optional: !0
				}) || {}, this.pendingTasks = p(nn), this.urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred", this.navigationTransitions = p(zc), this.urlSerializer = p(Xr), this.location = p(zn), this.urlHandlingStrategy = p(Hc), this._events = new X, this.errorHandler = this.options.errorHandler || tb, this.navigated = !1, this.routeReuseStrategy = p(JE), this.onSameUrlNavigation = this.options.onSameUrlNavigation || "ignore", this.config = p(Kr, {
					optional: !0
				})?.flat() ?? [], this.componentInputBindingEnabled = !!p(ss, {
					optional: !0
				}), this.eventsSubscription = new J, this.isNgZoneEnabled = p(Z) instanceof Z && Z.isInAngularZone(), this.resetConfig(this.config), this.navigationTransitions.setupNavigations(this, this.currentUrlTree, this.routerState).subscribe({
					error: n => {
						this.console.warn(n)
					}
				}), this.subscribeToNavigationEvents()
			}
			subscribeToNavigationEvents() {
				let n = this.navigationTransitions.events.subscribe(i => {
					try {
						let o = this.navigationTransitions.currentTransition,
							s = this.navigationTransitions.currentNavigation;
						if (o !== null && s !== null) {
							if (this.stateManager.handleRouterEvent(i, s), i instanceof Pt && i.code !== Ne.Redirect && i.code !== Ne.SupersededByNewNavigation) this.navigated = !0;
							else if (i instanceof Ge) this.navigated = !0;
							else if (i instanceof Wr) {
								let a = this.urlHandlingStrategy.merge(i.url, o.currentRawUrl),
									u = {
										info: o.extras.info,
										skipLocationChange: o.extras.skipLocationChange,
										replaceUrl: this.urlUpdateStrategy === "eager" || KE(o.source)
									};
								this.scheduleNavigation(a, $r, null, u, {
									resolve: o.resolve,
									reject: o.reject,
									promise: o.promise
								})
							}
						}
						ob(i) && this._events.next(i)
					} catch (o) {
						this.navigationTransitions.transitionAbortSubject.next(o)
					}
				});
				this.eventsSubscription.add(n)
			}
			resetRootComponentType(n) {
				this.routerState.root.component = n, this.navigationTransitions.rootComponentType = n
			}
			initialNavigation() {
				this.setUpLocationChangeListener(), this.navigationTransitions.hasRequestedNavigation || this.navigateToSyncWithBrowser(this.location.path(!0), $r, this.stateManager.restoredState())
			}
			setUpLocationChangeListener() {
				this.nonRouterCurrentEntryChangeSubscription ??= this.stateManager.registerNonRouterCurrentEntryChangeListener((n, i) => {
					setTimeout(() => {
						this.navigateToSyncWithBrowser(n, "popstate", i)
					}, 0)
				})
			}
			navigateToSyncWithBrowser(n, i, o) {
				let s = {
						replaceUrl: !0
					},
					a = o?.navigationId ? o : null;
				if (o) {
					let c = g({}, o);
					delete c.navigationId, delete c.\u0275routerPageId, Object.keys(c).length !== 0 && (s.state = c)
				}
				let u = this.parseUrl(n);
				this.scheduleNavigation(u, i, a, s)
			}
			get url() {
				return this.serializeUrl(this.currentUrlTree)
			}
			getCurrentNavigation() {
				return this.navigationTransitions.currentNavigation
			}
			get lastSuccessfulNavigation() {
				return this.navigationTransitions.lastSuccessfulNavigation
			}
			resetConfig(n) {
				this.config = n.map(Uc), this.navigated = !1
			}
			ngOnDestroy() {
				this.dispose()
			}
			dispose() {
				this.navigationTransitions.complete(), this.nonRouterCurrentEntryChangeSubscription && (this.nonRouterCurrentEntryChangeSubscription.unsubscribe(), this.nonRouterCurrentEntryChangeSubscription = void 0), this.disposed = !0, this.eventsSubscription.unsubscribe()
			}
			createUrlTree(n, i = {}) {
				let {
					relativeTo: o,
					queryParams: s,
					fragment: a,
					queryParamsHandling: u,
					preserveFragment: c
				} = i, l = c ? this.currentUrlTree.fragment : a, d = null;
				switch (u) {
					case "merge":
						d = g(g({}, this.currentUrlTree.queryParams), s);
						break;
					case "preserve":
						d = this.currentUrlTree.queryParams;
						break;
					default:
						d = s || null
				}
				d !== null && (d = this.removeEmptyProps(d));
				let f;
				try {
					let h = o ? o.snapshot : this.routerState.snapshot.root;
					f = Mp(h)
				} catch {
					(typeof n[0] != "string" || !n[0].startsWith("/")) && (n = []), f = this.currentUrlTree.root
				}
				return _p(f, n, d, l ?? null)
			}
			navigateByUrl(n, i = {
				skipLocationChange: !1
			}) {
				let o = Kn(n) ? n : this.parseUrl(n),
					s = this.urlHandlingStrategy.merge(o, this.rawUrlTree);
				return this.scheduleNavigation(s, $r, null, i)
			}
			navigate(n, i = {
				skipLocationChange: !1
			}) {
				return ib(n), this.navigateByUrl(this.createUrlTree(n, i), i)
			}
			serializeUrl(n) {
				return this.urlSerializer.serialize(n)
			}
			parseUrl(n) {
				try {
					return this.urlSerializer.parse(n)
				} catch {
					return this.urlSerializer.parse("/")
				}
			}
			isActive(n, i) {
				let o;
				if (i === !0 ? o = g({}, nb) : i === !1 ? o = g({}, rb) : o = i, Kn(n)) return ap(this.currentUrlTree, n, o);
				let s = this.parseUrl(n);
				return ap(this.currentUrlTree, s, o)
			}
			removeEmptyProps(n) {
				return Object.entries(n).reduce((i, [o, s]) => (s != null && (i[o] = s), i), {})
			}
			scheduleNavigation(n, i, o, s, a) {
				if (this.disposed) return Promise.resolve(!1);
				let u, c, l;
				a ? (u = a.resolve, c = a.reject, l = a.promise) : l = new Promise((f, h) => {
					u = f, c = h
				});
				let d = this.pendingTasks.add();
				return Gp(this, () => {
					queueMicrotask(() => this.pendingTasks.remove(d))
				}), this.navigationTransitions.handleNavigationRequest({
					source: i,
					restoredState: o,
					currentUrlTree: this.currentUrlTree,
					currentRawUrl: this.currentUrlTree,
					rawUrl: n,
					extras: s,
					resolve: u,
					reject: c,
					promise: l,
					currentSnapshot: this.routerState.snapshot,
					currentRouterState: this.routerState
				}), l.catch(f => Promise.reject(f))
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})();

function ib(e) {
	for (let t = 0; t < e.length; t++)
		if (e[t] == null) throw new I(4008, !1)
}

function ob(e) {
	return !(e instanceof qr) && !(e instanceof Wr)
}
var is = (() => {
		let t = class t {
			constructor(n, i, o, s, a, u) {
				this.router = n, this.route = i, this.tabIndexAttribute = o, this.renderer = s, this.el = a, this.locationStrategy = u, this.href = null, this.commands = null, this.onChanges = new X, this.preserveFragment = !1, this.skipLocationChange = !1, this.replaceUrl = !1;
				let c = a.nativeElement.tagName?.toLowerCase();
				this.isAnchorElement = c === "a" || c === "area", this.isAnchorElement ? this.subscription = n.events.subscribe(l => {
					l instanceof Ge && this.updateHref()
				}) : this.setTabIndexIfNotOnNativeEl("0")
			}
			setTabIndexIfNotOnNativeEl(n) {
				this.tabIndexAttribute != null || this.isAnchorElement || this.applyAttributeValue("tabindex", n)
			}
			ngOnChanges(n) {
				this.isAnchorElement && this.updateHref(), this.onChanges.next(this)
			}
			set routerLink(n) {
				n != null ? (this.commands = Array.isArray(n) ? n : [n], this.setTabIndexIfNotOnNativeEl("0")) : (this.commands = null, this.setTabIndexIfNotOnNativeEl(null))
			}
			onClick(n, i, o, s, a) {
				let u = this.urlTree;
				if (u === null || this.isAnchorElement && (n !== 0 || i || o || s || a || typeof this.target == "string" && this.target != "_self")) return !0;
				let c = {
					skipLocationChange: this.skipLocationChange,
					replaceUrl: this.replaceUrl,
					state: this.state,
					info: this.info
				};
				return this.router.navigateByUrl(u, c), !this.isAnchorElement
			}
			ngOnDestroy() {
				this.subscription?.unsubscribe()
			}
			updateHref() {
				let n = this.urlTree;
				this.href = n !== null && this.locationStrategy ? this.locationStrategy?.prepareExternalUrl(this.router.serializeUrl(n)) : null;
				let i = this.href === null ? null : Rf(this.href, this.el.nativeElement.tagName.toLowerCase(), "href");
				this.applyAttributeValue("href", i)
			}
			applyAttributeValue(n, i) {
				let o = this.renderer,
					s = this.el.nativeElement;
				i !== null ? o.setAttribute(s, n, i) : o.removeAttribute(s, n)
			}
			get urlTree() {
				return this.commands === null ? null : this.router.createUrlTree(this.commands, {
					relativeTo: this.relativeTo !== void 0 ? this.relativeTo : this.route,
					queryParams: this.queryParams,
					fragment: this.fragment,
					queryParamsHandling: this.queryParamsHandling,
					preserveFragment: this.preserveFragment
				})
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(it), $(Lt), gu("tabindex"), $(ht), $(Se), $(vt))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "routerLink", ""]
			],
			hostVars: 1,
			hostBindings: function(i, o) {
				i & 1 && Te("click", function(a) {
					return o.onClick(a.button, a.ctrlKey, a.shiftKey, a.altKey, a.metaKey)
				}), i & 2 && So("target", o.target)
			},
			inputs: {
				target: "target",
				queryParams: "queryParams",
				fragment: "fragment",
				queryParamsHandling: "queryParamsHandling",
				state: "state",
				info: "info",
				relativeTo: "relativeTo",
				preserveFragment: [le.HasDecoratorInputTransform, "preserveFragment", "preserveFragment", Bn],
				skipLocationChange: [le.HasDecoratorInputTransform, "skipLocationChange", "skipLocationChange", Bn],
				replaceUrl: [le.HasDecoratorInputTransform, "replaceUrl", "replaceUrl", Bn],
				routerLink: "routerLink"
			},
			standalone: !0,
			features: [Pu, xt]
		});
		let e = t;
		return e
	})(),
	qp = (() => {
		let t = class t {
			get isActive() {
				return this._isActive
			}
			constructor(n, i, o, s, a) {
				this.router = n, this.element = i, this.renderer = o, this.cdr = s, this.link = a, this.classes = [], this._isActive = !1, this.routerLinkActiveOptions = {
					exact: !1
				}, this.isActiveChange = new ie, this.routerEventsSubscription = n.events.subscribe(u => {
					u instanceof Ge && this.update()
				})
			}
			ngAfterContentInit() {
				b(this.links.changes, b(null)).pipe(wt()).subscribe(n => {
					this.update(), this.subscribeToEachLinkOnChanges()
				})
			}
			subscribeToEachLinkOnChanges() {
				this.linkInputChangesSubscription?.unsubscribe();
				let n = [...this.links.toArray(), this.link].filter(i => !!i).map(i => i.onChanges);
				this.linkInputChangesSubscription = G(n).pipe(wt()).subscribe(i => {
					this._isActive !== this.isLinkActive(this.router)(i) && this.update()
				})
			}
			set routerLinkActive(n) {
				let i = Array.isArray(n) ? n : n.split(" ");
				this.classes = i.filter(o => !!o)
			}
			ngOnChanges(n) {
				this.update()
			}
			ngOnDestroy() {
				this.routerEventsSubscription.unsubscribe(), this.linkInputChangesSubscription?.unsubscribe()
			}
			update() {
				!this.links || !this.router.navigated || queueMicrotask(() => {
					let n = this.hasActiveLinks();
					this.classes.forEach(i => {
						n ? this.renderer.addClass(this.element.nativeElement, i) : this.renderer.removeClass(this.element.nativeElement, i)
					}), n && this.ariaCurrentWhenActive !== void 0 ? this.renderer.setAttribute(this.element.nativeElement, "aria-current", this.ariaCurrentWhenActive.toString()) : this.renderer.removeAttribute(this.element.nativeElement, "aria-current"), this._isActive !== n && (this._isActive = n, this.cdr.markForCheck(), this.isActiveChange.emit(n))
				})
			}
			isLinkActive(n) {
				let i = sb(this.routerLinkActiveOptions) ? this.routerLinkActiveOptions : this.routerLinkActiveOptions.exact || !1;
				return o => {
					let s = o.urlTree;
					return s ? n.isActive(s, i) : !1
				}
			}
			hasActiveLinks() {
				let n = this.isLinkActive(this.router);
				return this.link && n(this.link) || this.links.some(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(it), $(Se), $(ht), $(an), $(is, 8))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "routerLinkActive", ""]
			],
			contentQueries: function(i, o, s) {
				if (i & 1 && wh(s, is, 5), i & 2) {
					let a;
					Ch(a = Eh()) && (o.links = a)
				}
			},
			inputs: {
				routerLinkActiveOptions: "routerLinkActiveOptions",
				ariaCurrentWhenActive: "ariaCurrentWhenActive",
				routerLinkActive: "routerLinkActive"
			},
			outputs: {
				isActiveChange: "isActiveChange"
			},
			exportAs: ["routerLinkActive"],
			standalone: !0,
			features: [xt]
		});
		let e = t;
		return e
	})();

function sb(e) {
	return !!e.paths
}
var os = class {};
var ab = (() => {
		let t = class t {
			constructor(n, i, o, s, a) {
				this.router = n, this.injector = o, this.preloadingStrategy = s, this.loader = a
			}
			setUpPreloading() {
				this.subscription = this.router.events.pipe(ve(n => n instanceof Ge), st(() => this.preload())).subscribe(() => {})
			}
			preload() {
				return this.processRoutes(this.injector, this.router.config)
			}
			ngOnDestroy() {
				this.subscription && this.subscription.unsubscribe()
			}
			processRoutes(n, i) {
				let o = [];
				for (let s of i) {
					s.providers && !s._injector && (s._injector = _o(s.providers, n, `Route: ${s.path}`));
					let a = s._injector ?? n,
						u = s._loadedInjector ?? a;
					(s.loadChildren && !s._loadedRoutes && s.canLoad === void 0 || s.loadComponent && !s._loadedComponent) && o.push(this.preloadConfig(a, s)), (s.children || s._loadedRoutes) && o.push(this.processRoutes(u, s.children ?? s._loadedRoutes))
				}
				return G(o).pipe(wt())
			}
			preloadConfig(n, i) {
				return this.preloadingStrategy.preload(i, () => {
					let o;
					i.loadChildren && i.canLoad === void 0 ? o = this.loader.loadChildren(n, i) : o = b(null);
					let s = o.pipe(K(a => a === null ? b(void 0) : (i._loadedRoutes = a.routes, i._loadedInjector = a.injector, this.processRoutes(a.injector ?? n, a.routes))));
					if (i.loadComponent && !i._loadedComponent) {
						let a = this.loader.loadComponent(i);
						return G([s, a]).pipe(wt())
					} else return s
				})
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(it), M(Ro), M(ge), M(os), M(Bc))
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac,
			providedIn: "root"
		});
		let e = t;
		return e
	})(),
	Wp = new w(""),
	ub = (() => {
		let t = class t {
			constructor(n, i, o, s, a = {}) {
				this.urlSerializer = n, this.transitions = i, this.viewportScroller = o, this.zone = s, this.options = a, this.lastId = 0, this.lastSource = "imperative", this.restoredId = 0, this.store = {}, a.scrollPositionRestoration ||= "disabled", a.anchorScrolling ||= "disabled"
			}
			init() {
				this.options.scrollPositionRestoration !== "disabled" && this.viewportScroller.setHistoryScrollRestoration("manual"), this.routerEventsSubscription = this.createScrollEvents(), this.scrollEventsSubscription = this.consumeScrollEvents()
			}
			createScrollEvents() {
				return this.transitions.events.subscribe(n => {
					n instanceof Jn ? (this.store[this.lastId] = this.viewportScroller.getScrollPosition(), this.lastSource = n.navigationTrigger, this.restoredId = n.restoredState ? n.restoredState.navigationId : 0) : n instanceof Ge ? (this.lastId = n.id, this.scheduleScrollEvent(n, this.urlSerializer.parse(n.urlAfterRedirects).fragment)) : n instanceof kt && n.code === Qo.IgnoredSameUrlNavigation && (this.lastSource = void 0, this.restoredId = 0, this.scheduleScrollEvent(n, this.urlSerializer.parse(n.url).fragment))
				})
			}
			consumeScrollEvents() {
				return this.transitions.events.subscribe(n => {
					n instanceof Jo && (n.position ? this.options.scrollPositionRestoration === "top" ? this.viewportScroller.scrollToPosition([0, 0]) : this.options.scrollPositionRestoration === "enabled" && this.viewportScroller.scrollToPosition(n.position) : n.anchor && this.options.anchorScrolling === "enabled" ? this.viewportScroller.scrollToAnchor(n.anchor) : this.options.scrollPositionRestoration !== "disabled" && this.viewportScroller.scrollToPosition([0, 0]))
				})
			}
			scheduleScrollEvent(n, i) {
				this.zone.runOutsideAngular(() => {
					setTimeout(() => {
						this.zone.run(() => {
							this.transitions.events.next(new Jo(n, this.lastSource === "popstate" ? this.store[this.restoredId] : null, i))
						})
					}, 0)
				})
			}
			ngOnDestroy() {
				this.routerEventsSubscription?.unsubscribe(), this.scrollEventsSubscription?.unsubscribe()
			}
		};
		t.\u0275fac = function(i) {
			Hf()
		}, t.\u0275prov = C({
			token: t,
			factory: t.\u0275fac
		});
		let e = t;
		return e
	})();

function Zp(e, ...t) {
	return kn([{
			provide: Kr,
			multi: !0,
			useValue: e
		},
		[], {
			provide: Lt,
			useFactory: Yp,
			deps: [it]
		}, {
			provide: Ar,
			multi: !0,
			useFactory: Qp
		},
		t.map(r => r.\u0275providers)
	])
}

function Yp(e) {
	return e.routerState.root
}

function ii(e, t) {
	return {
		\u0275kind: e,
		\u0275providers: t
	}
}

function Qp() {
	let e = p(ft);
	return t => {
		let r = e.get($n);
		if (t !== r.components[0]) return;
		let n = e.get(it),
			i = e.get(Kp);
		e.get(Gc) === 1 && n.initialNavigation(), e.get(Jp, null, O.Optional)?.setUpPreloading(), e.get(Wp, null, O.Optional)?.init(), n.resetRootComponentType(r.componentTypes[0]), i.closed || (i.next(), i.complete(), i.unsubscribe())
	}
}
var Kp = new w("", {
		factory: () => new X
	}),
	Gc = new w("", {
		providedIn: "root",
		factory: () => 1
	});

function cb() {
	return ii(2, [{
		provide: Gc,
		useValue: 0
	}, {
		provide: No,
		multi: !0,
		deps: [ft],
		useFactory: t => {
			let r = t.get(kh, Promise.resolve());
			return () => r.then(() => new Promise(n => {
				let i = t.get(it),
					o = t.get(Kp);
				Gp(i, () => {
					n(!0)
				}), t.get(zc).afterPreactivation = () => (n(!0), o.closed ? b(void 0) : o), i.initialNavigation()
			}))
		}
	}])
}

function lb() {
	return ii(3, [{
		provide: No,
		multi: !0,
		useFactory: () => {
			let t = p(it);
			return () => {
				t.setUpLocationChangeListener()
			}
		}
	}, {
		provide: Gc,
		useValue: 2
	}])
}
var Jp = new w("");

function db(e) {
	return ii(0, [{
		provide: Jp,
		useExisting: ab
	}, {
		provide: os,
		useExisting: e
	}])
}

function fb() {
	return ii(8, [dp, {
		provide: ss,
		useExisting: dp
	}])
}

function hb(e) {
	let t = [{
		provide: Bp,
		useValue: YE
	}, {
		provide: Hp,
		useValue: g({
			skipNextTransition: !!e?.skipInitialTransition
		}, e)
	}];
	return ii(9, t)
}
var hp = new w("ROUTER_FORROOT_GUARD"),
	pb = [zn, {
		provide: Xr,
		useClass: Hr
	}, it, ei, {
		provide: Lt,
		useFactory: Yp,
		deps: [it]
	}, Bc, []],
	us = (() => {
		let t = class t {
			constructor(n) {}
			static forRoot(n, i) {
				return {
					ngModule: t,
					providers: [pb, [], {
						provide: Kr,
						multi: !0,
						useValue: n
					}, {
						provide: hp,
						useFactory: yb,
						deps: [
							[it, new Qa, new Id]
						]
					}, {
						provide: ri,
						useValue: i || {}
					}, i?.useHash ? mb() : vb(), gb(), i?.preloadingStrategy ? db(i.preloadingStrategy).\u0275providers : [], i?.initialNavigation ? Db(i) : [], i?.bindToComponentInputs ? fb().\u0275providers : [], i?.enableViewTransitions ? hb().\u0275providers : [], wb()]
				}
			}
			static forChild(n) {
				return {
					ngModule: t,
					providers: [{
						provide: Kr,
						multi: !0,
						useValue: n
					}]
				}
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)(M(hp, 8))
		}, t.\u0275mod = et({
			type: t
		}), t.\u0275inj = Xe({});
		let e = t;
		return e
	})();

function gb() {
	return {
		provide: Wp,
		useFactory: () => {
			let e = p(Uh),
				t = p(Z),
				r = p(ri),
				n = p(zc),
				i = p(Xr);
			return r.scrollOffset && e.setOffset(r.scrollOffset), new ub(i, n, e, t, r)
		}
	}
}

function mb() {
	return {
		provide: vt,
		useClass: Vh
	}
}

function vb() {
	return {
		provide: vt,
		useClass: zu
	}
}

function yb(e) {
	return "guarded"
}

function Db(e) {
	return [e.initialNavigation === "disabled" ? lb().\u0275providers : [], e.initialNavigation === "enabledBlocking" ? cb().\u0275providers : []]
}
var pp = new w("");

function wb() {
	return [{
		provide: pp,
		useFactory: Qp
	}, {
		provide: Ar,
		multi: !0,
		useExisting: pp
	}]
}
var qc = {
	wsUrl: "ws://localhost:8765",
	defaultTimeout: 1e3,
	errorTimeout: 5e3,
	braceletApi: "https://mobileappstarter.com/dashboards/kidzquad/apitest/user/scan_bracelet"
};
var jt = (() => {
	let t = class t {
		constructor() {
			this._wsActive = new W(!1), this._piId = new W(""), this._errors = new W([]), this._data = new W(null), this._pendingData = new W(null), this._wsUrl = new W(qc.wsUrl), this._wsRetryCounter = 0
		}
		set wsUrl(n) {
			this._wsUrl.next(n)
		}
		get data() {
			return this._data.asObservable()
		}
		set updateData(n) {
			this._data.next(n)
		}
		get pendingData() {
			return this._pendingData.asObservable()
		}
		set updatePendingData(n) {
			this._pendingData.next(n)
		}
		get wsState() {
			return this._wsActive.asObservable()
		}
		set updateWsState(n) {
			this._wsActive.next(n)
		}
		get scannerId() {
			return this._piId.asObservable()
		}
		set updateScannerId(n) {
			this._piId.next(n)
		}
		get errors() {
			return this._errors.asObservable()
		}
		addError(n) {
			this._errors.next([...this._errors.value, n]), setTimeout(() => {
				this.removeError(this._errors.value.indexOf(n))
			}, qc.errorTimeout)
		}
		removeError(n) {
			let i = this._errors.value;
			i.splice(n, 1), this._errors.next(i)
		}
		connect() {
			this._wsUrl.subscribe(n => {
				console.log("connect", "url", n);
				let i = new WebSocket(n);
				i.onopen = () => {
					this.updateWsState = !0
				}, i.onmessage = o => {
					this._wsActive.value || (this.updateWsState = !0), this.updateData = JSON.parse(o.data), this.updateScannerId = JSON.parse(o.data).scanner_id
				}, i.onerror = o => {
					"error" in o ? console.log(`WebSocket error: ${o.error}`) : (console.log(`WebSocket event error: ${o}`), this._wsActive.value === !1 && this._wsRetryCounter < 50 && (this.connect(), this._wsRetryCounter++))
				}, i.onclose = () => {
					this._wsActive.value && (this.updateWsState = !1, console.log("Websocket closed"), this.connect())
				}
			})
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275prov = C({
		token: t,
		factory: t.\u0275fac,
		providedIn: "root"
	});
	let e = t;
	return e
})();
var og = (() => {
		let t = class t {
			constructor(n, i) {
				this._renderer = n, this._elementRef = i, this.onChange = o => {}, this.onTouched = () => {}
			}
			setProperty(n, i) {
				this._renderer.setProperty(this._elementRef.nativeElement, n, i)
			}
			registerOnTouched(n) {
				this.onTouched = n
			}
			registerOnChange(n) {
				this.onChange = n
			}
			setDisabledState(n) {
				this.setProperty("disabled", n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(ht), $(Se))
		}, t.\u0275dir = we({
			type: t
		});
		let e = t;
		return e
	})(),
	Eb = (() => {
		let t = class t extends og {};
		t.\u0275fac = (() => {
			let n;
			return function(o) {
				return (n || (n = Sr(t)))(o || t)
			}
		})(), t.\u0275dir = we({
			type: t,
			features: [tn]
		});
		let e = t;
		return e
	})(),
	sg = new w("");
var bb = {
	provide: sg,
	useExisting: Er(() => ps),
	multi: !0
};

function Ib() {
	let e = mt() ? mt().getUserAgent() : "";
	return /android (\d+)/.test(e.toLowerCase())
}
var Mb = new w(""),
	ps = (() => {
		let t = class t extends og {
			constructor(n, i, o) {
				super(n, i), this._compositionMode = o, this._composing = !1, this._compositionMode == null && (this._compositionMode = !Ib())
			}
			writeValue(n) {
				let i = n ?? "";
				this.setProperty("value", i)
			}
			_handleInput(n) {
				(!this._compositionMode || this._compositionMode && !this._composing) && this.onChange(n)
			}
			_compositionStart() {
				this._composing = !0
			}
			_compositionEnd(n) {
				this._composing = !1, this._compositionMode && this.onChange(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(ht), $(Se), $(Mb, 8))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["input", "formControlName", "", 3, "type", "checkbox"],
				["textarea", "formControlName", ""],
				["input", "formControl", "", 3, "type", "checkbox"],
				["textarea", "formControl", ""],
				["input", "ngModel", "", 3, "type", "checkbox"],
				["textarea", "ngModel", ""],
				["", "ngDefaultControl", ""]
			],
			hostBindings: function(i, o) {
				i & 1 && Te("input", function(a) {
					return o._handleInput(a.target.value)
				})("blur", function() {
					return o.onTouched()
				})("compositionstart", function() {
					return o._compositionStart()
				})("compositionend", function(a) {
					return o._compositionEnd(a.target.value)
				})
			},
			features: [ku([bb]), tn]
		});
		let e = t;
		return e
	})();
var _b = new w(""),
	Sb = new w("");

function ag(e) {
	return e != null
}

function ug(e) {
	return sn(e) ? G(e) : e
}

function cg(e) {
	let t = {};
	return e.forEach(r => {
		t = r != null ? g(g({}, t), r) : t
	}), Object.keys(t).length === 0 ? null : t
}

function lg(e, t) {
	return t.map(r => r(e))
}

function Tb(e) {
	return !e.validate
}

function dg(e) {
	return e.map(t => Tb(t) ? t : r => t.validate(r))
}

function xb(e) {
	if (!e) return null;
	let t = e.filter(ag);
	return t.length == 0 ? null : function(r) {
		return cg(lg(r, t))
	}
}

function fg(e) {
	return e != null ? xb(dg(e)) : null
}

function Ab(e) {
	if (!e) return null;
	let t = e.filter(ag);
	return t.length == 0 ? null : function(r) {
		let n = lg(r, t).map(ug);
		return Rs(n).pipe(A(cg))
	}
}

function hg(e) {
	return e != null ? Ab(dg(e)) : null
}

function Xp(e, t) {
	return e === null ? [t] : Array.isArray(e) ? [...e, t] : [e, t]
}

function pg(e) {
	return e._rawValidators
}

function gg(e) {
	return e._rawAsyncValidators
}

function Wc(e) {
	return e ? Array.isArray(e) ? e : [e] : []
}

function ls(e, t) {
	return Array.isArray(e) ? e.includes(t) : e === t
}

function eg(e, t) {
	let r = Wc(t);
	return Wc(e).forEach(i => {
		ls(r, i) || r.push(i)
	}), r
}

function tg(e, t) {
	return Wc(t).filter(r => !ls(e, r))
}
var ds = class {
		constructor() {
			this._rawValidators = [], this._rawAsyncValidators = [], this._onDestroyCallbacks = []
		}
		get value() {
			return this.control ? this.control.value : null
		}
		get valid() {
			return this.control ? this.control.valid : null
		}
		get invalid() {
			return this.control ? this.control.invalid : null
		}
		get pending() {
			return this.control ? this.control.pending : null
		}
		get disabled() {
			return this.control ? this.control.disabled : null
		}
		get enabled() {
			return this.control ? this.control.enabled : null
		}
		get errors() {
			return this.control ? this.control.errors : null
		}
		get pristine() {
			return this.control ? this.control.pristine : null
		}
		get dirty() {
			return this.control ? this.control.dirty : null
		}
		get touched() {
			return this.control ? this.control.touched : null
		}
		get status() {
			return this.control ? this.control.status : null
		}
		get untouched() {
			return this.control ? this.control.untouched : null
		}
		get statusChanges() {
			return this.control ? this.control.statusChanges : null
		}
		get valueChanges() {
			return this.control ? this.control.valueChanges : null
		}
		get path() {
			return null
		}
		_setValidators(t) {
			this._rawValidators = t || [], this._composedValidatorFn = fg(this._rawValidators)
		}
		_setAsyncValidators(t) {
			this._rawAsyncValidators = t || [], this._composedAsyncValidatorFn = hg(this._rawAsyncValidators)
		}
		get validator() {
			return this._composedValidatorFn || null
		}
		get asyncValidator() {
			return this._composedAsyncValidatorFn || null
		}
		_registerOnDestroy(t) {
			this._onDestroyCallbacks.push(t)
		}
		_invokeOnDestroyCallbacks() {
			this._onDestroyCallbacks.forEach(t => t()), this._onDestroyCallbacks = []
		}
		reset(t = void 0) {
			this.control && this.control.reset(t)
		}
		hasError(t, r) {
			return this.control ? this.control.hasError(t, r) : !1
		}
		getError(t, r) {
			return this.control ? this.control.getError(t, r) : null
		}
	},
	Zc = class extends ds {
		get formDirective() {
			return null
		}
		get path() {
			return null
		}
	},
	ai = class extends ds {
		constructor() {
			super(...arguments), this._parent = null, this.name = null, this.valueAccessor = null
		}
	},
	fs = class {
		constructor(t) {
			this._cd = t
		}
		get isTouched() {
			return !!this._cd?.control?.touched
		}
		get isUntouched() {
			return !!this._cd?.control?.untouched
		}
		get isPristine() {
			return !!this._cd?.control?.pristine
		}
		get isDirty() {
			return !!this._cd?.control?.dirty
		}
		get isValid() {
			return !!this._cd?.control?.valid
		}
		get isInvalid() {
			return !!this._cd?.control?.invalid
		}
		get isPending() {
			return !!this._cd?.control?.pending
		}
		get isSubmitted() {
			return !!this._cd?.submitted
		}
	},
	Nb = {
		"[class.ng-untouched]": "isUntouched",
		"[class.ng-touched]": "isTouched",
		"[class.ng-pristine]": "isPristine",
		"[class.ng-dirty]": "isDirty",
		"[class.ng-valid]": "isValid",
		"[class.ng-invalid]": "isInvalid",
		"[class.ng-pending]": "isPending"
	},
	eR = z(g({}, Nb), {
		"[class.ng-submitted]": "isSubmitted"
	}),
	mg = (() => {
		let t = class t extends fs {
			constructor(n) {
				super(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(ai, 2))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "formControlName", ""],
				["", "ngModel", ""],
				["", "formControl", ""]
			],
			hostVars: 14,
			hostBindings: function(i, o) {
				i & 2 && To("ng-untouched", o.isUntouched)("ng-touched", o.isTouched)("ng-pristine", o.isPristine)("ng-dirty", o.isDirty)("ng-valid", o.isValid)("ng-invalid", o.isInvalid)("ng-pending", o.isPending)
			},
			features: [tn]
		});
		let e = t;
		return e
	})(),
	vg = (() => {
		let t = class t extends fs {
			constructor(n) {
				super(n)
			}
		};
		t.\u0275fac = function(i) {
			return new(i || t)($(Zc, 10))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "formGroupName", ""],
				["", "formArrayName", ""],
				["", "ngModelGroup", ""],
				["", "formGroup", ""],
				["form", 3, "ngNoForm", ""],
				["", "ngForm", ""]
			],
			hostVars: 16,
			hostBindings: function(i, o) {
				i & 2 && To("ng-untouched", o.isUntouched)("ng-touched", o.isTouched)("ng-pristine", o.isPristine)("ng-dirty", o.isDirty)("ng-valid", o.isValid)("ng-invalid", o.isInvalid)("ng-pending", o.isPending)("ng-submitted", o.isSubmitted)
			},
			features: [tn]
		});
		let e = t;
		return e
	})();
var oi = "VALID",
	cs = "INVALID",
	tr = "PENDING",
	si = "DISABLED";

function Rb(e) {
	return (gs(e) ? e.validators : e) || null
}

function Ob(e) {
	return Array.isArray(e) ? fg(e) : e || null
}

function Fb(e, t) {
	return (gs(t) ? t.asyncValidators : e) || null
}

function Pb(e) {
	return Array.isArray(e) ? hg(e) : e || null
}

function gs(e) {
	return e != null && !Array.isArray(e) && typeof e == "object"
}
var Yc = class {
	constructor(t, r) {
		this._pendingDirty = !1, this._hasOwnPendingAsyncValidator = !1, this._pendingTouched = !1, this._onCollectionChange = () => {}, this._parent = null, this.pristine = !0, this.touched = !1, this._onDisabledChange = [], this._assignValidators(t), this._assignAsyncValidators(r)
	}
	get validator() {
		return this._composedValidatorFn
	}
	set validator(t) {
		this._rawValidators = this._composedValidatorFn = t
	}
	get asyncValidator() {
		return this._composedAsyncValidatorFn
	}
	set asyncValidator(t) {
		this._rawAsyncValidators = this._composedAsyncValidatorFn = t
	}
	get parent() {
		return this._parent
	}
	get valid() {
		return this.status === oi
	}
	get invalid() {
		return this.status === cs
	}
	get pending() {
		return this.status == tr
	}
	get disabled() {
		return this.status === si
	}
	get enabled() {
		return this.status !== si
	}
	get dirty() {
		return !this.pristine
	}
	get untouched() {
		return !this.touched
	}
	get updateOn() {
		return this._updateOn ? this._updateOn : this.parent ? this.parent.updateOn : "change"
	}
	setValidators(t) {
		this._assignValidators(t)
	}
	setAsyncValidators(t) {
		this._assignAsyncValidators(t)
	}
	addValidators(t) {
		this.setValidators(eg(t, this._rawValidators))
	}
	addAsyncValidators(t) {
		this.setAsyncValidators(eg(t, this._rawAsyncValidators))
	}
	removeValidators(t) {
		this.setValidators(tg(t, this._rawValidators))
	}
	removeAsyncValidators(t) {
		this.setAsyncValidators(tg(t, this._rawAsyncValidators))
	}
	hasValidator(t) {
		return ls(this._rawValidators, t)
	}
	hasAsyncValidator(t) {
		return ls(this._rawAsyncValidators, t)
	}
	clearValidators() {
		this.validator = null
	}
	clearAsyncValidators() {
		this.asyncValidator = null
	}
	markAsTouched(t = {}) {
		this.touched = !0, this._parent && !t.onlySelf && this._parent.markAsTouched(t)
	}
	markAllAsTouched() {
		this.markAsTouched({
			onlySelf: !0
		}), this._forEachChild(t => t.markAllAsTouched())
	}
	markAsUntouched(t = {}) {
		this.touched = !1, this._pendingTouched = !1, this._forEachChild(r => {
			r.markAsUntouched({
				onlySelf: !0
			})
		}), this._parent && !t.onlySelf && this._parent._updateTouched(t)
	}
	markAsDirty(t = {}) {
		this.pristine = !1, this._parent && !t.onlySelf && this._parent.markAsDirty(t)
	}
	markAsPristine(t = {}) {
		this.pristine = !0, this._pendingDirty = !1, this._forEachChild(r => {
			r.markAsPristine({
				onlySelf: !0
			})
		}), this._parent && !t.onlySelf && this._parent._updatePristine(t)
	}
	markAsPending(t = {}) {
		this.status = tr, t.emitEvent !== !1 && this.statusChanges.emit(this.status), this._parent && !t.onlySelf && this._parent.markAsPending(t)
	}
	disable(t = {}) {
		let r = this._parentMarkedDirty(t.onlySelf);
		this.status = si, this.errors = null, this._forEachChild(n => {
			n.disable(z(g({}, t), {
				onlySelf: !0
			}))
		}), this._updateValue(), t.emitEvent !== !1 && (this.valueChanges.emit(this.value), this.statusChanges.emit(this.status)), this._updateAncestors(z(g({}, t), {
			skipPristineCheck: r
		})), this._onDisabledChange.forEach(n => n(!0))
	}
	enable(t = {}) {
		let r = this._parentMarkedDirty(t.onlySelf);
		this.status = oi, this._forEachChild(n => {
			n.enable(z(g({}, t), {
				onlySelf: !0
			}))
		}), this.updateValueAndValidity({
			onlySelf: !0,
			emitEvent: t.emitEvent
		}), this._updateAncestors(z(g({}, t), {
			skipPristineCheck: r
		})), this._onDisabledChange.forEach(n => n(!1))
	}
	_updateAncestors(t) {
		this._parent && !t.onlySelf && (this._parent.updateValueAndValidity(t), t.skipPristineCheck || this._parent._updatePristine(), this._parent._updateTouched())
	}
	setParent(t) {
		this._parent = t
	}
	getRawValue() {
		return this.value
	}
	updateValueAndValidity(t = {}) {
		this._setInitialStatus(), this._updateValue(), this.enabled && (this._cancelExistingSubscription(), this.errors = this._runValidator(), this.status = this._calculateStatus(), (this.status === oi || this.status === tr) && this._runAsyncValidator(t.emitEvent)), t.emitEvent !== !1 && (this.valueChanges.emit(this.value), this.statusChanges.emit(this.status)), this._parent && !t.onlySelf && this._parent.updateValueAndValidity(t)
	}
	_updateTreeValidity(t = {
		emitEvent: !0
	}) {
		this._forEachChild(r => r._updateTreeValidity(t)), this.updateValueAndValidity({
			onlySelf: !0,
			emitEvent: t.emitEvent
		})
	}
	_setInitialStatus() {
		this.status = this._allControlsDisabled() ? si : oi
	}
	_runValidator() {
		return this.validator ? this.validator(this) : null
	}
	_runAsyncValidator(t) {
		if (this.asyncValidator) {
			this.status = tr, this._hasOwnPendingAsyncValidator = !0;
			let r = ug(this.asyncValidator(this));
			this._asyncValidationSubscription = r.subscribe(n => {
				this._hasOwnPendingAsyncValidator = !1, this.setErrors(n, {
					emitEvent: t
				})
			})
		}
	}
	_cancelExistingSubscription() {
		this._asyncValidationSubscription && (this._asyncValidationSubscription.unsubscribe(), this._hasOwnPendingAsyncValidator = !1)
	}
	setErrors(t, r = {}) {
		this.errors = t, this._updateControlsErrors(r.emitEvent !== !1)
	}
	get(t) {
		let r = t;
		return r == null || (Array.isArray(r) || (r = r.split(".")), r.length === 0) ? null : r.reduce((n, i) => n && n._find(i), this)
	}
	getError(t, r) {
		let n = r ? this.get(r) : this;
		return n && n.errors ? n.errors[t] : null
	}
	hasError(t, r) {
		return !!this.getError(t, r)
	}
	get root() {
		let t = this;
		for (; t._parent;) t = t._parent;
		return t
	}
	_updateControlsErrors(t) {
		this.status = this._calculateStatus(), t && this.statusChanges.emit(this.status), this._parent && this._parent._updateControlsErrors(t)
	}
	_initObservables() {
		this.valueChanges = new ie, this.statusChanges = new ie
	}
	_calculateStatus() {
		return this._allControlsDisabled() ? si : this.errors ? cs : this._hasOwnPendingAsyncValidator || this._anyControlsHaveStatus(tr) ? tr : this._anyControlsHaveStatus(cs) ? cs : oi
	}
	_anyControlsHaveStatus(t) {
		return this._anyControls(r => r.status === t)
	}
	_anyControlsDirty() {
		return this._anyControls(t => t.dirty)
	}
	_anyControlsTouched() {
		return this._anyControls(t => t.touched)
	}
	_updatePristine(t = {}) {
		this.pristine = !this._anyControlsDirty(), this._parent && !t.onlySelf && this._parent._updatePristine(t)
	}
	_updateTouched(t = {}) {
		this.touched = this._anyControlsTouched(), this._parent && !t.onlySelf && this._parent._updateTouched(t)
	}
	_registerOnCollectionChange(t) {
		this._onCollectionChange = t
	}
	_setUpdateStrategy(t) {
		gs(t) && t.updateOn != null && (this._updateOn = t.updateOn)
	}
	_parentMarkedDirty(t) {
		let r = this._parent && this._parent.dirty;
		return !t && !!r && !this._parent._anyControlsDirty()
	}
	_find(t) {
		return null
	}
	_assignValidators(t) {
		this._rawValidators = Array.isArray(t) ? t.slice() : t, this._composedValidatorFn = Ob(this._rawValidators)
	}
	_assignAsyncValidators(t) {
		this._rawAsyncValidators = Array.isArray(t) ? t.slice() : t, this._composedAsyncValidatorFn = Pb(this._rawAsyncValidators)
	}
};
var yg = new w("CallSetDisabledState", {
		providedIn: "root",
		factory: () => Qc
	}),
	Qc = "always";

function kb(e, t, r = Qc) {
	Vb(e, t), t.valueAccessor.writeValue(e.value), (e.disabled || r === "always") && t.valueAccessor.setDisabledState?.(e.disabled), Ub(e, t), Bb(e, t), $b(e, t), Lb(e, t)
}

function ng(e, t, r = !0) {
	let n = () => {};
	t.valueAccessor && (t.valueAccessor.registerOnChange(n), t.valueAccessor.registerOnTouched(n)), jb(e, t), e && (t._invokeOnDestroyCallbacks(), e._registerOnCollectionChange(() => {}))
}

function hs(e, t) {
	e.forEach(r => {
		r.registerOnValidatorChange && r.registerOnValidatorChange(t)
	})
}

function Lb(e, t) {
	if (t.valueAccessor.setDisabledState) {
		let r = n => {
			t.valueAccessor.setDisabledState(n)
		};
		e.registerOnDisabledChange(r), t._registerOnDestroy(() => {
			e._unregisterOnDisabledChange(r)
		})
	}
}

function Vb(e, t) {
	let r = pg(e);
	t.validator !== null ? e.setValidators(Xp(r, t.validator)) : typeof r == "function" && e.setValidators([r]);
	let n = gg(e);
	t.asyncValidator !== null ? e.setAsyncValidators(Xp(n, t.asyncValidator)) : typeof n == "function" && e.setAsyncValidators([n]);
	let i = () => e.updateValueAndValidity();
	hs(t._rawValidators, i), hs(t._rawAsyncValidators, i)
}

function jb(e, t) {
	let r = !1;
	if (e !== null) {
		if (t.validator !== null) {
			let i = pg(e);
			if (Array.isArray(i) && i.length > 0) {
				let o = i.filter(s => s !== t.validator);
				o.length !== i.length && (r = !0, e.setValidators(o))
			}
		}
		if (t.asyncValidator !== null) {
			let i = gg(e);
			if (Array.isArray(i) && i.length > 0) {
				let o = i.filter(s => s !== t.asyncValidator);
				o.length !== i.length && (r = !0, e.setAsyncValidators(o))
			}
		}
	}
	let n = () => {};
	return hs(t._rawValidators, n), hs(t._rawAsyncValidators, n), r
}

function Ub(e, t) {
	t.valueAccessor.registerOnChange(r => {
		e._pendingValue = r, e._pendingChange = !0, e._pendingDirty = !0, e.updateOn === "change" && Dg(e, t)
	})
}

function $b(e, t) {
	t.valueAccessor.registerOnTouched(() => {
		e._pendingTouched = !0, e.updateOn === "blur" && e._pendingChange && Dg(e, t), e.updateOn !== "submit" && e.markAsTouched()
	})
}

function Dg(e, t) {
	e._pendingDirty && e.markAsDirty(), e.setValue(e._pendingValue, {
		emitModelToViewChange: !1
	}), t.viewToModelUpdate(e._pendingValue), e._pendingChange = !1
}

function Bb(e, t) {
	let r = (n, i) => {
		t.valueAccessor.writeValue(n), i && t.viewToModelUpdate(n)
	};
	e.registerOnChange(r), t._registerOnDestroy(() => {
		e._unregisterOnChange(r)
	})
}

function Hb(e, t) {
	if (!e.hasOwnProperty("model")) return !1;
	let r = e.model;
	return r.isFirstChange() ? !0 : !Object.is(t, r.currentValue)
}

function zb(e) {
	return Object.getPrototypeOf(e.constructor) === Eb
}

function Gb(e, t) {
	if (!t) return null;
	Array.isArray(t);
	let r, n, i;
	return t.forEach(o => {
		o.constructor === ps ? r = o : zb(o) ? n = o : i = o
	}), i || n || r || null
}

function rg(e, t) {
	let r = e.indexOf(t);
	r > -1 && e.splice(r, 1)
}

function ig(e) {
	return typeof e == "object" && e !== null && Object.keys(e).length === 2 && "value" in e && "disabled" in e
}
var wg = class extends Yc {
	constructor(t = null, r, n) {
		super(Rb(r), Fb(n, r)), this.defaultValue = null, this._onChange = [], this._pendingChange = !1, this._applyFormState(t), this._setUpdateStrategy(r), this._initObservables(), this.updateValueAndValidity({
			onlySelf: !0,
			emitEvent: !!this.asyncValidator
		}), gs(r) && (r.nonNullable || r.initialValueIsDefault) && (ig(t) ? this.defaultValue = t.value : this.defaultValue = t)
	}
	setValue(t, r = {}) {
		this.value = this._pendingValue = t, this._onChange.length && r.emitModelToViewChange !== !1 && this._onChange.forEach(n => n(this.value, r.emitViewToModelChange !== !1)), this.updateValueAndValidity(r)
	}
	patchValue(t, r = {}) {
		this.setValue(t, r)
	}
	reset(t = this.defaultValue, r = {}) {
		this._applyFormState(t), this.markAsPristine(r), this.markAsUntouched(r), this.setValue(this.value, r), this._pendingChange = !1
	}
	_updateValue() {}
	_anyControls(t) {
		return !1
	}
	_allControlsDisabled() {
		return this.disabled
	}
	registerOnChange(t) {
		this._onChange.push(t)
	}
	_unregisterOnChange(t) {
		rg(this._onChange, t)
	}
	registerOnDisabledChange(t) {
		this._onDisabledChange.push(t)
	}
	_unregisterOnDisabledChange(t) {
		rg(this._onDisabledChange, t)
	}
	_forEachChild(t) {}
	_syncPendingControls() {
		return this.updateOn === "submit" && (this._pendingDirty && this.markAsDirty(), this._pendingTouched && this.markAsTouched(), this._pendingChange) ? (this.setValue(this._pendingValue, {
			onlySelf: !0,
			emitModelToViewChange: !1
		}), !0) : !1
	}
	_applyFormState(t) {
		ig(t) ? (this.value = this._pendingValue = t.value, t.disabled ? this.disable({
			onlySelf: !0,
			emitEvent: !1
		}) : this.enable({
			onlySelf: !0,
			emitEvent: !1
		})) : this.value = this._pendingValue = t
	}
};
var Cg = (() => {
	let t = class t {};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275dir = we({
		type: t,
		selectors: [
			["form", 3, "ngNoForm", "", 3, "ngNativeValidate", ""]
		],
		hostAttrs: ["novalidate", ""]
	});
	let e = t;
	return e
})();
var Eg = new w(""),
	qb = {
		provide: ai,
		useExisting: Er(() => Kc)
	},
	Kc = (() => {
		let t = class t extends ai {
			set isDisabled(n) {}
			constructor(n, i, o, s, a) {
				super(), this._ngModelWarningConfig = s, this.callSetDisabledState = a, this.update = new ie, this._ngModelWarningSent = !1, this._setValidators(n), this._setAsyncValidators(i), this.valueAccessor = Gb(this, o)
			}
			ngOnChanges(n) {
				if (this._isControlChanged(n)) {
					let i = n.form.previousValue;
					i && ng(i, this, !1), kb(this.form, this, this.callSetDisabledState), this.form.updateValueAndValidity({
						emitEvent: !1
					})
				}
				Hb(n, this.viewModel) && (this.form.setValue(this.model), this.viewModel = this.model)
			}
			ngOnDestroy() {
				this.form && ng(this.form, this, !1)
			}
			get path() {
				return []
			}
			get control() {
				return this.form
			}
			viewToModelUpdate(n) {
				this.viewModel = n, this.update.emit(n)
			}
			_isControlChanged(n) {
				return n.hasOwnProperty("form")
			}
		};
		t._ngModelWarningSentOnce = !1, t.\u0275fac = function(i) {
			return new(i || t)($(_b, 10), $(Sb, 10), $(sg, 10), $(Eg, 8), $(yg, 8))
		}, t.\u0275dir = we({
			type: t,
			selectors: [
				["", "formControl", ""]
			],
			inputs: {
				form: [le.None, "formControl", "form"],
				isDisabled: [le.None, "disabled", "isDisabled"],
				model: [le.None, "ngModel", "model"]
			},
			outputs: {
				update: "ngModelChange"
			},
			exportAs: ["ngForm"],
			features: [ku([qb]), tn, xt]
		});
		let e = t;
		return e
	})();
var Wb = (() => {
	let t = class t {};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275mod = et({
		type: t
	}), t.\u0275inj = Xe({});
	let e = t;
	return e
})();
var bg = (() => {
	let t = class t {
		static withConfig(n) {
			return {
				ngModule: t,
				providers: [{
					provide: Eg,
					useValue: n.warnOnNgModelWithFormControl ?? "always"
				}, {
					provide: yg,
					useValue: n.callSetDisabledState ?? Qc
				}]
			}
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275mod = et({
		type: t
	}), t.\u0275inj = Xe({
		imports: [Wb]
	});
	let e = t;
	return e
})();

function Yb(e, t) {
	e & 1 && (v(0, "div", 12)(1, "div", 13)(2, "strong", 14), P(3, "Connecting..."), y()()())
}

function Qb(e, t) {
	if (e & 1) {
		let r = xo();
		v(0, "form", 8)(1, "div", 9), Y(2, "input", 10), v(3, "button", 11), Te("click", function() {
			go(r);
			let i = Rt();
			return mo(i.connectScanner())
		}), P(4, " Connect "), y()()(), Me(5, Yb, 4, 0, "div", 12)
	}
	if (e & 2) {
		let r = Rt();
		j(2), te("formControl", r.scannerUrl), j(3), Pe(5, r.showConnecting ? 5 : -1)
	}
}
var Ig = (() => {
	let t = class t {
		constructor() {
			this.networkingService = p(jt), this.scannerId = "", this.scannerUrl = new wg(""), this.showInput = !1, this.showConnecting = !1
		}
		ngOnInit() {
			this.networkingService.wsState.subscribe(n => {
				this.showInput = !n, this.showConnecting = !1
			}), this.networkingService.scannerId.subscribe(n => {
				this.scannerId = n, this.showConnecting = !1
			}), this.networkingService.errors.subscribe(n => {
				this.showConnecting = !1
			})
		}
		connectScanner() {
			console.log("connectScanner", this.scannerUrl.value), this.networkingService.wsUrl = this.scannerUrl.value, this.showConnecting = !0
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-home"]
		],
		standalone: !0,
		features: [fe],
		decls: 13,
		vars: 2,
		consts: [
			[1, "relative", "isolate", "px-6", "pt-14", "lg:px-8"],
			[1, "mx-auto", "max-w-2xl", "py-32", "sm:py-48", "lg:py-56"],
			[1, "text-center"],
			[1, "text-4xl", "font-bold", "tracking-tight", "text-gray-900", "sm:text-6xl"],
			[1, "mt-6", "text-lg", "leading-8", "text-gray-600"],
			[1, "mt-10", "flex", "items-center", "justify-center", "gap-x-6"],
			[1, "rounded-md", "px-3.5", "py-2.5", "text-xl", "font-semibold", "text-primary-500", "shadow-sm"],
			[1, "rounded-md", "bg-primary-600", "px-3.5", "py-2.5", "text-xl", "font-semibold", "text-white", "shadow-sm"],
			[1, "mt-10", "max-w-md", "mx-auto"],
			[1, "relative"],
			["type", "url", "id", "default-search", "name", "scannerUrl", 1, "block", "w-full", "p-4", "text-sm", "text-gray-900", "border", "border-gray-300", "rounded-lg", "bg-gray-50", "focus:ring-primary-500", "focus:border-primary-500", 3, "formControl"],
			["type", "button", 1, "text-white", "absolute", "end-2.5", "bottom-2.5", "bg-primary-700", "hover:bg-primary-800", "focus:ring-4", "focus:outline-none", "focus:ring-primary-300", "font-medium", "rounded-lg", "text-sm", "px-4", "py-2", 3, "click"],
			[1, "w-full", "flex", "justify-center"],
			["role", "alert", 1, "mt-20", "bg-amber-100", "border", "border-red-400", "text-red-700", "px-4", "py-3", "rounded-md", "relative", "max-w-sm"],
			[1, "font-bold"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "h1", 3), P(4, " Kidsquad RFID Platform "), y(), v(5, "p", 4), P(6, " The kidsquad RFID reading & writing system "), y(), v(7, "div", 5)(8, "p", 6), P(9, " Scanner Id "), y(), v(10, "p", 7), P(11), y()(), Me(12, Qb, 6, 2), y()()()), i & 2 && (j(11), pt(" ", o.scannerId, " "), j(), Pe(12, o.showInput ? 12 : -1))
		},
		dependencies: [us, bg, Cg, ps, mg, vg, Kc]
	});
	let e = t;
	return e
})();
var Mg = (() => {
	let t = class t {
		constructor() {
			this.data = null
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-dialog"]
		],
		inputs: {
			data: "data"
		},
		standalone: !0,
		features: [fe],
		decls: 8,
		vars: 1,
		consts: [
			[1, "w-full", "flex", "justify-center"],
			["role", "alert", 1, "mt-20", "bg-green-100", "border", "border-green-400", "text-green-700", "px-4", "py-3", "rounded-md", "max-w-sm"],
			[1, "font-bold"],
			[1, "block", "sm:inline"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "div", 0)(1, "div", 1)(2, "p", 2), P(3, "Wonderful!"), y(), v(4, "p", 3), P(5), y(), v(6, "p"), P(7, "The scan was a success!"), y()()()), i & 2 && (j(5), pt("Great Job! ", o.data.data.user.name, ""))
		}
	});
	let e = t;
	return e
})();
var _g = (() => {
	let t = class t {
		constructor() {
			this.pendingMessage = ""
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-pending"]
		],
		inputs: {
			pendingMessage: "pendingMessage"
		},
		standalone: !0,
		features: [fe],
		decls: 8,
		vars: 1,
		consts: [
			[1, "w-full", "flex", "justify-center"],
			["role", "alert", 1, "mt-20", "bg-amber-100", "border", "border-red-400", "text-red-700", "px-4", "py-3", "rounded-md", "relative", "max-w-sm"],
			[1, "font-bold"],
			[1, "block", "sm:inline"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "div", 0)(1, "div", 1)(2, "strong", 2), P(3, "Received"), y(), v(4, "span", 3), P(5, "Great Job!"), y(), v(6, "p"), P(7), y()()()), i & 2 && (j(7), xr(o.pendingMessage))
		}
	});
	let e = t;
	return e
})();

function Kb(e, t) {
	if (e & 1 && (v(0, "div", 0), Y(1, "app-dialog", 2), y()), e & 2) {
		let r = Rt();
		j(), te("data", r.cloudResponse)
	}
}

function Jb(e, t) {
	e & 1 && (v(0, "div", 0), Y(1, "app-pending", 3), y()), e & 2 && (j(), te("pendingMessage", "Scan done. Checking details..."))
}

function Xb(e, t) {
	e & 1 && Y(0, "video", 1), e & 2 && te("autoplay", !0)
}

function eI(e, t) {
	if (e & 1) {
		let r = xo();
		v(0, "video", 4), Te("ended", function() {
			go(r);
			let i = Rt();
			return mo(i.vidEnded())
		}), y()
	}
	e & 2 && te("autoplay", !0)
}
var Jc = (() => {
	let t = class t {
		constructor() {
			this.networkingService = p(jt), this.data = null, this.cloudResponse = null, this.showTempMessage = !1, this.showSuccessMessage = !1, this.showSuccessVideo = !1
		}
		vidEnded() {
			console.log("vid ended"), this.data = null, this.cloudResponse = null, this.showSuccessMessage = !1, this.showSuccessVideo = !1, this.showTempMessage = !1
		}
		ngOnInit() {
			this.networkingService.connect(), this.networkingService.data.subscribe(n => {
				let i = n;
				if (i !== null) switch (this.networkingService.updateScannerId = i.scanner_id, i.status) {
					case "INITIAL_CONNECTION": {
						console.log("initial connection", i);
						break
					}
					case "INITIAL_SCAN": {
						this.showTempMessage = !0, this.showSuccessMessage = !1, this.showSuccessVideo = !1;
						break
					}
					case "TOO_SOON": {
						this.showTempMessage = !1, console.log("too soon", i), this.networkingService.addError("You must wait at least 5 seconds before scanning again");
						break
					}
					case "SCAN_COMPLETE": {
						this.showTempMessage = !1, console.log("scan complete", i);
						let o = JSON.parse(i.response),
							s = JSON.parse(o);
						console.log(s.Result, "parsedData"), s.Result === 0 && (this.showSuccessVideo = !0, this.networkingService.addError(`${s.Message}`)), s.Result === 1 && (console.log(s.data, "parsedData"), this.cloudResponse = s, this.showSuccessMessage = !0, this.showSuccessVideo = !0);
						break
					}
					case "DISCONNECTED": {
						this.showTempMessage = !1, console.log("disconnected", i), this.networkingService.addError(`Scanner ${i.scanner_id} has disconnected`);
						break
					}
				}
			})
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-read"]
		],
		standalone: !0,
		features: [fe],
		decls: 4,
		vars: 3,
		consts: [
			[1, "absolute", "top-0", "left-0", "z-auto", "flex", "w-full", "justify-center"],
			["loop", "", "src", "./../../../assets/video1.mp4", "type", "video/mp4", "oncanplay", "this.play()", "onloadedmetadata", "this.muted = true", 1, "min-w-full", "min-h-full", "m-auto", 3, "autoplay"],
			[3, "data"],
			[3, "pendingMessage"],
			["src", "../../../../../assets/video2.mp4", "type", "video/mp4", "oncanplay", "this.play()", "onloadedmetadata", "this.muted = true", 1, "min-w-full", "min-h-full", "m-auto", 3, "ended", "autoplay"]
		],
		template: function(i, o) {
			i & 1 && Me(0, Kb, 2, 1, "div", 0)(1, Jb, 2, 1, "div", 0)(2, Xb, 1, 1, "video", 1)(3, eI, 1, 1), i & 2 && (Pe(0, o.showSuccessMessage ? 0 : -1), j(), Pe(1, o.showTempMessage ? 1 : -1), j(), Pe(2, o.showSuccessVideo ? 3 : 2))
		},
		dependencies: [Mg, Kh, _g]
	});
	let e = t;
	return e
})();
var Sg = [{
	path: "",
	redirectTo: "/read",
	pathMatch: "full"
}, {
	path: "home",
	component: Ig
}, {
	path: "read",
	component: Jc
}, {
	path: "**",
	component: Jc
}];
var Tg = {
	providers: [Zp(Sg)]
};
var ms = () => ["/home"],
	tI = e => ({
		hidden: e
	}),
	xg = () => ["/read"];

function nI(e, t) {
	e & 1 && (v(0, "a", 3)(1, "span", 6), P(2, "Kidsquad RFID System"), y(), Y(3, "img", 20), y()), e & 2 && te("routerLink", on(1, ms))
}

function rI(e, t) {
	if (e & 1 && (v(0, "div", 9)(1, "a", 31), P(2, " Home "), y(), v(3, "a", 32), P(4, " Docs "), y(), v(5, "a", 31), P(6, " Read "), y(), v(7, "a", 33), P(8, " Company "), y(), v(9, "p", 29), P(10), y()()), e & 2) {
		let r = Rt();
		j(), te("routerLink", on(3, ms)), j(4), te("routerLink", on(4, xg)), j(5), pt(" ", r.scannerId, " ")
	}
}

function iI(e, t) {
	e & 1 && (v(0, "span", 14), Y(1, "span", 34)(2, "span", 35), y())
}

function oI(e, t) {
	e & 1 && (v(0, "span", 14), Y(1, "span", 36)(2, "span", 37), y())
}

function sI(e, t) {
	e & 1 && (v(0, "span", 14), Y(1, "span", 34)(2, "span", 35), y())
}

function aI(e, t) {
	e & 1 && (v(0, "span", 14), Y(1, "span", 36)(2, "span", 37), y())
}
var Ag = (() => {
	let t = class t {
		constructor() {
			this.networkingService = p(jt), this.showMobileMenu = !1, this.serverActive = !1, this.showHeaderLinks = !1, this.$end = new X, this.scannerId = ""
		}
		ngOnInit() {
			this.networkingService.wsState.pipe(Cn(this.$end)).subscribe(n => {
				this.serverActive = n
			}), this.networkingService.scannerId.subscribe(n => {
				this.scannerId = n
			})
		}
		ngOnDestroy() {
			this.$end.next(!0), this.$end.complete()
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-header"]
		],
		standalone: !0,
		features: [fe],
		decls: 48,
		vars: 14,
		consts: [
			[1, "absolute", "inset-x-0", "top-0", "z-10"],
			["aria-label", "Global", 1, "flex", "items-center", "justify-between", "p-6", "lg:px-8"],
			[1, "flex", "lg:flex-1"],
			[1, "-m-1.5", "p-1.5", 3, "routerLink"],
			[1, "flex", "lg:hidden"],
			["type", "button", 1, "-m-2.5", "inline-flex", "items-center", "justify-center", "rounded-md", "p-2.5", "text-gray-700", 3, "click"],
			[1, "sr-only"],
			["fill", "none", "viewBox", "0 0 24 24", "stroke-width", "1.5", "stroke", "currentColor", "aria-hidden", "true", 1, "h-6", "w-6"],
			["stroke-linecap", "round", "stroke-linejoin", "round", "d", "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"],
			[1, "hidden", "lg:flex", "lg:gap-x-12"],
			[1, "hidden", "lg:flex", "lg:flex-1", "lg:justify-end"],
			["routerLinkActive", "text-primary-600", 1, "text-sm", "font-semibold", "leading-6", "text-gray-900", "sr-only", 3, "routerLink"],
			["aria-hidden", "true"],
			[3, "click"],
			[1, "relative", "flex", "h-3", "w-3"],
			["role", "dialog", "aria-modal", "true", 1, "lg:hidden", 3, "ngClass"],
			[1, "fixed", "inset-0", "z-50"],
			[1, "fixed", "inset-y-0", "right-0", "z-50", "w-full", "overflow-y-auto", "bg-white", "px-6", "py-6", "sm:max-w-sm", "sm:ring-1", "sm:ring-gray-900/10"],
			[1, "flex", "items-center", "justify-between"],
			["href", "#", 1, "-m-1.5", "p-1.5"],
			["src", "https://kidsquad.com.mx/creative-studio/img/logo.png", "alt", "kidsquad logo", 1, "h-8", "w-auto"],
			["type", "button", 1, "-m-2.5", "rounded-md", "p-2.5", "text-gray-700", 3, "click"],
			["stroke-linecap", "round", "stroke-linejoin", "round", "d", "M6 18L18 6M6 6l12 12"],
			[1, "mt-6", "flow-root"],
			[1, "-my-6", "divide-y", "divide-gray-500/10"],
			[1, "space-y-2", "py-6"],
			["routerLinkActive", "text-primary-600", 1, "-mx-3", "block", "rounded-lg", "px-3", "py-2", "text-base", "font-semibold", "leading-7", "text-gray-900", "hover:bg-gray-50", 3, "routerLink"],
			["href", "https://github.com/EdwardOmondi/tag_system_pi/blob/main/Readme.md", "target", "_blank", "routerLinkActive", "text-primary-600", 1, "-mx-3", "block", "rounded-lg", "px-3", "py-2", "text-base", "font-semibold", "leading-7", "text-gray-900", "hover:bg-gray-50"],
			["href", "https://kidsquad.com.mx/", 1, "-mx-3", "block", "rounded-lg", "px-3", "py-2", "text-base", "font-semibold", "leading-7", "text-gray-900", "hover:bg-gray-50"],
			[1, "rounded-md", "bg-primary-600", "px-3.5", "py-2.5", "text-xl", "font-semibold", "text-white", "shadow-sm"],
			[1, "py-6"],
			["routerLinkActive", "text-primary-600", 1, "text-sm", "font-semibold", "leading-6", "text-gray-900", 3, "routerLink"],
			["href", "https://github.com/EdwardOmondi/tag_system_pi/blob/main/Readme.md", "target", "_blank", "routerLinkActive", "text-primary-600", 1, "text-sm", "font-semibold", "leading-6", "text-gray-900"],
			["href", "https://kidsquad.com.mx", 1, "text-sm", "font-semibold", "leading-6", "text-gray-900"],
			[1, "animate-ping", "absolute", "inline-flex", "h-full", "w-full", "rounded-full", "bg-green-400", "opacity-75"],
			[1, "relative", "inline-flex", "rounded-full", "h-3", "w-3", "bg-green-500"],
			[1, "animate-ping", "absolute", "inline-flex", "h-full", "w-full", "rounded-full", "bg-red-400", "opacity-75"],
			[1, "relative", "inline-flex", "rounded-full", "h-3", "w-3", "bg-red-500"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "header", 0)(1, "nav", 1)(2, "div", 2), Me(3, nI, 4, 2, "a", 3), y(), v(4, "div", 4)(5, "button", 5), Te("click", function() {
				return o.showMobileMenu = !0
			}), v(6, "span", 6), P(7, "Open main menu"), y(), cu(), v(8, "svg", 7), Y(9, "path", 8), y()()(), Me(10, rI, 11, 5, "div", 9), lu(), v(11, "div", 10)(12, "a", 11), P(13, "Home "), v(14, "span", 12), P(15, "\u2192"), y()(), v(16, "button", 13), Te("click", function() {
				return o.showHeaderLinks = !o.showHeaderLinks
			}), Me(17, iI, 3, 0, "span", 14)(18, oI, 3, 0), y()()(), v(19, "div", 15), Y(20, "div", 16), v(21, "div", 17)(22, "div", 18)(23, "a", 19)(24, "span", 6), P(25, "Kidsquad RFID System"), y(), Y(26, "img", 20), y(), v(27, "button", 21), Te("click", function() {
				return o.showMobileMenu = !1
			}), v(28, "span", 6), P(29, "Close menu"), y(), cu(), v(30, "svg", 7), Y(31, "path", 22), y()()(), lu(), v(32, "div", 23)(33, "div", 24)(34, "div", 25)(35, "a", 26), P(36, " Home "), y(), v(37, "a", 27), P(38, " Docs "), y(), v(39, "a", 26), P(40, " Read "), y(), v(41, "a", 28), P(42, " Company "), y(), v(43, "p", 29), P(44), y()(), v(45, "div", 30), Me(46, sI, 3, 0, "span", 14)(47, aI, 3, 0), y()()()()()()), i & 2 && (j(3), Pe(3, o.showHeaderLinks ? 3 : -1), j(7), Pe(10, o.showHeaderLinks ? 10 : -1), j(2), te("routerLink", on(9, ms)), j(5), Pe(17, o.serverActive ? 17 : 18), j(2), te("ngClass", Ih(10, tI, !o.showMobileMenu)), j(16), te("routerLink", on(12, ms)), j(4), te("routerLink", on(13, xg)), j(5), pt(" ", o.scannerId, " "), j(2), Pe(46, o.serverActive ? 46 : 47))
		},
		dependencies: [us, is, qp, Gu, jh]
	});
	let e = t;
	return e
})();
var Ng = (() => {
	let t = class t {
		constructor() {
			this.error = ""
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-alert"]
		],
		inputs: {
			error: "error"
		},
		standalone: !0,
		features: [fe],
		decls: 8,
		vars: 1,
		consts: [
			[1, "w-full", "flex", "justify-center"],
			["role", "alert", 1, "mt-20", "bg-red-100", "border", "border-red-400", "text-red-700", "px-4", "py-3", "rounded-md", "relative", "max-w-sm"],
			[1, "font-bold"],
			[1, "block", "sm:inline"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "div", 0)(1, "div", 1)(2, "p", 2), P(3, "Oops!"), y(), v(4, "span", 3), P(5, " Something went wrong."), y(), v(6, "p"), P(7), y()()()), i & 2 && (j(7), xr(o.error))
		}
	});
	let e = t;
	return e
})();

function uI(e, t) {
	if (e & 1 && (v(0, "div", 1), Y(1, "app-alert", 2), y()), e & 2) {
		let r = t.$implicit;
		j(), te("error", r)
	}
}
var Rg = (() => {
	let t = class t {
		constructor() {
			this.title = "ui", this.networkingService = p(jt), this.errors = []
		}
		ngOnInit() {
			this.networkingService.errors.subscribe(n => {
				this.errors = n
			})
		}
	};
	t.\u0275fac = function(i) {
		return new(i || t)
	}, t.\u0275cmp = de({
		type: t,
		selectors: [
			["app-root"]
		],
		standalone: !0,
		features: [fe],
		decls: 5,
		vars: 0,
		consts: [
			[1, "bg-white", "min-h-full"],
			[1, "absolute", "bottom-0", "left-0", "z-auto", "flex", "w-full", "justify-center"],
			[1, "", 3, "error"]
		],
		template: function(i, o) {
			i & 1 && (v(0, "div", 0), Y(1, "app-header"), yh(2, uI, 2, 1, "div", 1, vh), Y(4, "router-outlet"), y()), i & 2 && (j(2), Dh(o.errors))
		},
		dependencies: [jc, Ag, Ng]
	});
	let e = t;
	return e
})();
op(Rg, Tg).catch(e => console.error(e));